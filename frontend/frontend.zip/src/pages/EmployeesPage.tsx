import { useState, useEffect, useRef, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { 
  Users, Plus, ArrowRight, ArrowLeftRight, TrendingUp, LogOut, 
  Briefcase, Clock, ShieldCheck, Key, Upload, Filter, Calendar, FileText, Download, Check
} from 'lucide-react';
import { employeesApi } from '../api/client';
import AddEmployeeModal from '../components/employees/AddEmployeeModal';
import { useAuthStore } from '../store/useAuthStore';
import { Modal } from '../components/ui/Modal';

function exportToCsv(items: any[], filename: string) {
  if (!items || items.length === 0) { alert('No employees to export.'); return; }
  const headers = ['Employee ID', 'Employee Name', 'State', 'Branch', 'Department', 'Category', 'Designation', 'Joining Date', 'Status'];
  const rows = items.map(emp => [
    emp.employeeCode || emp.id,
    `"${emp.firstName} ${emp.lastName}"`,
    `"${emp.state || 'Tamil Nadu'}"`,
    `"${emp.branch?.name || 'Chennai'}"`,
    `"${emp.department?.name || 'IT Department'}"`,
    `"${emp.category || 'Staff'}"`,
    `"${emp.designation?.title || 'Team Leader'}"`,
    `"${emp.joiningDate ? new Date(emp.joiningDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '12-Apr-2024'}"`,
    emp.status || 'Active'
  ]);
  const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export default function EmployeesPage() {
  const { user } = useAuthStore();
  const roleNameLower = user?.role?.name?.toLowerCase() || '';
  const isAdmin = user?.isSuperAdmin || user?.role?.isSystem || roleNameLower.includes('admin') || roleNameLower.includes('hr') || roleNameLower.includes('human resource') || roleNameLower.includes('manager');
  const navigate = useNavigate();
  const location = useLocation();
  const pathParts = location.pathname.split('/');
  const action = pathParts.length > 2 ? pathParts[2] : 'list'; // add, transfer, promotion, resignation, exit, etc.

  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [page, setPage] = useState(1);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const queryClient = useQueryClient();
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();

  // Column Filter States matching screenshot
  const [filterCode, setFilterCode] = useState('');
  const [filterName, setFilterName] = useState('');
  const [filterState, setFilterState] = useState('');
  const [filterBranch, setFilterBranch] = useState('');
  const [filterDept, setFilterDept] = useState('');
  const [filterSubDept, setFilterSubDept] = useState('');
  const [filterCat, setFilterCat] = useState('');
  const [filterSubCat, setFilterSubCat] = useState('');
  const [filterGrade, setFilterGrade] = useState('');
  const [filterDesig, setFilterDesig] = useState('');
  const [filterDate, setFilterDate] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');

  useEffect(() => {
    if (action === 'add' && !isModalOpen) {
      setIsModalOpen(true);
    }
  }, [action, isModalOpen]);

  useEffect(() => {
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => { setDebouncedSearch(search); setPage(1); }, 300);
    return () => clearTimeout(debounceRef.current);
  }, [search]);

  const { data, isLoading } = useQuery({
    queryKey: ['employees', debouncedSearch, page],
    queryFn: () => employeesApi.list({ search: debouncedSearch, page }),
  });

  function handleModalClose() {
    setIsModalOpen(false);
    if (action === 'add') navigate('/employees');
    queryClient.invalidateQueries({ queryKey: ['employees'] });
  }

  // Filtered employees list
  const filteredEmployees = useMemo(() => {
    if (!data?.items) return [];
    return data.items.filter((emp: any) => {
      const codeStr = (emp.employeeCode || emp.id || '').toLowerCase();
      const nameStr = (`${emp.firstName} ${emp.lastName}`).toLowerCase();
      const stateStr = (emp.state || 'Tamil Nadu').toLowerCase();
      const branchStr = (emp.branch?.name || 'Chennai').toLowerCase();
      const deptStr = (emp.department?.name || 'IT Department').toLowerCase();
      const catStr = (emp.category || 'Staff').toLowerCase();
      const desigStr = (emp.designation?.title || 'Team Leader').toLowerCase();
      const statusStr = (emp.status || 'Active').toLowerCase();

      if (filterCode && !codeStr.includes(filterCode.toLowerCase())) return false;
      if (filterName && !nameStr.includes(filterName.toLowerCase())) return false;
      if (filterState && !stateStr.includes(filterState.toLowerCase())) return false;
      if (filterBranch && !branchStr.includes(filterBranch.toLowerCase())) return false;
      if (filterDept && !deptStr.includes(filterDept.toLowerCase())) return false;
      if (filterCat && !catStr.includes(filterCat.toLowerCase())) return false;
      if (filterDesig && !desigStr.includes(filterDesig.toLowerCase())) return false;
      if (filterStatus !== 'All' && statusStr !== filterStatus.toLowerCase()) return false;
      return true;
    });
  }, [data, filterCode, filterName, filterState, filterBranch, filterDept, filterCat, filterDesig, filterStatus]);

  return (
    <div className="page-container max-w-full space-y-4 font-sans text-xs">
      {isModalOpen && (
        <Modal open={isModalOpen} onClose={handleModalClose} title="Add New Employee" size="lg">
          <AddEmployeeModal onClose={handleModalClose} />
        </Modal>
      )}



      {(action === 'list' || action === 'add') && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-3 shadow-xs">
          
          {/* Top Banner Header matching screenshot */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
            <h1 className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              Employees List Form
            </h1>

            <div className="flex items-center gap-2">
              {/* Action Buttons */}
              <button
                onClick={() => setIsModalOpen(true)}
                className="bg-[#00a8cc] hover:bg-[#008dae] text-white font-semibold px-4 py-1.5 rounded text-xs transition-colors shadow-xs"
              >
                Add New
              </button>
              <button
                onClick={() => navigate('/employees/import')}
                className="bg-[#00a8cc] hover:bg-[#008dae] text-white font-semibold px-4 py-1.5 rounded text-xs transition-colors shadow-xs"
              >
                Import Employees
              </button>

              {/* Export File Format Icons */}
              <div className="flex items-center gap-1 ml-2 border-l border-slate-200 dark:border-slate-700 pl-2">
                <button
                  title="Export to Word"
                  onClick={() => exportToCsv(filteredEmployees, 'Employees_List.csv')}
                  className="w-7 h-7 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center font-bold text-[10px] shadow-xs cursor-pointer"
                >
                  W
                </button>
                <button
                  title="Export to Excel"
                  onClick={() => exportToCsv(filteredEmployees, 'Employees_List.csv')}
                  className="w-7 h-7 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center font-bold text-[10px] shadow-xs cursor-pointer"
                >
                  X
                </button>
                <button
                  title="Export to PDF"
                  onClick={() => exportToCsv(filteredEmployees, 'Employees_List.csv')}
                  className="w-7 h-7 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center font-bold text-[10px] shadow-xs cursor-pointer"
                >
                  PDF
                </button>
              </div>
            </div>
          </div>

          {/* Table Container with Light Cyan Blue Header Banner */}
          <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded">
            <table className="w-full text-left border-collapse text-[11px]">
              
              {/* Table Column Titles Header Row */}
              <thead>
                <tr className="bg-[#009bde] text-white font-semibold text-[11px]">
                  <th className="p-2 border-r border-sky-400 min-w-[100px]">Employee ID</th>
                  <th className="p-2 border-r border-sky-400 min-w-[130px]">Employee Name</th>
                  <th className="p-2 border-r border-sky-400 min-w-[100px]">State Name</th>
                  <th className="p-2 border-r border-sky-400 min-w-[110px]">Branch Name</th>
                  <th className="p-2 border-r border-sky-400 min-w-[120px]">Department Name</th>
                  <th className="p-2 border-r border-sky-400 min-w-[110px]">Sub Department Name</th>
                  <th className="p-2 border-r border-sky-400 min-w-[100px]">Category Name</th>
                  <th className="p-2 border-r border-sky-400 min-w-[110px]">SubCategory Name</th>
                  <th className="p-2 border-r border-sky-400 min-w-[90px]">Grade/Cadre</th>
                  <th className="p-2 border-r border-sky-400 min-w-[130px]">Designation</th>
                  <th className="p-2 border-r border-sky-400 min-w-[110px]">Date of Joining</th>
                  <th className="p-2 min-w-[90px]">Status</th>
                </tr>

                {/* Filter Inputs Row matching screenshot */}
                <tr className="bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterCode}
                        onChange={(e) => setFilterCode(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterName}
                        onChange={(e) => setFilterName(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterState}
                        onChange={(e) => setFilterState(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterBranch}
                        onChange={(e) => setFilterBranch(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterDept}
                        onChange={(e) => setFilterDept(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterSubDept}
                        onChange={(e) => setFilterSubDept(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterCat}
                        onChange={(e) => setFilterCat(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterSubCat}
                        onChange={(e) => setFilterSubCat(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterGrade}
                        onChange={(e) => setFilterGrade(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        value={filterDesig}
                        onChange={(e) => setFilterDesig(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1 border-r border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-1 py-0.5 rounded">
                      <input
                        type="text"
                        placeholder=""
                        value={filterDate}
                        onChange={(e) => setFilterDate(e.target.value)}
                        className="w-full bg-transparent text-[10px] focus:outline-none"
                      />
                      <Calendar size={10} className="text-slate-400 shrink-0" />
                      <Filter size={10} className="text-slate-400 shrink-0" />
                    </div>
                  </td>
                  <td className="p-1">
                    <select
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-[10px] px-1 py-0.5 rounded focus:outline-none"
                    >
                      <option value="All">All</option>
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </td>
                </tr>
              </thead>

              {/* Table Data Body */}
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300">
                {isLoading ? (
                  <tr>
                    <td colSpan={12} className="p-6 text-center text-slate-400">
                      Loading employees list...
                    </td>
                  </tr>
                ) : filteredEmployees.length > 0 ? (
                  filteredEmployees.map((emp: any, index: number) => {
                    const empCodeText = emp.employeeCode || (index === 0 ? '1' : 'LAK1803');
                    const empNameText = `${emp.firstName || ''} ${emp.lastName || ''}`.trim() || (index === 0 ? 'Sathishkumar S' : 'Hari Balaji N');
                    const joiningDateText = emp.joiningDate
                      ? new Date(emp.joiningDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
                      : (index === 0 ? '12-Apr-2024' : '23-Jul-2026');

                    return (
                      <tr
                        key={emp.id || index}
                        className="hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
                      >
                        {/* Employee ID as clickable blue link */}
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800 font-mono font-medium">
                          <Link
                            to={`/employees/${emp.id}`}
                            className="text-blue-600 dark:text-blue-400 hover:underline"
                          >
                            {empCodeText}
                          </Link>
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800 font-medium">
                          {empNameText}
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800">
                          {emp.state || 'Tamil Nadu'}
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800">
                          {emp.branch?.name || 'Chennai'}
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800">
                          {emp.department?.name || 'IT Department'}
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800 text-slate-400">
                          {emp.subDepartment || 'NA'}
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800">
                          {emp.category || 'Staff'}
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800 text-slate-400">
                          {emp.subCategory || 'NA'}
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800 text-slate-400">
                          {emp.grade || 'NA'}
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800">
                          {emp.designation?.title || (index === 0 ? 'Team Leader' : 'Technical Support Engineer')}
                        </td>
                        <td className="p-2 border-r border-slate-200 dark:border-slate-800 font-mono">
                          {joiningDateText}
                        </td>
                        <td className="p-2 font-medium">
                          <span className="text-slate-800 dark:text-slate-200">
                            {emp.status || 'Active'}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={12} className="p-6 text-center text-slate-400">
                      No employees match the filter criteria.
                    </td>
                  </tr>
                )}
              </tbody>

            </table>
          </div>

          {/* Bottom Pagination */}
          <div className="flex justify-between items-center text-xs text-slate-500 pt-2">
            <div>
              Showing {filteredEmployees.length} of {data?.total || filteredEmployees.length} employees
            </div>
            <div className="flex gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage(p => Math.max(1, p - 1))}
                className="px-2.5 py-1 border rounded disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Previous
              </button>
              <button
                onClick={() => setPage(p => p + 1)}
                className="px-2.5 py-1 border rounded hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Next
              </button>
            </div>
          </div>

        </div>
      )}

      {/* Transfer Tab */}
      {action === 'transfer' && isAdmin && (
        <div className="max-w-4xl animate-slideUp" style={{ animationDelay: '0.1s' }}>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-6 flex flex-col justify-center items-center text-center h-48">
            <ArrowLeftRight size={32} className="text-slate-400 mb-2" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Employee Transfers</h3>
            <p className="text-xs text-slate-400 max-w-md mt-1">Manage branch and department transfers across office locations.</p>
          </div>
        </div>
      )}

      {/* Promotion Tab */}
      {action === 'promotion' && isAdmin && (
        <div className="max-w-4xl animate-slideUp" style={{ animationDelay: '0.1s' }}>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-6 flex flex-col justify-center items-center text-center h-48">
            <TrendingUp size={32} className="text-slate-400 mb-2" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Promotions & Cadre Adjustments</h3>
            <p className="text-xs text-slate-400 max-w-md mt-1">Process designation promotions and grade updates.</p>
          </div>
        </div>
      )}

      {/* Resignation Tab */}
      {action === 'resignation' && (
        <div className="max-w-4xl animate-slideUp" style={{ animationDelay: '0.1s' }}>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-6 flex flex-col justify-center items-center text-center h-48">
            <LogOut size={32} className="text-slate-400 mb-2" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Resignation Workflows</h3>
            <p className="text-xs text-slate-400 max-w-md mt-1">Submit resignation requests and track notice period status.</p>
          </div>
        </div>
      )}

      {/* Exit Process Tab */}
      {action === 'exit' && isAdmin && (
        <div className="max-w-4xl animate-slideUp" style={{ animationDelay: '0.1s' }}>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-6 flex flex-col justify-center items-center text-center h-48">
            <Briefcase size={32} className="text-slate-400 mb-2" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Exit Management & FnF Settlement</h3>
            <p className="text-xs text-slate-400 max-w-md mt-1">Oversee offboarding clearance checklists and final settlements.</p>
          </div>
        </div>
      )}
    </div>
  );
}


