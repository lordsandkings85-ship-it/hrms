import MyTravelPage from './employee/MyTravelPage';
export default function TravelPage() { return <MyTravelPage />; }
