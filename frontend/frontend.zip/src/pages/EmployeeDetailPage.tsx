import { useParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { employeesApi } from '../api/client';
import AdvancedEmployeeForm from '../components/employees/AdvancedEmployeeForm';

export default function EmployeeDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const { data: emp, isLoading } = useQuery({
    queryKey: ['employee', id],
    queryFn: () => employeesApi.get(id!),
    enabled: !!id,
  });

  if (isLoading) return <div className="page-container flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-500"></div></div>;
  if (!emp) return <div className="page-container flex items-center justify-center h-64 text-red-500">Employee not found.</div>;

  // Format initialData to handle nested objects matching the form state
  const initialData = {
    ...emp,
    paymentInfo: emp.paymentInfo || {},
    adminInfo: emp.adminInfo || {},
    personalInfo: emp.personalInfo || {},
    familyMembers: emp.familyMembers?.length ? emp.familyMembers : [{ relation: '', name: '', mobile: '', occupation: '', birthDate: '' }],
    emergencyContacts: emp.emergencyContacts?.length ? emp.emergencyContacts : [{ name: '', address: '', mobileNo: '', telNo: '' }],
  };

  return (
    <AdvancedEmployeeForm 
      initialData={initialData} 
      onClose={() => navigate('/employees')} 
    />
  );
}
