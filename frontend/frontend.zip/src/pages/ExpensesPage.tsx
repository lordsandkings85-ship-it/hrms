import MyExpensesPage from './employee/MyExpensesPage';
export default function ExpensesPage() { return <MyExpensesPage />; }
