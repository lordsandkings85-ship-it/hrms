import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Star, Users, Target, Search, Filter } from 'lucide-react';
import { performanceApi, employeesApi } from '../../../api/client';
import { DataTable, Column } from '../../../components/ui/DataTable';
import { StatusBadge } from '../../../components/ui/Badge';

export default function ManagerEvaluationPage() {
  const [selectedEmp, setSelectedEmp] = useState('');

  const { data: employees } = useQuery({
    queryKey: ['employees-list-all'],
    queryFn: () => employeesApi.list({ page: 1 }),
  });

  const { data: goals, isLoading: goalsLoading } = useQuery({
    queryKey: ['performance-goals', selectedEmp],
    queryFn: () => performanceApi.listGoals(selectedEmp),
    enabled: !!selectedEmp,
  });

  const { data: reviews, isLoading: reviewsLoading } = useQuery({
    queryKey: ['performance-reviews', selectedEmp],
    queryFn: () => performanceApi.listReviews(selectedEmp),
    enabled: !!selectedEmp,
  });

  const goalColumns: Column<any>[] = [
    { key: 'title', header: 'Goal Title', render: (row: any) => <span className="font-bold text-[var(--text-primary)]">{row.title}</span> },
    { key: 'description', header: 'Description', render: (row: any) => <span className="text-[var(--text-muted)] text-xs truncate max-w-[200px] block">{row.description}</span> },
    { key: 'dueDate', header: 'Due Date', render: (row: any) => <span className="font-mono text-xs">{row.dueDate ? new Date(row.dueDate).toLocaleDateString() : '—'}</span> },
    { 
      key: 'progress', 
      header: 'Progress', 
      render: (row: any) => (
        <div className="flex items-center gap-2">
          <div className="w-24 h-1.5 bg-[var(--surface-alt)] rounded-full overflow-hidden border border-[var(--border)]">
             <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${row.progress}%` }}></div>
          </div>
          <span className="text-[10px] font-bold text-[var(--text-muted)]">{row.progress}%</span>
        </div>
      ) 
    },
    { key: 'status', header: 'Status', render: (row: any) => <StatusBadge status={row.status || (row.progress === 100 ? 'completed' : 'in_progress')} /> },
  ];

  const reviewColumns: Column<any>[] = [
    { key: 'cycle', header: 'Cycle', render: (row: any) => <span className="font-bold text-[var(--text-primary)]">{row.cycle}</span> },
    { key: 'type', header: 'Type', render: (row: any) => <span className="text-xs uppercase tracking-wider font-bold text-indigo-500 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">{row.type}</span> },
    { 
      key: 'score', 
      header: 'Score', 
      render: (row: any) => (
        <div className="flex items-center gap-1">
          {[1,2,3,4,5].map(s => (
             <Star key={s} size={12} className={s <= row.score ? "text-amber-500 fill-amber-500" : "text-[var(--border)]"} />
          ))}
          <span className="ml-1 text-xs font-bold">{row.score}/5</span>
        </div>
      ) 
    },
    { key: 'date', header: 'Date', render: (row: any) => <span className="font-mono text-xs text-[var(--text-muted)]">{new Date(row.createdAt).toLocaleDateString()}</span> },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Premium Header */}
      <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="absolute top-0 right-0 p-32 bg-amber-500/10 rounded-bl-full -z-0 blur-2xl"></div>
        <div className="relative z-10 flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-500 shadow-inner">
             <Star size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--text-primary)] tracking-tight">Manager Evaluation</h1>
            <p className="text-sm text-[var(--text-muted)] mt-1 font-medium">Manage and review employee performance metrics.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Context Selector Sidebar */}
        <div className="xl:col-span-1 space-y-6">
           <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-5 shadow-sm">
              <h3 className="text-sm font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2"><Users size={16} className="text-amber-500" /> Employee Context</h3>
              <p className="text-xs text-[var(--text-muted)] mb-3">Select an employee to view their manager evaluation details.</p>
              <select
                value={selectedEmp}
                onChange={(e) => setSelectedEmp(e.target.value)}
                className="w-full px-3 py-2.5 bg-[var(--surface-alt)] border border-[var(--border)] rounded-xl text-sm font-medium text-[var(--text-primary)] focus:outline-none focus:border-amber-500/50 transition-colors"
              >
                <option value="">-- Select Employee --</option>
                {employees?.items?.map((emp: any) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.firstName} {emp.lastName} ({emp.employeeCode})
                  </option>
                ))}
              </select>
           </div>
        </div>

        {/* Content Area */}
        <div className="xl:col-span-3">
          <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm min-h-[400px]">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6 pb-4 border-b border-[var(--border)]">
              <div>
                 <h3 className="text-lg font-bold text-[var(--text-primary)] flex items-center gap-2">
                   <Star size={20} className="text-amber-500" /> Manager Evaluation Data
                 </h3>
              </div>
            </div>
            
            {!selectedEmp ? (
               <div className="flex flex-col items-center justify-center h-64 text-[var(--text-muted)]">
                 <div className="w-16 h-16 rounded-2xl bg-[var(--surface-alt)] border border-[var(--border)] flex items-center justify-center mb-4">
                   <Users size={24} />
                 </div>
                 <p className="text-sm font-bold text-[var(--text-primary)]">No Employee Selected</p>
                 <p className="text-xs mt-1">Please select an employee from the sidebar to view data.</p>
               </div>
            ) : (
               <div className="premium-datatable">
                 <style>{`
                    .premium-datatable table { width: 100%; border-collapse: separate; border-spacing: 0 8px; }
                    .premium-datatable th { padding: 12px 16px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); font-weight: 700; border-bottom: 1px solid var(--border); text-align: left; }
                    .premium-datatable td { padding: 12px 16px; background: var(--surface-alt); border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); transition: background 0.2s; }
                    .premium-datatable tr td:first-child { border-left: 1px solid var(--border); border-top-left-radius: 12px; border-bottom-left-radius: 12px; }
                    .premium-datatable tr td:last-child { border-right: 1px solid var(--border); border-top-right-radius: 12px; border-bottom-right-radius: 12px; }
                    .premium-datatable tbody tr:hover td { background: var(--surface-hover); }
                 `}</style>
                 <DataTable columns={reviewColumns} data={reviews || []} loading={reviewsLoading} keyField="id" />
               </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
