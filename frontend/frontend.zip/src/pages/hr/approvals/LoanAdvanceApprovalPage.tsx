import { useMutation, useQueryClient } from '@tanstack/react-query';
import { leaveApi } from '../../../api/client';
import { ApprovalQueue } from '../../../components/hr/ApprovalQueue';
import { Landmark } from 'lucide-react';
import { useToast } from '../../../components/ui/ToastProvider';

export default function LoanAdvanceApprovalPage() {
  const queryClient = useQueryClient();
  const { success } = useToast();

  const approveMutation = useMutation({
    mutationFn: (id: string) => leaveApi.approve(id),
    onSuccess: () => { success('Approved!', 'Request was approved successfully.'); queryClient.invalidateQueries({ queryKey: ['loan-approvals'] }); }
  });

  const rejectMutation = useMutation({
    mutationFn: (id: string) => leaveApi.reject(id),
    onSuccess: () => { success('Rejected!', 'Request was rejected.'); queryClient.invalidateQueries({ queryKey: ['loan-approvals'] }); }
  });

  return (
    <ApprovalQueue
      title="Loan/Advance Approval"
      icon={Landmark}
      queryKey={['loan-approvals']}
      queryFn={async () => {
        const res = await leaveApi.listPending();
        return res || [];
      }}
      onApprove={(id) => approveMutation.mutate(id)}
      onReject={(id) => rejectMutation.mutate(id)}
    />
  );
}
