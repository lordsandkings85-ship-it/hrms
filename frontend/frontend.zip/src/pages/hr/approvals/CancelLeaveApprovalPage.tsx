import { useMutation, useQueryClient } from '@tanstack/react-query';
import { leaveApi } from '../../../api/client';
import { ApprovalQueue } from '../../../components/hr/ApprovalQueue';
import { XSquare } from 'lucide-react';
import { useToast } from '../../../components/ui/ToastProvider';

export default function CancelLeaveApprovalPage() {
  const queryClient = useQueryClient();
  const { success } = useToast();

  const approveMutation = useMutation({
    mutationFn: (id: string) => leaveApi.approve(id),
    onSuccess: () => { success('Approved!', 'Request was approved successfully.'); queryClient.invalidateQueries({ queryKey: ['cancel-leave-approvals'] }); }
  });

  const rejectMutation = useMutation({
    mutationFn: (id: string) => leaveApi.reject(id),
    onSuccess: () => { success('Rejected!', 'Request was rejected.'); queryClient.invalidateQueries({ queryKey: ['cancel-leave-approvals'] }); }
  });

  return (
    <ApprovalQueue
      title="Cancel Leave Application"
      icon={XSquare}
      queryKey={['cancel-leave-approvals']}
      queryFn={async () => {
        const res = await leaveApi.listPending();
        return res || [];
      }}
      onApprove={(id) => approveMutation.mutate(id)}
      onReject={(id) => rejectMutation.mutate(id)}
    />
  );
}
