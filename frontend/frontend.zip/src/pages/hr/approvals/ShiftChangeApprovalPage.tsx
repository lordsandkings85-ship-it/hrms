import { useMutation, useQueryClient } from '@tanstack/react-query';
import { leaveApi } from '../../../api/client';
import { ApprovalQueue } from '../../../components/hr/ApprovalQueue';
import { Clock } from 'lucide-react';
import { useToast } from '../../../components/ui/ToastProvider';

export default function ShiftChangeApprovalPage() {
  const queryClient = useQueryClient();
  const { success } = useToast();

  const approveMutation = useMutation({
    mutationFn: (id: string) => leaveApi.approve(id),
    onSuccess: () => { success('Approved!', 'Request was approved successfully.'); queryClient.invalidateQueries({ queryKey: ['shift-approvals'] }); }
  });

  const rejectMutation = useMutation({
    mutationFn: (id: string) => leaveApi.reject(id),
    onSuccess: () => { success('Rejected!', 'Request was rejected.'); queryClient.invalidateQueries({ queryKey: ['shift-approvals'] }); }
  });

  return (
    <ApprovalQueue
      title="Shift Change Approval"
      icon={Clock}
      queryKey={['shift-approvals']}
      queryFn={async () => {
        const res = await leaveApi.listPending();
        return res || [];
      }}
      onApprove={(id) => approveMutation.mutate(id)}
      onReject={(id) => rejectMutation.mutate(id)}
    />
  );
}
