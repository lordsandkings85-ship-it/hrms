import { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { Shield, Percent, IndianRupee, Heart, FileText, Search, Filter } from 'lucide-react';
import { DataTable, Column } from '../../components/ui/DataTable';

type TabKey = 'pt' | 'pf' | 'esic' | 'lwf' | 'forms';

const SUB_TO_TAB: Record<string, TabKey> = {
  pt: 'pt',
  pf: 'pf',
  esic: 'esic',
  lwf: 'lwf',
  forms: 'forms',
};

const TAB_TO_SUB: Record<TabKey, string> = {
  pt: 'pt',
  pf: 'pf',
  esic: 'esic',
  lwf: 'lwf',
  forms: 'forms',
};

export default function CompliancePage() {
  const navigate = useNavigate();
  const location = useLocation();
  const pathParts = location.pathname.split('/');
  const subAction = pathParts.length > 2 ? pathParts[2] : 'pt';

  const initialTab = SUB_TO_TAB[subAction] || 'pt';
  const [tab, setTab] = useState<TabKey>(initialTab);

  useEffect(() => {
    if (subAction && SUB_TO_TAB[subAction]) {
      setTab(SUB_TO_TAB[subAction]);
    }
  }, [subAction]);

  const handleTabChange = (t: TabKey) => {
    setTab(t);
    navigate(`/compliance/${TAB_TO_SUB[t]}`);
  };

  const TABS = [
    { key: 'pt', label: 'Professional Tax', icon: <Percent size={16} /> },
    { key: 'pf', label: 'Provident Fund (PF)', icon: <Shield size={16} /> },
    { key: 'esic', label: 'ESIC', icon: <Heart size={16} /> },
    { key: 'lwf', label: 'Labour Welfare Fund', icon: <IndianRupee size={16} /> },
    { key: 'forms', label: 'Compliance Forms', icon: <FileText size={16} /> },
  ] as const;

  const currentTab = TABS.find(t => t.key === tab) || TABS[0];

  const ptColumns: Column<any>[] = [
    { key: 'range', header: '6-Month Gross Salary Range', render: (row) => <span className="font-bold text-[var(--text-primary)]">{row.range}</span> },
    { key: 'halfYearly', header: 'Half-Yearly PT (₹)', render: (row) => <span className="font-mono text-sm text-[var(--text-muted)] font-bold">{row.halfYearly}</span> },
    { key: 'monthly', header: 'Monthly Equivalent (₹)', render: (row) => <span className="font-mono text-xs text-[var(--text-muted)]">{row.monthly}</span> },
    { key: 'status', header: 'Status', render: (row) => <span className={`text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${row.status === 'Exempt' ? 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20' : 'text-amber-500 bg-amber-500/10 border-amber-500/20'}`}>{row.status}</span> },
  ];

  const ptData = [
    { id: '1', range: '₹0 to ₹21,000', halfYearly: '₹0', monthly: '₹0', status: 'Exempt' },
    { id: '2', range: '₹21,001 to ₹30,000', halfYearly: '₹135', monthly: '₹22.50', status: 'Applicable' },
    { id: '3', range: '₹30,001 to ₹45,000', halfYearly: '₹315', monthly: '₹52.50', status: 'Applicable' },
    { id: '4', range: '₹45,001 to ₹60,000', halfYearly: '₹690', monthly: '₹115.00', status: 'Applicable' },
    { id: '5', range: '₹60,001 to ₹75,000', halfYearly: '₹1,025', monthly: '₹170.83', status: 'Applicable' },
    { id: '6', range: '₹75,001 and above', halfYearly: '₹1,250', monthly: '₹208.33', status: 'Applicable' },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      
      {/* Premium Header */}
      <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="absolute top-0 right-0 p-32 bg-rose-500/10 rounded-bl-full -z-0 blur-2xl"></div>
        <div className="relative z-10 flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-500 shadow-inner">
             <Shield size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--text-primary)] tracking-tight">Compliance Command Center</h1>
            <p className="text-sm text-[var(--text-muted)] mt-1 font-medium">Manage Professional Tax, PF, ESIC, and Statutory forms.</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {TABS.map(t => (
          <button
            key={t.key}
            onClick={() => handleTabChange(t.key)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all border ${
              tab === t.key
                ? 'bg-rose-500 text-white border-rose-500 shadow-md shadow-rose-500/20'
                : 'bg-[var(--surface)] text-[var(--text-muted)] border-[var(--border)] hover:bg-[var(--surface-hover)] hover:text-[var(--text-primary)]'
            }`}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      {/* Dynamic Content Area */}
      <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm min-h-[400px]">
          
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6 pb-4 border-b border-[var(--border)]">
            <div>
               <h3 className="text-lg font-bold text-[var(--text-primary)] flex items-center gap-2">
                 {currentTab.icon} {currentTab.label} Configuration
               </h3>
               <p className="text-xs text-[var(--text-muted)] mt-1 font-medium">Review and update statutory limits and rules for {currentTab.label}.</p>
            </div>
          </div>

          {tab === 'pt' ? (
             <div className="premium-datatable">
               <style>{`
                  .premium-datatable table { width: 100%; border-collapse: separate; border-spacing: 0 8px; }
                  .premium-datatable th { padding: 12px 16px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); font-weight: 700; border-bottom: 1px solid var(--border); text-align: left; }
                  .premium-datatable td { padding: 12px 16px; background: var(--surface-alt); border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); transition: background 0.2s; }
                  .premium-datatable tr td:first-child { border-left: 1px solid var(--border); border-top-left-radius: 12px; border-bottom-left-radius: 12px; }
                  .premium-datatable tr td:last-child { border-right: 1px solid var(--border); border-top-right-radius: 12px; border-bottom-right-radius: 12px; }
                  .premium-datatable tbody tr:hover td { background: var(--surface-hover); }
               `}</style>
               <DataTable columns={ptColumns} data={ptData} keyField="id" />
               <p className="text-xs text-[var(--text-muted)] mt-4">* Slabs are based on 6-Month Total Gross Salary. PT is assessed half-yearly (April-September & October-March).</p>
             </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 text-[var(--text-muted)]">
               <div className="w-16 h-16 rounded-2xl bg-[var(--surface-alt)] border border-[var(--border)] flex items-center justify-center mb-4">
                 {currentTab.icon}
               </div>
               <p className="text-sm font-bold text-[var(--text-primary)]">{currentTab.label}</p>
               <p className="text-xs mt-1">This compliance module is fully automated through payroll.</p>
            </div>
          )}

        </div>
      </div>

    </div>
  );
}
