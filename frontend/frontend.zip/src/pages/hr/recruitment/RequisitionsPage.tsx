import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ClipboardCheck, Search, Filter } from 'lucide-react';
import { recruitmentApi } from '../../../api/client';
import { DataTable, Column } from '../../../components/ui/DataTable';
import { StatusBadge } from '../../../components/ui/Badge';

export default function RequisitionsPage() {
  const [searchTerm, setSearchTerm] = useState('');

  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ['recruitment-jobs'],
    queryFn: () => recruitmentApi.listJobs(),
  });

  const jobColumns: Column<any>[] = [
    { key: 'title', header: 'Job Title', render: (row: any) => <span className="font-bold text-[var(--text-primary)]">{row.title}</span> },
    { key: 'department', header: 'Department', render: (row: any) => <span className="text-[var(--text-muted)] text-xs font-semibold uppercase tracking-wider">{row.department || 'Engineering'}</span> },
    { key: 'status', header: 'Status', render: (row: any) => <StatusBadge status={row.status || 'open'} /> },
    { key: 'candidates', header: 'Candidates', render: (row: any) => <span className="font-mono font-bold text-[var(--text-primary)]">{row.candidates?.length || 0} Applied</span> },
    { key: 'date', header: 'Posted Date', render: (row: any) => <span className="font-mono text-xs">{new Date(row.createdAt).toLocaleDateString()}</span> },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="absolute top-0 right-0 p-32 bg-emerald-500/10 rounded-bl-full -z-0 blur-2xl"></div>
        <div className="relative z-10 flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-500 shadow-inner">
             <ClipboardCheck size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--text-primary)] tracking-tight">Requisitions</h1>
            <p className="text-sm text-[var(--text-muted)] mt-1 font-medium">Manage job requisitions workflows.</p>
          </div>
        </div>
      </div>

      <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm min-h-[400px]">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6 pb-4 border-b border-[var(--border)]">
          <div>
             <h3 className="text-lg font-bold text-[var(--text-primary)] flex items-center gap-2">Requisitions</h3>
             <p className="text-xs text-[var(--text-muted)] mt-1 font-medium">Manage requisitions data below.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
              <input type="text" placeholder="Search..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-9 pr-4 py-2 bg-[var(--surface-alt)] border border-[var(--border)] rounded-xl text-xs text-[var(--text-primary)] focus:outline-none focus:border-emerald-500/50 transition-colors w-64" />
            </div>
            <button className="p-2 border border-[var(--border)] rounded-xl text-[var(--text-muted)] hover:text-emerald-500 hover:border-emerald-500/30 transition-colors bg-[var(--surface-alt)]">
               <Filter size={16} />
            </button>
          </div>
        </div>

        <div className="premium-datatable">
          <style>{`
             .premium-datatable table { width: 100%; border-collapse: separate; border-spacing: 0 8px; }
             .premium-datatable th { padding: 12px 16px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); font-weight: 700; border-bottom: 1px solid var(--border); text-align: left; }
             .premium-datatable td { padding: 12px 16px; background: var(--surface-alt); border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); transition: background 0.2s; }
             .premium-datatable tr td:first-child { border-left: 1px solid var(--border); border-top-left-radius: 12px; border-bottom-left-radius: 12px; }
             .premium-datatable tr td:last-child { border-right: 1px solid var(--border); border-top-right-radius: 12px; border-bottom-right-radius: 12px; }
             .premium-datatable tbody tr:hover td { background: var(--surface-hover); }
          `}</style>
          
          <DataTable columns={jobColumns} data={jobs || []} loading={isLoadingJobs} keyField="id" />
        </div>
      </div>
    </div>
  );
}
