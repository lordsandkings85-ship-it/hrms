import { useState } from 'react';
import {
  FileBarChart, IndianRupee, TrendingUp, TrendingDown, Shield,
  Download, Printer, Calendar, CheckCircle, Info, ChevronRight,
  Building2, User, Calculator, BarChart3
} from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';

const FY_LIST = ['FY 2025-26', 'FY 2024-25', 'FY 2023-24'];

interface IncomeHead {
  label: string;
  amount: number;
  note?: string;
  sub?: boolean;
}

interface Deduction {
  section: string;
  description: string;
  amount: number;
}

interface ITStatement {
  financialYear: string;
  regime: 'old' | 'new';
  income: IncomeHead[];
  grossIncome: number;
  deductions: Deduction[];
  totalDeductions: number;
  taxableIncome: number;
  taxSlabs: { slab: string; rate: string; tax: number }[];
  taxOnIncome: number;
  rebate87A: number;
  surcharge: number;
  cess: number;
  totalTaxLiability: number;
  tdsDeducted: number;
  selfAssessmentTax: number;
  refundDue: number;
}

const MOCK_IT_STATEMENTS: Record<string, ITStatement> = {
  'FY 2025-26': {
    financialYear: 'FY 2025-26 (AY 2026-27)',
    regime: 'old',
    income: [
      { label: 'Salary (as per Form 16)', amount: 1200000 },
      { label: 'Less: Standard Deduction (Sec. 16)', amount: -50000, sub: true },
      { label: 'Less: Professional Tax', amount: -2400, sub: true },
      { label: 'Net Salary Income', amount: 1147600, note: 'After Sec. 16 deductions' },
      { label: 'Interest Income (Savings)', amount: 8500 },
      { label: 'Other Income', amount: 0 },
    ],
    grossIncome: 1156100,
    deductions: [
      { section: '80C', description: 'EPF + LIC + PPF', amount: 150000 },
      { section: '80D', description: 'Health Insurance Premium', amount: 18000 },
      { section: '80CCD(1B)', description: 'NPS Contribution', amount: 50000 },
      { section: '80TTA', description: 'Interest on Savings Account', amount: 8500 },
    ],
    totalDeductions: 226500,
    taxableIncome: 929600,
    taxSlabs: [
      { slab: '₹0 – ₹2,50,000', rate: 'Nil', tax: 0 },
      { slab: '₹2,50,001 – ₹5,00,000', rate: '5%', tax: 12500 },
      { slab: '₹5,00,001 – ₹9,29,600', rate: '20%', tax: 85920 },
    ],
    taxOnIncome: 98420,
    rebate87A: 0,
    surcharge: 0,
    cess: 3937,
    totalTaxLiability: 102357,
    tdsDeducted: 78450,
    selfAssessmentTax: 0,
    refundDue: -23907,
  },
  'FY 2024-25': {
    financialYear: 'FY 2024-25 (AY 2025-26)',
    regime: 'old',
    income: [
      { label: 'Salary (as per Form 16)', amount: 1020000 },
      { label: 'Less: Standard Deduction (Sec. 16)', amount: -50000, sub: true },
      { label: 'Less: Professional Tax', amount: -2400, sub: true },
      { label: 'Net Salary Income', amount: 967600 },
      { label: 'Interest Income (Savings)', amount: 6200 },
      { label: 'Other Income', amount: 0 },
    ],
    grossIncome: 973800,
    deductions: [
      { section: '80C', description: 'EPF + LIC', amount: 125000 },
      { section: '80D', description: 'Health Insurance', amount: 15000 },
      { section: '80CCD(1B)', description: 'NPS Contribution', amount: 30000 },
      { section: '80TTA', description: 'Interest on Savings Account', amount: 6200 },
    ],
    totalDeductions: 176200,
    taxableIncome: 797600,
    taxSlabs: [
      { slab: '₹0 – ₹2,50,000', rate: 'Nil', tax: 0 },
      { slab: '₹2,50,001 – ₹5,00,000', rate: '5%', tax: 12500 },
      { slab: '₹5,00,001 – ₹7,97,600', rate: '20%', tax: 59520 },
    ],
    taxOnIncome: 72020,
    rebate87A: 0,
    surcharge: 0,
    cess: 2881,
    totalTaxLiability: 74901,
    tdsDeducted: 62400,
    selfAssessmentTax: 12501,
    refundDue: 0,
  },
};

function fmt(n: number) {
  if (n < 0) return '(₹' + Math.abs(n).toLocaleString('en-IN') + ')';
  return '₹' + n.toLocaleString('en-IN');
}

function LineItem({ label, value, bold, indent, highlight, green, red, note }: {
  label: string; value: string; bold?: boolean; indent?: boolean; highlight?: boolean; green?: boolean; red?: boolean; note?: string;
}) {
  return (
    <div className={`flex items-start justify-between py-3 border-b border-[var(--border)] last:border-0 ${indent ? 'pl-5' : ''}`}>
      <div>
        <span className={`text-sm ${bold ? 'font-semibold text-[var(--text-primary)]' : indent ? 'text-[var(--text-muted)]' : 'text-[var(--text-muted)]'}`}>{label}</span>
        {note && <div className="text-xs text-[var(--text-muted)] mt-0.5">{note}</div>}
      </div>
      <span className={`font-mono text-sm flex-shrink-0 ml-4 ${
        highlight ? 'text-indigo-400 font-bold text-base' :
        green ? 'text-green-400 font-semibold' :
        red ? 'text-red-400 font-semibold' :
        bold ? 'font-bold text-[var(--text-primary)]' : 'text-[var(--text-primary)]'
      }`}>
        {value}
      </span>
    </div>
  );
}

export default function ITStatementPage() {
  const { user } = useAuthStore();
  const [selectedFY, setSelectedFY] = useState('FY 2025-26');
  const [activeTab, setActiveTab] = useState<'income' | 'deductions' | 'tax'>('income');

  const statement = MOCK_IT_STATEMENTS[selectedFY];
  const emp = user?.employee;

  const handleDownload = () => {
    const content = `IT STATEMENT - ${statement.financialYear}\nEmployee: ${emp?.firstName} ${emp?.lastName}\nGross Income: ${fmt(statement.grossIncome)}\nTaxable Income: ${fmt(statement.taxableIncome)}\nTotal Tax Liability: ${fmt(statement.totalTaxLiability)}\nTDS Deducted: ${fmt(statement.tdsDeducted)}\n${statement.refundDue < 0 ? `Amount Payable: ${fmt(Math.abs(statement.refundDue))}` : `Refund Due: ${fmt(statement.refundDue)}`}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `IT_Statement_${selectedFY.replace(' ', '_')}.txt`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="IT Statement"
        subtitle="Income Tax computation statement for the selected assessment year"
        icon={FileBarChart}
        actions={
          <div className="flex items-center gap-2">
            <select value={selectedFY} onChange={e => setSelectedFY(e.target.value)}
              className="px-4 py-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40">
              {FY_LIST.map(fy => <option key={fy} value={fy}>{fy}</option>)}
            </select>
            <button onClick={handleDownload}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-indigo-500/20">
              <Download size={14} /> Download
            </button>
          </div>
        }
      />

      {/* Header Statement Card */}
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-indigo-600 via-purple-500 to-blue-500" />
        <div className="p-6">
          <div className="flex items-start justify-between gap-4 mb-5">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Shield size={14} className="text-indigo-400" />
                <span className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wider">Income Tax Department, India</span>
              </div>
              <h2 className="text-xl font-bold text-[var(--text-primary)]">Income Tax Statement</h2>
              <p className="text-sm text-[var(--text-muted)] mt-0.5">{statement.financialYear} · {statement.regime === 'old' ? 'Old Tax Regime' : 'New Tax Regime'}</p>
            </div>
            <span className={`px-3 py-1.5 rounded-full text-xs font-semibold border ${
              statement.refundDue < 0 ? 'bg-red-500/10 text-red-400 border-red-500/20' : 'bg-green-500/10 text-green-400 border-green-500/20'
            }`}>
              {statement.refundDue < 0 ? 'Tax Payable' : 'Refund Due'}
            </span>
          </div>

          {/* KPI Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Gross Income', value: fmt(statement.grossIncome), icon: IndianRupee, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
              { label: 'Total Deductions', value: fmt(statement.totalDeductions), icon: TrendingDown, color: 'text-green-400', bg: 'bg-green-500/10' },
              { label: 'Taxable Income', value: fmt(statement.taxableIncome), icon: BarChart3, color: 'text-amber-400', bg: 'bg-amber-500/10' },
              {
                label: statement.refundDue < 0 ? 'Tax Payable' : 'Refund Due',
                value: fmt(Math.abs(statement.refundDue)),
                icon: statement.refundDue < 0 ? TrendingDown : CheckCircle,
                color: statement.refundDue < 0 ? 'text-red-400' : 'text-green-400',
                bg: statement.refundDue < 0 ? 'bg-red-500/10' : 'bg-green-500/10',
              },
            ].map(c => (
              <div key={c.label} className={`${c.bg} rounded-xl p-4`}>
                <c.icon size={16} className={`${c.color} mb-2`} />
                <div className={`text-xl font-bold font-mono ${c.color}`}>{c.value}</div>
                <div className="text-xs text-[var(--text-muted)] mt-1">{c.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-[var(--surface-alt)] rounded-xl w-fit">
        {([['income', 'Income Details'], ['deductions', 'Deductions'], ['tax', 'Tax Computation']] as const).map(([key, label]) => (
          <button key={key} onClick={() => setActiveTab(key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === key ? 'bg-[var(--surface)] text-[var(--text-primary)] shadow-sm' : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
            }`}>
            {label}
          </button>
        ))}
      </div>

      {/* Income Details */}
      {activeTab === 'income' && (
        <div className="max-w-2xl rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
          <div className="px-6 py-4 border-b border-[var(--border)] bg-gradient-to-r from-indigo-500/5 to-transparent">
            <h3 className="font-semibold text-sm text-[var(--text-primary)]">Income Under All Heads</h3>
          </div>
          <div className="p-6 space-y-1">
            {statement.income.map((item, idx) => (
              <div key={idx} className={`flex items-start justify-between py-2.5 border-b border-[var(--border)] last:border-0 ${item.sub ? 'pl-4' : ''}`}>
                <div>
                  <div className={`text-sm ${item.sub ? 'text-[var(--text-muted)]' : 'text-[var(--text-primary)]'} ${item.note ? 'font-medium' : ''}`}>{item.label}</div>
                  {item.note && <div className="text-xs text-[var(--text-muted)] mt-0.5">{item.note}</div>}
                </div>
                <span className={`font-mono text-sm flex-shrink-0 ml-4 ${item.amount < 0 ? 'text-green-400' : item.note ? 'font-bold text-[var(--text-primary)]' : 'text-[var(--text-primary)]'}`}>
                  {item.amount < 0 ? `(₹${Math.abs(item.amount).toLocaleString('en-IN')})` : `₹${item.amount.toLocaleString('en-IN')}`}
                </span>
              </div>
            ))}
            <div className="flex justify-between py-3 font-bold text-sm border-t-2 border-indigo-500/20 mt-2">
              <span className="text-[var(--text-primary)]">Gross Total Income</span>
              <span className="font-mono text-indigo-400 text-base">₹{statement.grossIncome.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>
      )}

      {/* Deductions */}
      {activeTab === 'deductions' && (
        <div className="max-w-2xl rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
          <div className="px-6 py-4 border-b border-[var(--border)] bg-gradient-to-r from-green-500/5 to-transparent">
            <h3 className="font-semibold text-sm text-[var(--text-primary)]">Deductions from Gross Total Income</h3>
          </div>
          <div className="p-6 space-y-1">
            {statement.deductions.map((d, idx) => (
              <div key={idx} className="flex items-center justify-between py-3 border-b border-[var(--border)] last:border-0">
                <div>
                  <span className="inline-block px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 text-xs font-mono font-semibold border border-green-500/20 mr-2">{d.section}</span>
                  <span className="text-sm text-[var(--text-muted)]">{d.description}</span>
                </div>
                <span className="font-mono text-sm font-semibold text-green-400">₹{d.amount.toLocaleString('en-IN')}</span>
              </div>
            ))}
            <div className="flex justify-between py-3 font-bold text-sm border-t-2 border-green-500/20 mt-2">
              <span className="text-[var(--text-primary)]">Total Deductions</span>
              <span className="font-mono text-green-400 text-base">(₹{statement.totalDeductions.toLocaleString('en-IN')})</span>
            </div>
            <div className="flex justify-between py-3 font-bold text-sm">
              <span className="text-[var(--text-primary)]">Total Taxable Income</span>
              <span className="font-mono text-indigo-400 text-base">₹{statement.taxableIncome.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>
      )}

      {/* Tax Computation */}
      {activeTab === 'tax' && (
        <div className="max-w-2xl space-y-4">
          {/* Tax Slabs */}
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
            <div className="px-6 py-4 border-b border-[var(--border)] bg-gradient-to-r from-amber-500/5 to-transparent">
              <h3 className="font-semibold text-sm text-[var(--text-primary)]">Tax on Taxable Income (Slab-wise)</h3>
            </div>
            <div className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[var(--border)]">
                      <th className="text-left py-2 text-xs text-[var(--text-muted)] uppercase font-semibold">Income Slab</th>
                      <th className="text-center py-2 text-xs text-[var(--text-muted)] uppercase font-semibold">Rate</th>
                      <th className="text-right py-2 text-xs text-[var(--text-muted)] uppercase font-semibold">Tax</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statement.taxSlabs.map((slab, i) => (
                      <tr key={i} className="border-b border-[var(--border)] last:border-0">
                        <td className="py-3 text-[var(--text-muted)]">{slab.slab}</td>
                        <td className="py-3 text-center font-semibold text-[var(--text-primary)]">{slab.rate}</td>
                        <td className="py-3 text-right font-mono font-semibold text-[var(--text-primary)]">₹{slab.tax.toLocaleString('en-IN')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Final Tax Summary */}
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
            <div className="px-6 py-4 border-b border-[var(--border)] bg-gradient-to-r from-indigo-500/5 to-transparent">
              <h3 className="font-semibold text-sm text-[var(--text-primary)]">Final Tax Computation</h3>
            </div>
            <div className="p-6 space-y-1">
              <LineItem label="Tax on Total Income" value={fmt(statement.taxOnIncome)} />
              {statement.rebate87A > 0 && <LineItem label="Less: Rebate u/s 87A" value={`(${fmt(statement.rebate87A)})`} green />}
              {statement.surcharge > 0 && <LineItem label="Surcharge" value={fmt(statement.surcharge)} />}
              <LineItem label="Health & Education Cess (4%)" value={fmt(statement.cess)} />
              <div className="my-2 border-t-2 border-[var(--border)]" />
              <LineItem label="Total Tax Liability" value={fmt(statement.totalTaxLiability)} bold />
              <div className="my-2 border-t border-[var(--border)]" />
              <LineItem label="Less: TDS Deducted (Form 16)" value={`(${fmt(statement.tdsDeducted)})`} green />
              {statement.selfAssessmentTax > 0 && <LineItem label="Self Assessment Tax Paid" value={`(${fmt(statement.selfAssessmentTax)})`} green />}
              <div className="my-2 border-t-2 border-indigo-500/20" />
              <LineItem
                label={statement.refundDue < 0 ? 'Tax Payable (Advance Tax / SAT)' : 'Refund Due'}
                value={fmt(statement.refundDue)}
                highlight
                red={statement.refundDue < 0}
                green={statement.refundDue >= 0}
              />
            </div>
          </div>

          {statement.refundDue < 0 && (
            <div className="flex items-start gap-3 p-4 rounded-2xl bg-red-500/10 border border-red-500/20">
              <Info size={16} className="text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-[var(--text-muted)]">
                You have a tax payable of <strong className="text-red-400">{fmt(Math.abs(statement.refundDue))}</strong>. 
                Please pay advance tax or self-assessment tax before the due date to avoid interest u/s 234B & 234C.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
