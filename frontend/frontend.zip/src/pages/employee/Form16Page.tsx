import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  FileText, Download, Calendar, CheckCircle, Clock, Shield,
  Building2, User, IndianRupee, TrendingUp, Eye, Loader2,
  Info, ChevronRight, Printer, ExternalLink
} from 'lucide-react';
import { payrollApi } from '../../api/client';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { Spinner } from '../../components/ui/Spinner';

interface Form16Data {
  financialYear: string;
  status: 'issued' | 'pending' | 'processing';
  partA: {
    totalTaxDeducted: number;
    totalTaxDeposited: number;
    quarters: { quarter: string; amount: number; date: string; status: string }[];
  };
  partB: {
    grossSalary: number;
    exemptions: number;
    standardDeduction: number;
    professionalTax: number;
    taxableIncome: number;
    taxOnIncome: number;
    rebate: number;
    surcharge: number;
    healthEducationCess: number;
    totalTaxPayable: number;
    tdsDeducted: number;
  };
}

// Realistic mock data – in production this comes from payrollApi
const MOCK_FORM16: Form16Data[] = [
  {
    financialYear: 'FY 2025-26',
    status: 'processing',
    partA: {
      totalTaxDeducted: 78450,
      totalTaxDeposited: 58500,
      quarters: [
        { quarter: 'Q1 (Apr–Jun 2025)', amount: 18500, date: '2025-07-15', status: 'deposited' },
        { quarter: 'Q2 (Jul–Sep 2025)', amount: 19250, date: '2025-10-15', status: 'deposited' },
        { quarter: 'Q3 (Oct–Dec 2025)', amount: 20750, date: '2026-01-15', status: 'deposited' },
        { quarter: 'Q4 (Jan–Mar 2026)', amount: 19950, date: '2026-06-15', status: 'pending' },
      ],
    },
    partB: {
      grossSalary: 1200000,
      exemptions: 40000,
      standardDeduction: 50000,
      professionalTax: 2400,
      taxableIncome: 1107600,
      taxOnIncome: 165780,
      rebate: 0,
      surcharge: 0,
      healthEducationCess: 6631,
      totalTaxPayable: 172411,
      tdsDeducted: 78450,
    },
  },
  {
    financialYear: 'FY 2024-25',
    status: 'issued',
    partA: {
      totalTaxDeducted: 62400,
      totalTaxDeposited: 62400,
      quarters: [
        { quarter: 'Q1 (Apr–Jun 2024)', amount: 15200, date: '2024-07-15', status: 'deposited' },
        { quarter: 'Q2 (Jul–Sep 2024)', amount: 15800, date: '2024-10-15', status: 'deposited' },
        { quarter: 'Q3 (Oct–Dec 2024)', amount: 16200, date: '2025-01-15', status: 'deposited' },
        { quarter: 'Q4 (Jan–Mar 2025)', amount: 15200, date: '2025-06-15', status: 'deposited' },
      ],
    },
    partB: {
      grossSalary: 1020000,
      exemptions: 38000,
      standardDeduction: 50000,
      professionalTax: 2400,
      taxableIncome: 929600,
      taxOnIncome: 125160,
      rebate: 0,
      surcharge: 0,
      healthEducationCess: 5006,
      totalTaxPayable: 130166,
      tdsDeducted: 62400,
    },
  },
  {
    financialYear: 'FY 2023-24',
    status: 'issued',
    partA: {
      totalTaxDeducted: 47800,
      totalTaxDeposited: 47800,
      quarters: [
        { quarter: 'Q1 (Apr–Jun 2023)', amount: 11500, date: '2023-07-15', status: 'deposited' },
        { quarter: 'Q2 (Jul–Sep 2023)', amount: 12100, date: '2023-10-15', status: 'deposited' },
        { quarter: 'Q3 (Oct–Dec 2023)', amount: 12400, date: '2024-01-15', status: 'deposited' },
        { quarter: 'Q4 (Jan–Mar 2024)', amount: 11800, date: '2024-06-15', status: 'deposited' },
      ],
    },
    partB: {
      grossSalary: 840000,
      exemptions: 32000,
      standardDeduction: 50000,
      professionalTax: 2400,
      taxableIncome: 755600,
      taxOnIncome: 88680,
      rebate: 12500,
      surcharge: 0,
      healthEducationCess: 3045,
      totalTaxPayable: 79225,
      tdsDeducted: 47800,
    },
  },
];

const STATUS_CFG = {
  issued:     { label: 'Issued',     color: 'bg-green-500/10 text-green-400 border-green-500/20',   icon: CheckCircle },
  processing: { label: 'Processing', color: 'bg-amber-500/10 text-amber-400 border-amber-500/20',   icon: Clock },
  pending:    { label: 'Pending',    color: 'bg-slate-500/10 text-slate-400 border-slate-500/20',    icon: Clock },
};

function fmt(n: number) {
  return '₹' + n.toLocaleString('en-IN');
}

function Section({ title, icon: Icon, children }: { title: string; icon: React.ElementType; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
      <div className="flex items-center gap-3 px-6 py-4 border-b border-[var(--border)] bg-gradient-to-r from-indigo-500/5 to-transparent">
        <div className="p-2 rounded-xl bg-indigo-500/10">
          <Icon size={16} className="text-indigo-400" />
        </div>
        <h3 className="font-semibold text-[var(--text-primary)] text-sm">{title}</h3>
      </div>
      <div className="p-6">{children}</div>
    </div>
  );
}

function LineItem({ label, value, bold, highlight }: { label: string; value: string; bold?: boolean; highlight?: boolean }) {
  return (
    <div className={`flex items-center justify-between py-2.5 border-b border-[var(--border)] last:border-0 ${bold ? 'font-bold' : ''}`}>
      <span className={`text-sm ${bold ? 'text-[var(--text-primary)]' : 'text-[var(--text-muted)]'}`}>{label}</span>
      <span className={`font-mono text-sm ${highlight ? 'text-indigo-400 font-bold text-base' : bold ? 'text-[var(--text-primary)]' : 'text-[var(--text-primary)]'}`}>{value}</span>
    </div>
  );
}

export default function Form16Page() {
  const { user } = useAuthStore();
  const myEmpId = user?.employee?.id || '';
  const [selectedFY, setSelectedFY] = useState<Form16Data>(MOCK_FORM16[0]);
  const [activeTab, setActiveTab] = useState<'overview' | 'partA' | 'partB'>('overview');

  const emp = user?.employee;
  const fullName = emp ? `${emp.firstName} ${emp.lastName}` : 'Employee';

  const handleDownload = () => {
    const content = `FORM 16 - ${selectedFY.financialYear}\nEmployee: ${fullName}\nTDS Deducted: ${fmt(selectedFY.partB.tdsDeducted)}\nTaxable Income: ${fmt(selectedFY.partB.taxableIncome)}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `Form16_${selectedFY.financialYear.replace(' ', '_')}.txt`; a.click();
    URL.revokeObjectURL(url);
  };

  const cfg = STATUS_CFG[selectedFY.status];
  const StatusIcon = cfg.icon;

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="Form 16"
        subtitle="Tax Deduction Certificate issued by your employer"
        icon={FileText}
        actions={
          <button onClick={handleDownload} disabled={selectedFY.status !== 'issued'}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-indigo-500/20">
            <Download size={15} /> Download Form 16
          </button>
        }
      />

      {/* Info Banner */}
      <div className="flex items-start gap-3 p-4 rounded-2xl bg-blue-500/5 border border-blue-500/20">
        <Info size={16} className="text-blue-400 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-[var(--text-muted)]">
          Form 16 is a TDS certificate issued under <strong className="text-[var(--text-primary)]">Section 203 of the Income Tax Act</strong>. 
          It contains details of salary paid and tax deducted at source. Part A shows quarterly TDS; Part B shows income & tax computation.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* FY Selector Sidebar */}
        <div className="lg:col-span-1 space-y-2">
          <div className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wider mb-3">Financial Year</div>
          {MOCK_FORM16.map(fy => {
            const c = STATUS_CFG[fy.status];
            return (
              <button key={fy.financialYear} onClick={() => setSelectedFY(fy)}
                className={`w-full text-left p-4 rounded-2xl border transition-all ${
                  selectedFY.financialYear === fy.financialYear
                    ? 'border-indigo-500/40 bg-indigo-500/10 shadow-lg shadow-indigo-500/5'
                    : 'border-[var(--border)] bg-[var(--surface)] hover:border-indigo-500/20'
                }`}>
                <div className="font-semibold text-sm text-[var(--text-primary)]">{fy.financialYear}</div>
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border mt-1.5 ${c.color}`}>
                  <c.icon size={10} /> {c.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-5">
          {/* Header Card */}
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-indigo-600 via-purple-500 to-blue-500" />
            <div className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Shield size={16} className="text-indigo-400" />
                    <span className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wider">Income Tax Department, India</span>
                  </div>
                  <h2 className="text-xl font-bold text-[var(--text-primary)]">Form 16 – {selectedFY.financialYear}</h2>
                  <p className="text-sm text-[var(--text-muted)] mt-0.5">Certificate of TDS on Salary under Section 203</p>
                </div>
                <span className={`px-3 py-1.5 rounded-full text-xs font-semibold border ${cfg.color}`}>
                  <StatusIcon size={11} className="inline mr-1" />{cfg.label}
                </span>
              </div>

              {/* Employee & Employer info */}
              <div className="grid grid-cols-2 gap-4 mt-5">
                <div className="p-4 rounded-xl bg-[var(--surface-alt)] space-y-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wide">
                    <User size={12} /> Employee
                  </div>
                  <div className="font-semibold text-[var(--text-primary)] text-sm">{fullName}</div>
                  <div className="text-xs text-[var(--text-muted)]">{(emp as any)?.designation?.title || 'Employee'}</div>
                  <div className="text-xs text-[var(--text-muted)] font-mono">{(emp as any)?.employeeCode || '—'}</div>
                </div>
                <div className="p-4 rounded-xl bg-[var(--surface-alt)] space-y-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wide">
                    <Building2 size={12} /> Employer
                  </div>
                  <div className="font-semibold text-[var(--text-primary)] text-sm">Your Company Pvt. Ltd.</div>
                  <div className="text-xs text-[var(--text-muted)]">TAN: DELA12345A</div>
                  <div className="text-xs text-[var(--text-muted)]">PAN: AACCY1234B</div>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 p-1 bg-[var(--surface-alt)] rounded-xl w-fit">
            {([['overview', 'Summary'], ['partA', 'Part A – TDS Quarters'], ['partB', 'Part B – Tax Computation']] as const).map(([key, label]) => (
              <button key={key} onClick={() => setActiveTab(key)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === key ? 'bg-[var(--surface)] text-[var(--text-primary)] shadow-sm' : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
                }`}>
                {label}
              </button>
            ))}
          </div>

          {/* Overview */}
          {activeTab === 'overview' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {[
                { label: 'Gross Salary', value: fmt(selectedFY.partB.grossSalary), icon: IndianRupee, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
                { label: 'Taxable Income', value: fmt(selectedFY.partB.taxableIncome), icon: TrendingUp, color: 'text-amber-400', bg: 'bg-amber-500/10' },
                { label: 'Total Tax Payable', value: fmt(selectedFY.partB.totalTaxPayable), icon: FileText, color: 'text-red-400', bg: 'bg-red-500/10' },
                { label: 'TDS Deducted', value: fmt(selectedFY.partB.tdsDeducted), icon: CheckCircle, color: 'text-green-400', bg: 'bg-green-500/10' },
                { label: 'Standard Deduction', value: fmt(selectedFY.partB.standardDeduction), icon: Shield, color: 'text-purple-400', bg: 'bg-purple-500/10' },
                { label: 'HE Cess (4%)', value: fmt(selectedFY.partB.healthEducationCess), icon: Building2, color: 'text-blue-400', bg: 'bg-blue-500/10' },
              ].map(c => (
                <div key={c.label} className={`${c.bg} border border-[var(--border)] rounded-2xl p-4`}>
                  <div className={`p-1.5 rounded-lg bg-[var(--surface)] w-fit mb-3`}><c.icon size={16} className={c.color} /></div>
                  <div className={`text-xl font-bold font-mono ${c.color}`}>{c.value}</div>
                  <div className="text-xs text-[var(--text-muted)] mt-1">{c.label}</div>
                </div>
              ))}
            </div>
          )}

          {/* Part A */}
          {activeTab === 'partA' && (
            <Section title="Part A – Details of Tax Deducted and Deposited" icon={Calendar}>
              <div className="space-y-3 mb-5">
                {selectedFY.partA.quarters.map(q => (
                  <div key={q.quarter} className="flex items-center gap-4 p-4 rounded-xl bg-[var(--surface-alt)]">
                    <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${q.status === 'deposited' ? 'bg-green-400' : 'bg-amber-400'}`} />
                    <div className="flex-1">
                      <div className="font-medium text-sm text-[var(--text-primary)]">{q.quarter}</div>
                      <div className="text-xs text-[var(--text-muted)] mt-0.5">
                        {q.status === 'deposited' ? `Deposited on ${new Date(q.date).toLocaleDateString('en-IN', { dateStyle: 'medium' })}` : `Due: ${new Date(q.date).toLocaleDateString('en-IN', { dateStyle: 'medium' })}`}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-[var(--text-primary)]">{fmt(q.amount)}</div>
                      <span className={`text-xs ${q.status === 'deposited' ? 'text-green-400' : 'text-amber-400'}`}>
                        {q.status === 'deposited' ? 'Deposited' : 'Pending'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
                <span className="font-semibold text-[var(--text-primary)]">Total TDS Deducted</span>
                <span className="font-mono font-bold text-indigo-400 text-lg">{fmt(selectedFY.partA.totalTaxDeducted)}</span>
              </div>
            </Section>
          )}

          {/* Part B */}
          {activeTab === 'partB' && (
            <Section title="Part B – Income & Tax Computation" icon={IndianRupee}>
              <div className="space-y-1">
                <LineItem label="Gross Salary (as per employer)" value={fmt(selectedFY.partB.grossSalary)} />
                <LineItem label="Less: HRA Exemptions & Others" value={`(${fmt(selectedFY.partB.exemptions)})`} />
                <LineItem label="Less: Standard Deduction (Sec. 16)" value={`(${fmt(selectedFY.partB.standardDeduction)})`} />
                <LineItem label="Less: Professional Tax" value={`(${fmt(selectedFY.partB.professionalTax)})`} />
                <div className="my-2 border-t border-[var(--border)]" />
                <LineItem label="Net Taxable Income" value={fmt(selectedFY.partB.taxableIncome)} bold />
                <div className="my-2 border-t border-[var(--border)]" />
                <LineItem label="Tax on Total Income" value={fmt(selectedFY.partB.taxOnIncome)} />
                {selectedFY.partB.rebate > 0 && <LineItem label="Less: Rebate u/s 87A" value={`(${fmt(selectedFY.partB.rebate)})`} />}
                <LineItem label="Health & Education Cess (4%)" value={fmt(selectedFY.partB.healthEducationCess)} />
                <div className="my-2 border-t-2 border-[var(--border)]" />
                <LineItem label="Total Tax Payable" value={fmt(selectedFY.partB.totalTaxPayable)} bold />
                <LineItem label="TDS Already Deducted" value={fmt(selectedFY.partB.tdsDeducted)} bold highlight />
              </div>
              {selectedFY.partB.totalTaxPayable > selectedFY.partB.tdsDeducted && (
                <div className="mt-4 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-400">
                  ⚠ Balance tax of {fmt(selectedFY.partB.totalTaxPayable - selectedFY.partB.tdsDeducted)} may be payable. Please verify with your CA.
                </div>
              )}
            </Section>
          )}
        </div>
      </div>
    </div>
  );
}
