import { Clock, Command } from 'lucide-react';

export default function ManualPunchPage() {
  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Premium Header */}
      <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="absolute top-0 right-0 p-32 bg-blue-500/10 rounded-bl-full -z-0 blur-2xl"></div>
        <div className="relative z-10 flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-500 shadow-inner">
             <Clock size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--text-primary)] tracking-tight">Manual Punch</h1>
            <p className="text-sm text-[var(--text-muted)] mt-1 font-medium">Manage manual punch configurations and data.</p>
          </div>
        </div>
      </div>

      <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm min-h-[400px]">
        <div className="flex flex-col items-center justify-center h-64 text-[var(--text-muted)]">
           <div className="w-16 h-16 rounded-2xl bg-[var(--surface-alt)] border border-[var(--border)] flex items-center justify-center mb-4">
             <Command size={24} className="animate-spin-slow text-blue-500" />
           </div>
           <p className="text-sm font-bold text-[var(--text-primary)]">Manual Punch</p>
           <p className="text-xs mt-1">This module is currently pending integration.</p>
        </div>
      </div>
    </div>
  );
}
