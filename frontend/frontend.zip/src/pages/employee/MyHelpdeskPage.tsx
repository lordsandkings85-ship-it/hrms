import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Headphones, Plus, Clock, CheckCircle, AlertCircle,
  Loader2, MessageSquare, TicketCheck, Send, Eye, ArrowLeft, Search
} from 'lucide-react';
import { useToast } from '../../components/ui/ToastProvider';
import { useAuthStore } from '../../store/useAuthStore';
import { helpdeskApi } from '../../api/client';
import { PageHeader } from '../../components/ui/PageHeader';

type TicketStatus = 'open' | 'in_progress' | 'resolved' | 'closed';
type TicketPriority = 'low' | 'medium' | 'high' | 'urgent';
type TicketCategory = 'hr' | 'it' | 'payroll' | 'asset' | 'general';
type TabKey = 'new' | 'history';

interface Ticket {
  id: string;
  subject: string;
  description: string;
  status: TicketStatus;
  priority: TicketPriority;
  category: TicketCategory;
  createdAt: string;
  updatedAt: string;
  employeeId?: string;
  employee?: { firstName: string; lastName: string };
}

const STATUS_CONFIG: Record<TicketStatus, { label: string; color: string; icon: React.ElementType }> = {
  open:        { label: 'Open',        color: 'bg-blue-500/10 text-blue-400 border border-blue-500/20',   icon: AlertCircle },
  in_progress: { label: 'In Progress', color: 'bg-amber-500/10 text-amber-400 border border-amber-500/20', icon: Loader2 },
  resolved:    { label: 'Resolved',    color: 'bg-green-500/10 text-green-400 border border-green-500/20', icon: CheckCircle },
  closed:      { label: 'Closed',      color: 'bg-slate-500/10 text-slate-400 border border-slate-500/20', icon: CheckCircle },
};

const PRIORITY_CONFIG: Record<TicketPriority, { label: string; color: string; dot: string }> = {
  low:    { label: 'Low',    color: 'text-slate-400',  dot: 'bg-slate-400' },
  medium: { label: 'Medium', color: 'text-blue-400',   dot: 'bg-blue-400' },
  high:   { label: 'High',   color: 'text-amber-400',  dot: 'bg-amber-400' },
  urgent: { label: 'Urgent', color: 'text-red-400',    dot: 'bg-red-400' },
};

const CATEGORY_LABELS: Record<TicketCategory, string> = {
  hr: 'Human Resources', it: 'IT Support', payroll: 'Payroll',
  asset: 'Assets & Equipment', general: 'General'
};

function StatusBadge({ status }: { status: TicketStatus }) {
  const cfg = STATUS_CONFIG[status];
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${cfg.color}`}>
      <Icon size={11} />
      {cfg.label}
    </span>
  );
}

function PriorityBadge({ priority }: { priority: TicketPriority }) {
  const cfg = PRIORITY_CONFIG[priority];
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${cfg.color}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
      {cfg.label}
    </span>
  );
}

export default function MyHelpdeskPage() {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const { sub } = useParams<{ sub?: string }>();
  const navigate = useNavigate();
  const { success: toastSuccess, error: toastError } = useToast();

  const myEmpId = user?.employee?.id || '';

  const initialTab: TabKey = sub === 'my-tickets' ? 'history' : 'new';
  const [tab, setTab] = useState<TabKey>(initialTab);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<TicketStatus | 'all'>('all');

  // Form state
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<TicketPriority>('medium');
  const [category, setCategory] = useState<TicketCategory>('general');

  const { data: tickets, isLoading } = useQuery({
    queryKey: ['my-tickets', myEmpId],
    queryFn: () => helpdeskApi.list(),
    enabled: !!myEmpId,
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => helpdeskApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-tickets', myEmpId] });
      toastSuccess('Ticket submitted successfully!');
      setSubject(''); setDescription(''); setPriority('medium'); setCategory('general');
      setTab('history');
    },
    onError: (err: any) => toastError(err.message || 'Failed to submit ticket'),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !description.trim()) {
      toastError('Please fill in all required fields'); return;
    }
    createMutation.mutate({ subject, description, priority, category });
  };

  const handleTabChange = (t: TabKey) => {
    setTab(t);
    navigate(t === 'history' ? '/helpdesk/my-tickets' : '/helpdesk');
  };

  const ticketList: Ticket[] = Array.isArray(tickets) ? tickets : [];
  const filtered = ticketList.filter(t => {
    const matchSearch = !searchTerm || t.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'all' || t.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const stats = {
    open: ticketList.filter(t => t.status === 'open').length,
    inProgress: ticketList.filter(t => t.status === 'in_progress').length,
    resolved: ticketList.filter(t => t.status === 'resolved').length,
    total: ticketList.length,
  };

  if (selectedTicket) {
    return (
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        <button onClick={() => setSelectedTicket(null)}
          className="inline-flex items-center gap-2 text-sm text-[var(--text-muted)] hover:text-[var(--text-primary)] transition-colors mb-2">
          <ArrowLeft size={16} /> Back to tickets
        </button>
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
          <div className="p-6 border-b border-[var(--border)]">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="text-lg font-semibold text-[var(--text-primary)]">{selectedTicket.subject}</h2>
                <p className="text-sm text-[var(--text-muted)] mt-1">{CATEGORY_LABELS[selectedTicket.category]}</p>
              </div>
              <StatusBadge status={selectedTicket.status} />
            </div>
          </div>
          <div className="p-6 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><label className="text-xs text-[var(--text-muted)] uppercase tracking-wide">Priority</label>
                <div className="mt-1"><PriorityBadge priority={selectedTicket.priority} /></div>
              </div>
              <div><label className="text-xs text-[var(--text-muted)] uppercase tracking-wide">Ticket ID</label>
                <div className="mt-1 text-sm font-mono text-[var(--text-primary)]">#{selectedTicket.id.slice(0, 8).toUpperCase()}</div>
              </div>
              <div><label className="text-xs text-[var(--text-muted)] uppercase tracking-wide">Submitted</label>
                <div className="mt-1 text-sm text-[var(--text-primary)]">{new Date(selectedTicket.createdAt).toLocaleDateString('en-IN', { dateStyle: 'long' })}</div>
              </div>
              <div><label className="text-xs text-[var(--text-muted)] uppercase tracking-wide">Last Updated</label>
                <div className="mt-1 text-sm text-[var(--text-primary)]">{new Date(selectedTicket.updatedAt).toLocaleDateString('en-IN', { dateStyle: 'long' })}</div>
              </div>
            </div>
            <div>
              <label className="text-xs text-[var(--text-muted)] uppercase tracking-wide">Description</label>
              <div className="mt-2 p-4 rounded-xl bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] leading-relaxed">{selectedTicket.description}</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="Helpdesk"
        subtitle="Get support, raise tickets, and track your requests"
        icon={Headphones}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total Tickets', value: stats.total, color: 'text-[var(--text-primary)]', bg: 'bg-[var(--surface)]' },
          { label: 'Open', value: stats.open, color: 'text-blue-400', bg: 'bg-blue-500/5' },
          { label: 'In Progress', value: stats.inProgress, color: 'text-amber-400', bg: 'bg-amber-500/5' },
          { label: 'Resolved', value: stats.resolved, color: 'text-green-400', bg: 'bg-green-500/5' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} border border-[var(--border)] rounded-2xl p-4`}>
            <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-xs text-[var(--text-muted)] mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-[var(--surface-alt)] rounded-xl w-fit">
        {([['new', 'Raise a Ticket', Plus], ['history', 'My Tickets', TicketCheck]] as [TabKey, string, React.ElementType][]).map(([key, label, Icon]) => (
          <button key={key} onClick={() => handleTabChange(key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === key ? 'bg-[var(--surface)] text-[var(--text-primary)] shadow-sm' : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
            }`}>
            <Icon size={15} /> {label}
          </button>
        ))}
      </div>

      {/* New Ticket Form */}
      {tab === 'new' && (
        <div className="max-w-2xl">
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
            <div className="px-6 py-4 border-b border-[var(--border)] bg-gradient-to-r from-indigo-500/5 to-transparent">
              <h3 className="font-semibold text-[var(--text-primary)]">Submit a New Ticket</h3>
              <p className="text-sm text-[var(--text-muted)] mt-0.5">Describe your issue and our team will respond shortly</p>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Subject <span className="text-red-400">*</span></label>
                <input value={subject} onChange={e => setSubject(e.target.value)} required
                  placeholder="Brief description of your issue..."
                  className="w-full px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Category</label>
                  <select value={category} onChange={e => setCategory(e.target.value as TicketCategory)}
                    className="w-full px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all">
                    {Object.entries(CATEGORY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Priority</label>
                  <select value={priority} onChange={e => setPriority(e.target.value as TicketPriority)}
                    className="w-full px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all">
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Description <span className="text-red-400">*</span></label>
                <textarea value={description} onChange={e => setDescription(e.target.value)} required rows={5}
                  placeholder="Provide detailed information about your issue..."
                  className="w-full px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all resize-none" />
              </div>
              <button type="submit" disabled={createMutation.isPending}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-indigo-500/20">
                {createMutation.isPending ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
                {createMutation.isPending ? 'Submitting...' : 'Submit Ticket'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Ticket History */}
      {tab === 'history' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-52">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
              <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                placeholder="Search tickets..."
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40" />
            </div>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40">
              <option value="all">All Status</option>
              <option value="open">Open</option>
              <option value="in_progress">In Progress</option>
              <option value="resolved">Resolved</option>
              <option value="closed">Closed</option>
            </select>
          </div>
          {isLoading ? (
            <div className="flex items-center justify-center h-40 text-[var(--text-muted)]">
              <Loader2 size={20} className="animate-spin mr-2" /> Loading tickets...
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 gap-3 text-[var(--text-muted)]">
              <MessageSquare size={32} className="opacity-30" />
              <p className="text-sm">{ticketList.length === 0 ? 'No tickets yet — raise your first one!' : 'No tickets match your filters'}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map(ticket => (
                <div key={ticket.id} className="flex items-center gap-4 p-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] hover:border-indigo-500/30 transition-all">
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm text-[var(--text-primary)] truncate">{ticket.subject}</div>
                    <div className="text-xs text-[var(--text-muted)] mt-0.5">{CATEGORY_LABELS[ticket.category]} · {new Date(ticket.createdAt).toLocaleDateString('en-IN', { dateStyle: 'medium' })}</div>
                  </div>
                  <PriorityBadge priority={ticket.priority} />
                  <StatusBadge status={ticket.status} />
                  <button onClick={() => setSelectedTicket(ticket)}
                    className="inline-flex items-center gap-1 text-xs text-indigo-400 hover:text-indigo-300 transition-colors flex-shrink-0">
                    <Eye size={13} /> View
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
