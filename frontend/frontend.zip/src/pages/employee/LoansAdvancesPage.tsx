import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  IndianRupee, CreditCard, Plus, CheckCircle, Clock, AlertTriangle,
  TrendingDown, FileText, Loader2, ChevronDown, X, Calendar,
  Wallet, BarChart3, ArrowDownLeft, ArrowUpRight, Send, Eye, ArrowLeft
} from 'lucide-react';
import { expensesApi } from '../../api/client';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { useToast } from '../../components/ui/ToastProvider';

type TabKey = 'overview' | 'loans' | 'advances' | 'apply';
type RequestType = 'loan' | 'advance';

const STATUS_CFG = {
  pending:   { label: 'Pending',   color: 'bg-amber-500/10 text-amber-400 border-amber-500/20',   icon: Clock },
  approved:  { label: 'Approved',  color: 'bg-green-500/10 text-green-400 border-green-500/20',   icon: CheckCircle },
  rejected:  { label: 'Rejected',  color: 'bg-red-500/10 text-red-400 border-red-500/20',         icon: AlertTriangle },
  active:    { label: 'Active',    color: 'bg-blue-500/10 text-blue-400 border-blue-500/20',       icon: ArrowDownLeft },
  closed:    { label: 'Closed',    color: 'bg-slate-500/10 text-slate-400 border-slate-500/20',    icon: CheckCircle },
};

interface LoanRecord {
  id: string;
  type: 'loan' | 'advance';
  purpose: string;
  amount: number;
  emi?: number;
  emiMonths?: number;
  amountRepaid?: number;
  balance?: number;
  status: keyof typeof STATUS_CFG;
  appliedOn: string;
  approvedOn?: string;
  nextEmiDate?: string;
}

const MOCK_LOANS: LoanRecord[] = [
  {
    id: '1', type: 'loan', purpose: 'Medical Emergency', amount: 150000, emi: 12500,
    emiMonths: 12, amountRepaid: 37500, balance: 112500, status: 'active',
    appliedOn: '2026-01-10', approvedOn: '2026-01-15', nextEmiDate: '2026-08-01',
  },
  {
    id: '2', type: 'advance', purpose: 'Festival Advance – Diwali', amount: 30000,
    amountRepaid: 30000, balance: 0, status: 'closed',
    appliedOn: '2025-10-01', approvedOn: '2025-10-05',
  },
  {
    id: '3', type: 'loan', purpose: 'Vehicle Purchase', amount: 80000, emi: 6667,
    emiMonths: 12, amountRepaid: 0, balance: 80000, status: 'pending',
    appliedOn: '2026-07-20',
  },
];

function StatusBadge({ status }: { status: keyof typeof STATUS_CFG }) {
  const cfg = STATUS_CFG[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${cfg.color}`}>
      <cfg.icon size={11} />
      {cfg.label}
    </span>
  );
}

function ProgressBar({ value, max }: { value: number; max: number }) {
  const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0;
  return (
    <div className="h-2 bg-[var(--surface-alt)] rounded-full overflow-hidden">
      <div className="h-full bg-indigo-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
    </div>
  );
}

export default function LoansAdvancesPage() {
  const { user } = useAuthStore();
  const { success: toastSuccess, error: toastError } = useToast();
  const myEmpId = user?.employee?.id || '';

  const [tab, setTab] = useState<TabKey>('overview');
  const [requestType, setRequestType] = useState<RequestType>('advance');
  const [selectedRecord, setSelectedRecord] = useState<LoanRecord | null>(null);

  // Apply form state
  const [purpose, setPurpose] = useState('');
  const [amount, setAmount] = useState('');
  const [repayMonths, setRepayMonths] = useState('12');
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loans = MOCK_LOANS;
  const activeLoans = loans.filter(l => l.type === 'loan' && l.status === 'active');
  const advances = loans.filter(l => l.type === 'advance');
  const totalOutstanding = loans.filter(l => l.status === 'active').reduce((s, l) => s + (l.balance || 0), 0);
  const totalRepaid = loans.reduce((s, l) => s + (l.amountRepaid || 0), 0);

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!purpose || !amount || Number(amount) < 1000) { toastError('Please fill all fields. Minimum amount ₹1,000'); return; }
    setIsSubmitting(true);
    await new Promise(r => setTimeout(r, 1500));
    setIsSubmitting(false);
    toastSuccess(`${requestType === 'loan' ? 'Loan' : 'Salary Advance'} request submitted successfully`);
    setPurpose(''); setAmount(''); setReason(''); setTab('overview');
  };

  if (selectedRecord) {
    const r = selectedRecord;
    return (
      <div className="p-6 max-w-2xl mx-auto space-y-6">
        <button onClick={() => setSelectedRecord(null)} className="inline-flex items-center gap-2 text-sm text-[var(--text-muted)] hover:text-[var(--text-primary)] transition-colors">
          <ArrowLeft size={16} /> Back
        </button>
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-indigo-600 to-purple-500" />
          <div className="p-6 border-b border-[var(--border)]">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-xs text-[var(--text-muted)] uppercase tracking-wide mb-1">{r.type === 'loan' ? 'Salary Loan' : 'Salary Advance'}</div>
                <h2 className="text-xl font-bold text-[var(--text-primary)]">{r.purpose}</h2>
                <p className="text-sm text-[var(--text-muted)] mt-1">Applied on {new Date(r.appliedOn).toLocaleDateString('en-IN', { dateStyle: 'long' })}</p>
              </div>
              <StatusBadge status={r.status} />
            </div>
          </div>
          <div className="p-6 space-y-5">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { label: 'Sanctioned Amount', value: '₹' + r.amount.toLocaleString('en-IN'), color: 'text-indigo-400' },
                { label: 'Amount Repaid', value: '₹' + (r.amountRepaid || 0).toLocaleString('en-IN'), color: 'text-green-400' },
                { label: 'Outstanding Balance', value: '₹' + (r.balance || 0).toLocaleString('en-IN'), color: r.balance ? 'text-amber-400' : 'text-green-400' },
                ...(r.emi ? [{ label: 'Monthly EMI', value: '₹' + r.emi.toLocaleString('en-IN'), color: 'text-[var(--text-primary)]' }] : []),
                ...(r.emiMonths ? [{ label: 'Repayment Period', value: `${r.emiMonths} months`, color: 'text-[var(--text-primary)]' }] : []),
                ...(r.nextEmiDate ? [{ label: 'Next EMI Date', value: new Date(r.nextEmiDate).toLocaleDateString('en-IN', { dateStyle: 'medium' }), color: 'text-blue-400' }] : []),
              ].map(item => (
                <div key={item.label} className="p-3 rounded-xl bg-[var(--surface-alt)]">
                  <div className="text-xs text-[var(--text-muted)]">{item.label}</div>
                  <div className={`font-bold font-mono mt-1 ${item.color}`}>{item.value}</div>
                </div>
              ))}
            </div>
            {r.type === 'loan' && r.balance !== undefined && r.amount > 0 && (
              <div>
                <div className="flex justify-between text-xs text-[var(--text-muted)] mb-2">
                  <span>Repayment Progress</span>
                  <span>{Math.round(((r.amountRepaid || 0) / r.amount) * 100)}%</span>
                </div>
                <ProgressBar value={r.amountRepaid || 0} max={r.amount} />
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  const TABS: [TabKey, string, React.ElementType][] = [
    ['overview', 'Overview', BarChart3],
    ['loans', 'My Loans', CreditCard],
    ['advances', 'My Advances', Wallet],
    ['apply', 'Apply', Plus],
  ];

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="Loans & Salary Advances"
        subtitle="Apply for salary loans, track repayments, and manage advances"
        icon={IndianRupee}
      />

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Active Loans', value: activeLoans.length, icon: CreditCard, color: 'text-indigo-400', bg: 'bg-indigo-500/5' },
          { label: 'Outstanding', value: '₹' + totalOutstanding.toLocaleString('en-IN'), icon: TrendingDown, color: 'text-red-400', bg: 'bg-red-500/5' },
          { label: 'Total Repaid', value: '₹' + totalRepaid.toLocaleString('en-IN'), icon: CheckCircle, color: 'text-green-400', bg: 'bg-green-500/5' },
          { label: 'Total Requests', value: loans.length, icon: FileText, color: 'text-amber-400', bg: 'bg-amber-500/5' },
        ].map(c => (
          <div key={c.label} className={`${c.bg} border border-[var(--border)] rounded-2xl p-4 flex items-center gap-3`}>
            <div className="p-2 rounded-xl bg-[var(--surface)]"><c.icon size={18} className={c.color} /></div>
            <div>
              <div className={`text-xl font-bold font-mono ${c.color}`}>{c.value}</div>
              <div className="text-xs text-[var(--text-muted)] mt-0.5">{c.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-[var(--surface-alt)] rounded-xl w-fit flex-wrap">
        {TABS.map(([key, label, Icon]) => (
          <button key={key} onClick={() => setTab(key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === key ? 'bg-[var(--surface)] text-[var(--text-primary)] shadow-sm' : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
            }`}>
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === 'overview' && (
        <div className="space-y-4">
          <div className="grid gap-4">
            {loans.map(record => (
              <div key={record.id} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 hover:border-indigo-500/30 transition-all">
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${record.type === 'loan' ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' : 'bg-purple-500/10 text-purple-400 border-purple-500/20'}`}>
                        {record.type === 'loan' ? 'Salary Loan' : 'Salary Advance'}
                      </span>
                    </div>
                    <h4 className="font-semibold text-[var(--text-primary)]">{record.purpose}</h4>
                    <p className="text-xs text-[var(--text-muted)] mt-0.5">Applied: {new Date(record.appliedOn).toLocaleDateString('en-IN', { dateStyle: 'medium' })}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <StatusBadge status={record.status} />
                    <button onClick={() => setSelectedRecord(record)} className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-indigo-400 hover:bg-indigo-500/10 transition-all">
                      <Eye size={15} />
                    </button>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm mb-3">
                  <span className="text-[var(--text-muted)]">₹{(record.amountRepaid || 0).toLocaleString('en-IN')} repaid of ₹{record.amount.toLocaleString('en-IN')}</span>
                  <span className="font-mono font-bold text-[var(--text-primary)]">{Math.round(((record.amountRepaid || 0) / record.amount) * 100)}%</span>
                </div>
                {record.type === 'loan' && <ProgressBar value={record.amountRepaid || 0} max={record.amount} />}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Loans List */}
      {tab === 'loans' && (
        <div className="space-y-3">
          {loans.filter(l => l.type === 'loan').length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 gap-3 text-[var(--text-muted)]">
              <CreditCard size={32} className="opacity-30" />
              <p className="text-sm">No loans on record</p>
            </div>
          ) : loans.filter(l => l.type === 'loan').map(record => (
            <div key={record.id} className="flex items-center gap-4 p-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] hover:border-indigo-500/30 transition-all">
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm text-[var(--text-primary)]">{record.purpose}</div>
                <div className="text-xs text-[var(--text-muted)] mt-0.5">
                  ₹{record.amount.toLocaleString('en-IN')} · EMI ₹{record.emi?.toLocaleString('en-IN')} × {record.emiMonths} months
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono font-bold text-amber-400 text-sm">₹{(record.balance || 0).toLocaleString('en-IN')}</div>
                <div className="text-xs text-[var(--text-muted)]">outstanding</div>
              </div>
              <StatusBadge status={record.status} />
            </div>
          ))}
        </div>
      )}

      {/* Advances List */}
      {tab === 'advances' && (
        <div className="space-y-3">
          {loans.filter(l => l.type === 'advance').length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 gap-3 text-[var(--text-muted)]">
              <Wallet size={32} className="opacity-30" />
              <p className="text-sm">No advance requests on record</p>
            </div>
          ) : loans.filter(l => l.type === 'advance').map(record => (
            <div key={record.id} className="flex items-center gap-4 p-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] hover:border-indigo-500/30 transition-all">
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm text-[var(--text-primary)]">{record.purpose}</div>
                <div className="text-xs text-[var(--text-muted)] mt-0.5">Applied: {new Date(record.appliedOn).toLocaleDateString('en-IN', { dateStyle: 'medium' })}</div>
              </div>
              <div className="font-mono font-bold text-[var(--text-primary)]">₹{record.amount.toLocaleString('en-IN')}</div>
              <StatusBadge status={record.status} />
            </div>
          ))}
        </div>
      )}

      {/* Apply Form */}
      {tab === 'apply' && (
        <div className="max-w-2xl">
          {/* Type Selector */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            {([['advance', 'Salary Advance', Wallet, 'Quick advance on your salary. Recovered in 1–3 months.'],
               ['loan', 'Salary Loan', CreditCard, 'Larger loan amount with structured EMI repayment.']] as const).map(([type, label, Icon, desc]) => (
              <button key={type} onClick={() => setRequestType(type)}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  requestType === type
                    ? 'border-indigo-500/40 bg-indigo-500/10 shadow-lg shadow-indigo-500/5'
                    : 'border-[var(--border)] bg-[var(--surface)] hover:border-indigo-500/20'
                }`}>
                <Icon size={20} className={`mb-2 ${requestType === type ? 'text-indigo-400' : 'text-[var(--text-muted)]'}`} />
                <div className={`font-semibold text-sm ${requestType === type ? 'text-indigo-400' : 'text-[var(--text-primary)]'}`}>{label}</div>
                <div className="text-xs text-[var(--text-muted)] mt-1 leading-relaxed">{desc}</div>
              </button>
            ))}
          </div>

          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
            <div className="px-6 py-4 border-b border-[var(--border)] bg-gradient-to-r from-indigo-500/5 to-transparent">
              <h3 className="font-semibold text-[var(--text-primary)]">Apply for {requestType === 'loan' ? 'Salary Loan' : 'Salary Advance'}</h3>
              <p className="text-sm text-[var(--text-muted)] mt-0.5">Your request will be reviewed by HR within 2–3 working days</p>
            </div>
            <form onSubmit={handleApply} className="p-6 space-y-5">
              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Purpose <span className="text-red-400">*</span></label>
                <select value={purpose} onChange={e => setPurpose(e.target.value)} required
                  className="w-full px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40">
                  <option value="">Select purpose...</option>
                  {(requestType === 'advance'
                    ? ['Festival Advance', 'Medical Emergency', 'Travel Expenses', 'Educational Fees', 'Personal Emergency', 'Other']
                    : ['Medical Emergency', 'Vehicle Purchase', 'Home Renovation', 'Educational Loan', 'Wedding Expenses', 'Other']
                  ).map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div className={`grid gap-4 ${requestType === 'loan' ? 'grid-cols-2' : 'grid-cols-1'}`}>
                <div>
                  <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Amount (₹) <span className="text-red-400">*</span></label>
                  <input type="number" value={amount} onChange={e => setAmount(e.target.value)} required min="1000"
                    placeholder={requestType === 'loan' ? 'e.g. 100000' : 'e.g. 25000'}
                    className="w-full px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40" />
                </div>
                {requestType === 'loan' && (
                  <div>
                    <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Repayment (Months)</label>
                    <select value={repayMonths} onChange={e => setRepayMonths(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40">
                      {[3, 6, 9, 12, 18, 24].map(m => <option key={m} value={m}>{m} months</option>)}
                    </select>
                  </div>
                )}
              </div>

              {amount && Number(amount) > 0 && requestType === 'loan' && (
                <div className="p-4 rounded-xl bg-indigo-500/5 border border-indigo-500/20">
                  <div className="text-xs text-[var(--text-muted)] mb-1">Estimated Monthly EMI</div>
                  <div className="text-2xl font-bold font-mono text-indigo-400">
                    ₹{Math.ceil(Number(amount) / Number(repayMonths)).toLocaleString('en-IN')}
                  </div>
                  <div className="text-xs text-[var(--text-muted)] mt-1">Deducted from salary over {repayMonths} months</div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Reason / Supporting Details</label>
                <textarea value={reason} onChange={e => setReason(e.target.value)} rows={3}
                  placeholder="Briefly explain your requirement..."
                  className="w-full px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 resize-none" />
              </div>
              <button type="submit" disabled={isSubmitting}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-indigo-500/20">
                {isSubmitting ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
                {isSubmitting ? 'Submitting...' : `Submit ${requestType === 'loan' ? 'Loan' : 'Advance'} Request`}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
