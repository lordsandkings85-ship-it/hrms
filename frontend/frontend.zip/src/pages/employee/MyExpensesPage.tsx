import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Receipt, FileUp, IndianRupee, Send, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { expensesApi } from '../../api/client';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { Spinner } from '../../components/ui/Spinner';
import { useToast } from '../../components/ui/ToastProvider';

export default function MyExpensesPage() {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const myEmpId = user?.employee?.id || '';
  const { success: toastSuccess, error: toastError } = useToast();

  const [category, setCategory] = useState('travel');
  const [amount, setAmount] = useState('');
  const [receiptUrl, setReceiptUrl] = useState('');

  // Fetch expenses for this employee
  const { data: expenses, isLoading } = useQuery({
    queryKey: ['my-expenses-list', myEmpId],
    queryFn: () => expensesApi.listForEmployee(myEmpId),
    enabled: !!myEmpId,
  });

  // Submit Expense
  const submitExpenseMutation = useMutation({
    mutationFn: expensesApi.submit,
    onSuccess: () => {
      toastSuccess('Expense claim registered successfully!');
      setAmount('');
      setReceiptUrl('');
      queryClient.invalidateQueries({ queryKey: ['my-expenses-list', myEmpId] });
    },
    onError: (err: any) => toastError(err.message || 'Failed to submit expense'),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount.trim()) return toastError('Please enter an amount');
    submitExpenseMutation.mutate({
      employeeId: myEmpId,
      category,
      amount: Number(amount),
      receiptUrl,
    });
  };

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="Claims & Reimbursements"
        subtitle="Submit expense reports, upload receipts, and check reimbursement statuses."
        icon={Receipt}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Submit Claim form */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 h-fit space-y-4">
          <h3 className="text-sm font-bold text-[var(--text-primary)] flex items-center gap-2 border-b border-[var(--border)] pb-3">
            <Receipt className="text-indigo-500" size={16} /> Submit Claim
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none"
              >
                <option value="travel">Travel</option>
                <option value="accommodation">Accommodation</option>
                <option value="food">Meals / Food</option>
                <option value="fuel">Fuel &amp; Transport</option>
                <option value="office">Office Supplies</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">Amount (₹)</label>
              <input
                type="number"
                placeholder="₹0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none font-mono"
                required
              />
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">Receipt URL</label>
              <input
                type="text"
                placeholder="https://storage.hrms.internal/..."
                value={receiptUrl}
                onChange={(e) => setReceiptUrl(e.target.value)}
                className="w-full bg-[var(--surface-alt)] text-xs text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={submitExpenseMutation.isPending}
              className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-indigo-500/20"
            >
              <Send size={15} /> {submitExpenseMutation.isPending ? 'Submitting...' : 'Submit Claim'}
            </button>
          </form>
        </div>

        {/* Expenses List */}
        <div className="lg:col-span-2 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 h-fit space-y-4">
          <h3 className="text-sm font-bold text-[var(--text-primary)] flex items-center gap-2 border-b border-[var(--border)] pb-3">
            <Receipt className="text-indigo-500" size={16} /> Claims Registry
          </h3>

          {isLoading ? (
            <div className="flex justify-center py-6"><Spinner /></div>
          ) : !expenses || expenses.length === 0 ? (
            <p className="text-xs text-[var(--text-muted)] py-8 text-center">No expense claims filed yet.</p>
          ) : (
            <div className="divide-y divide-[var(--border)]">
              {expenses.map((exp: any) => {
                const statusColors: Record<string, { badge: string, icon: React.ElementType }> = {
                  pending: { badge: 'bg-amber-500/10 text-amber-500 border-amber-500/20', icon: Clock },
                  approved: { badge: 'bg-green-500/10 text-green-400 border-green-500/20', icon: CheckCircle2 },
                  rejected: { badge: 'bg-red-500/10 text-red-400 border-red-500/20', icon: XCircle }
                };
                const cfg = statusColors[exp.status] || { badge: 'bg-slate-550/10 text-slate-400 border-slate-500/20', icon: Clock };
                const StatusIcon = cfg.icon;
                return (
                  <div key={exp.id} className="py-4 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="p-2.5 bg-indigo-500/10 rounded-xl text-indigo-400 shrink-0">
                        <IndianRupee size={16} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-[var(--text-primary)] capitalize truncate">
                          {exp.category}
                        </div>
                        <div className="text-xs text-[var(--text-muted)] mt-0.5">
                          Submitted on {new Date(exp.createdAt).toLocaleDateString('en-IN')}
                          {exp.receiptUrl && (
                            <a
                              href={exp.receiptUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-indigo-400 ml-2 hover:underline inline-flex items-center gap-0.5"
                            >
                              Receipt <FileUp size={10} />
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0 flex items-center gap-3">
                      <span className="font-mono font-bold text-[var(--text-primary)]">₹{exp.amount.toLocaleString('en-IN')}</span>
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${cfg.badge}`}>
                        <StatusIcon size={10} />
                        {exp.status}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
