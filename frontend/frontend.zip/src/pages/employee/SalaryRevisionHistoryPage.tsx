import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  TrendingUp, IndianRupee, ArrowUpRight, Calendar, Download,
  Award, ChevronRight, BarChart3, Clock, CheckCircle, Building2,
  Sparkles, Info, User, Briefcase, Loader2
} from 'lucide-react';
import { payrollApi } from '../../api/client';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { Spinner } from '../../components/ui/Spinner';

interface SalaryRevision {
  id: string;
  effectiveFrom: string;
  revisedCTC: number;
  previousCTC: number;
  incrementAmount: number;
  incrementPercent: number;
  reason: 'annual_appraisal' | 'promotion' | 'market_correction' | 'performance_bonus' | 'joining';
  remarks?: string;
  approvedBy?: string;
  components: {
    label: string;
    previous: number;
    revised: number;
  }[];
}

const REASON_CFG = {
  annual_appraisal: { label: 'Annual Appraisal', color: 'bg-blue-500/10 text-blue-400 border-blue-500/20', icon: Award },
  promotion: { label: 'Promotion', color: 'bg-purple-500/10 text-purple-400 border-purple-500/20', icon: Sparkles },
  market_correction: { label: 'Market Correction', color: 'bg-amber-500/10 text-amber-400 border-amber-500/20', icon: BarChart3 },
  performance_bonus: { label: 'Performance Bonus', color: 'bg-green-500/10 text-green-400 border-green-500/20', icon: CheckCircle },
  joining: { label: 'Joining CTC', color: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20', icon: User },
};

const MOCK_REVISIONS: SalaryRevision[] = [
  {
    id: '1',
    effectiveFrom: '2026-04-01',
    revisedCTC: 1440000,
    previousCTC: 1200000,
    incrementAmount: 240000,
    incrementPercent: 20.0,
    reason: 'annual_appraisal',
    remarks: 'Exceptional performance in FY 2025-26. Promoted to Senior level.',
    approvedBy: 'Priya Sharma (HR Manager)',
    components: [
      { label: 'Basic Pay', previous: 480000, revised: 576000 },
      { label: 'HRA', previous: 192000, revised: 230400 },
      { label: 'Special Allowance', previous: 348000, revised: 417600 },
      { label: 'PF Employer', previous: 57600, revised: 69120 },
      { label: 'Gratuity', previous: 27692, revised: 33231 },
      { label: 'Medical Allowance', previous: 15000, revised: 18000 },
      { label: 'Conveyance', previous: 19200, revised: 19200 },
    ],
  },
  {
    id: '2',
    effectiveFrom: '2025-10-01',
    revisedCTC: 1200000,
    previousCTC: 1080000,
    incrementAmount: 120000,
    incrementPercent: 11.1,
    reason: 'market_correction',
    remarks: 'Mid-year market correction to align with industry benchmarks.',
    approvedBy: 'Amit Kumar (Director)',
    components: [
      { label: 'Basic Pay', previous: 432000, revised: 480000 },
      { label: 'HRA', previous: 172800, revised: 192000 },
      { label: 'Special Allowance', previous: 312480, revised: 348000 },
      { label: 'PF Employer', previous: 51840, revised: 57600 },
      { label: 'Gratuity', previous: 24923, revised: 27692 },
      { label: 'Medical Allowance', previous: 15000, revised: 15000 },
      { label: 'Conveyance', previous: 19200, revised: 19200 },
    ],
  },
  {
    id: '3',
    effectiveFrom: '2025-04-01',
    revisedCTC: 1080000,
    previousCTC: 960000,
    incrementAmount: 120000,
    incrementPercent: 12.5,
    reason: 'annual_appraisal',
    remarks: 'FY 2024-25 annual increment. Rating: 4.2/5.',
    approvedBy: 'Priya Sharma (HR Manager)',
    components: [
      { label: 'Basic Pay', previous: 384000, revised: 432000 },
      { label: 'HRA', previous: 153600, revised: 172800 },
      { label: 'Special Allowance', previous: 278400, revised: 312480 },
      { label: 'PF Employer', previous: 46080, revised: 51840 },
      { label: 'Gratuity', previous: 22154, revised: 24923 },
      { label: 'Medical Allowance', previous: 15000, revised: 15000 },
      { label: 'Conveyance', previous: 19200, revised: 19200 },
    ],
  },
  {
    id: '4',
    effectiveFrom: '2024-04-01',
    revisedCTC: 960000,
    previousCTC: 840000,
    incrementAmount: 120000,
    incrementPercent: 14.3,
    reason: 'promotion',
    remarks: 'Promoted from Junior to Mid-level. Salary revised accordingly.',
    approvedBy: 'Amit Kumar (Director)',
    components: [
      { label: 'Basic Pay', previous: 336000, revised: 384000 },
      { label: 'HRA', previous: 134400, revised: 153600 },
      { label: 'Special Allowance', previous: 241920, revised: 278400 },
      { label: 'PF Employer', previous: 40320, revised: 46080 },
      { label: 'Gratuity', previous: 19385, revised: 22154 },
      { label: 'Medical Allowance', previous: 15000, revised: 15000 },
      { label: 'Conveyance', previous: 19200, revised: 19200 },
    ],
  },
  {
    id: '5',
    effectiveFrom: '2023-06-01',
    revisedCTC: 840000,
    previousCTC: 0,
    incrementAmount: 840000,
    incrementPercent: 0,
    reason: 'joining',
    remarks: 'Joining CTC as per offer letter.',
    approvedBy: 'Priya Sharma (HR Manager)',
    components: [
      { label: 'Basic Pay', previous: 0, revised: 336000 },
      { label: 'HRA', previous: 0, revised: 134400 },
      { label: 'Special Allowance', previous: 0, revised: 241920 },
      { label: 'PF Employer', previous: 0, revised: 40320 },
      { label: 'Gratuity', previous: 0, revised: 19385 },
      { label: 'Medical Allowance', previous: 0, revised: 15000 },
      { label: 'Conveyance', previous: 0, revised: 19200 },
    ],
  },
];

function pctColor(pct: number) {
  if (pct >= 20) return 'text-green-400';
  if (pct >= 10) return 'text-blue-400';
  return 'text-amber-400';
}

export default function SalaryRevisionHistoryPage() {
  const { user } = useAuthStore();
  const [selected, setSelected] = useState<SalaryRevision | null>(null);

  const revisions = MOCK_REVISIONS;
  const latestCTC = revisions[0]?.revisedCTC || 0;
  const joiningCTC = revisions[revisions.length - 1]?.revisedCTC || 0;
  const totalGrowth = joiningCTC > 0 ? ((latestCTC - joiningCTC) / joiningCTC * 100).toFixed(1) : '0';
  const avgIncrement = revisions.filter(r => r.reason !== 'joining').length > 0
    ? (revisions.filter(r => r.reason !== 'joining').reduce((s, r) => s + r.incrementPercent, 0) / revisions.filter(r => r.reason !== 'joining').length).toFixed(1)
    : '0';

  const emp = user?.employee;

  if (selected) {
    const cfg = REASON_CFG[selected.reason];
    return (
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        <button onClick={() => setSelected(null)} className="inline-flex items-center gap-2 text-sm text-[var(--text-muted)] hover:text-[var(--text-primary)] transition-colors">
          ← Back to History
        </button>

        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
          <div className="h-1.5 bg-gradient-to-r from-indigo-600 to-purple-500" />
          <div className="p-6 border-b border-[var(--border)]">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${cfg.color} mb-2`}>
                  <cfg.icon size={11} /> {cfg.label}
                </span>
                <h2 className="text-xl font-bold text-[var(--text-primary)]">
                  Salary Revision – {new Date(selected.effectiveFrom).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}
                </h2>
                <p className="text-sm text-[var(--text-muted)] mt-0.5">Effective from {new Date(selected.effectiveFrom).toLocaleDateString('en-IN', { dateStyle: 'long' })}</p>
              </div>
              {selected.reason !== 'joining' && (
                <div className="text-right flex-shrink-0">
                  <div className={`text-3xl font-black font-mono ${pctColor(selected.incrementPercent)}`}>+{selected.incrementPercent.toFixed(1)}%</div>
                  <div className="text-xs text-[var(--text-muted)]">Increment</div>
                </div>
              )}
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* CTC Comparison */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-[var(--surface-alt)]">
                <div className="text-xs text-[var(--text-muted)] mb-1">Previous CTC</div>
                <div className="font-mono font-bold text-[var(--text-primary)]">
                  {selected.reason === 'joining' ? '—' : '₹' + selected.previousCTC.toLocaleString('en-IN')}
                </div>
              </div>
              <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
                <div className="text-xs text-indigo-400 mb-1">Revised CTC</div>
                <div className="font-mono font-bold text-indigo-400">₹{selected.revisedCTC.toLocaleString('en-IN')}</div>
              </div>
              <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20">
                <div className="text-xs text-green-400 mb-1">Annual Increment</div>
                <div className="font-mono font-bold text-green-400">
                  {selected.reason === 'joining' ? 'Offer CTC' : '+₹' + selected.incrementAmount.toLocaleString('en-IN')}
                </div>
              </div>
            </div>

            {/* Component-wise Breakup */}
            <div>
              <div className="text-sm font-semibold text-[var(--text-primary)] mb-3">Salary Structure Breakup</div>
              <div className="rounded-xl overflow-hidden border border-[var(--border)]">
                <table className="w-full text-sm">
                  <thead className="bg-[var(--surface-alt)]">
                    <tr>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-[var(--text-muted)] uppercase">Component</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-[var(--text-muted)] uppercase">Previous (Annual)</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-[var(--text-muted)] uppercase">Revised (Annual)</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-[var(--text-muted)] uppercase">Change</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selected.components.map((comp, i) => {
                      const diff = comp.revised - comp.previous;
                      return (
                        <tr key={i} className="border-t border-[var(--border)] hover:bg-[var(--surface-alt)] transition-colors">
                          <td className="px-4 py-3 text-[var(--text-primary)]">{comp.label}</td>
                          <td className="px-4 py-3 text-right font-mono text-[var(--text-muted)]">
                            {comp.previous > 0 ? '₹' + comp.previous.toLocaleString('en-IN') : '—'}
                          </td>
                          <td className="px-4 py-3 text-right font-mono font-semibold text-[var(--text-primary)]">₹{comp.revised.toLocaleString('en-IN')}</td>
                          <td className="px-4 py-3 text-right font-mono font-semibold">
                            {diff > 0 ? (
                              <span className="text-green-400">+₹{diff.toLocaleString('en-IN')}</span>
                            ) : <span className="text-[var(--text-muted)]">—</span>}
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="border-t-2 border-indigo-500/20 bg-indigo-500/5">
                      <td className="px-4 py-3 font-bold text-[var(--text-primary)]">Total CTC</td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-[var(--text-muted)]">
                        {selected.reason === 'joining' ? '—' : '₹' + selected.previousCTC.toLocaleString('en-IN')}
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-indigo-400">₹{selected.revisedCTC.toLocaleString('en-IN')}</td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-green-400">
                        {selected.reason !== 'joining' ? '+₹' + selected.incrementAmount.toLocaleString('en-IN') : '—'}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Remarks */}
            {selected.remarks && (
              <div className="p-4 rounded-xl bg-[var(--surface-alt)] border border-[var(--border)]">
                <div className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wider mb-2">Remarks</div>
                <p className="text-sm text-[var(--text-primary)]">{selected.remarks}</p>
                {selected.approvedBy && (
                  <p className="text-xs text-[var(--text-muted)] mt-2">Approved by: <span className="font-medium text-[var(--text-primary)]">{selected.approvedBy}</span></p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="Salary Revision History"
        subtitle="Track your complete salary growth journey since joining"
        icon={TrendingUp}
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Current CTC', value: '₹' + latestCTC.toLocaleString('en-IN'), icon: IndianRupee, color: 'text-indigo-400', bg: 'bg-indigo-500/5' },
          { label: 'Total Revisions', value: revisions.length.toString(), icon: Calendar, color: 'text-blue-400', bg: 'bg-blue-500/5' },
          { label: 'Career Growth', value: `+${totalGrowth}%`, icon: TrendingUp, color: 'text-green-400', bg: 'bg-green-500/5' },
          { label: 'Avg. Increment', value: `${avgIncrement}%`, icon: BarChart3, color: 'text-amber-400', bg: 'bg-amber-500/5' },
        ].map(c => (
          <div key={c.label} className={`${c.bg} border border-[var(--border)] rounded-2xl p-4 flex items-center gap-3`}>
            <div className="p-2 rounded-xl bg-[var(--surface)]"><c.icon size={18} className={c.color} /></div>
            <div>
              <div className={`text-xl font-bold font-mono ${c.color}`}>{c.value}</div>
              <div className="text-xs text-[var(--text-muted)] mt-0.5">{c.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* CTC Growth Timeline */}
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6">
        <h3 className="font-semibold text-sm text-[var(--text-primary)] mb-5">CTC Growth Timeline</h3>
        <div className="relative">
          {/* Bar Chart */}
          <div className="flex items-end gap-3 h-40 mb-2">
            {[...revisions].reverse().map((rev, i, arr) => {
              const maxCTC = Math.max(...arr.map(r => r.revisedCTC));
              const height = Math.round((rev.revisedCTC / maxCTC) * 100);
              const isLatest = i === arr.length - 1;
              return (
                <div key={rev.id} className="flex-1 flex flex-col items-center gap-1 cursor-pointer" onClick={() => setSelected(rev)}>
                  <div className="text-xs font-mono font-semibold text-[var(--text-muted)] truncate w-full text-center">
                    ₹{(rev.revisedCTC / 100000).toFixed(1)}L
                  </div>
                  <div className={`w-full rounded-t-lg transition-all hover:opacity-80 ${isLatest ? 'bg-indigo-500' : 'bg-indigo-500/30'}`}
                    style={{ height: `${height}%` }} />
                  <div className="text-xs text-[var(--text-muted)] text-center leading-tight">
                    {new Date(rev.effectiveFrom).toLocaleDateString('en-IN', { month: 'short', year: '2-digit' })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Revision List */}
      <div className="space-y-3">
        <div className="text-sm font-semibold text-[var(--text-muted)] uppercase tracking-wider">All Revisions</div>
        {revisions.map((rev, idx) => {
          const cfg = REASON_CFG[rev.reason];
          const isLatest = idx === 0;
          return (
            <div key={rev.id} onClick={() => setSelected(rev)}
              className={`flex items-center gap-4 p-5 rounded-2xl border cursor-pointer transition-all ${
                isLatest ? 'border-indigo-500/30 bg-indigo-500/5 hover:border-indigo-500/50' : 'border-[var(--border)] bg-[var(--surface)] hover:border-indigo-500/20'
              }`}>
              <div className={`p-2.5 rounded-xl ${cfg.color.split(' ').slice(0, 2).join(' ')} border ${cfg.color.split(' ')[2]} flex-shrink-0`}>
                <cfg.icon size={16} className={cfg.color.split(' ')[1]} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-semibold text-sm text-[var(--text-primary)]">
                    {new Date(rev.effectiveFrom).toLocaleDateString('en-IN', { dateStyle: 'long' })}
                  </span>
                  {isLatest && <span className="px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 text-xs border border-indigo-500/20">Latest</span>}
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full border ${cfg.color}`}>{cfg.label}</span>
                {rev.remarks && <div className="text-xs text-[var(--text-muted)] mt-1 truncate">{rev.remarks}</div>}
              </div>
              <div className="text-right flex-shrink-0">
                <div className="font-mono font-bold text-[var(--text-primary)]">₹{rev.revisedCTC.toLocaleString('en-IN')}</div>
                {rev.reason !== 'joining' && (
                  <div className={`text-sm font-bold font-mono ${pctColor(rev.incrementPercent)}`}>+{rev.incrementPercent.toFixed(1)}%</div>
                )}
              </div>
              <ChevronRight size={16} className="text-[var(--text-muted)] flex-shrink-0" />
            </div>
          );
        })}
      </div>
    </div>
  );
}
