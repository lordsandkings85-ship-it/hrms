import { useState } from 'react';
import {
  Shield, PlusCircle, Edit3, CheckCircle, Clock, AlertTriangle,
  IndianRupee, Home, Heart, GraduationCap, Building2, TrendingUp,
  Loader2, Info, Save, ChevronDown, ChevronUp, Calculator, Send
} from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { useToast } from '../../components/ui/ToastProvider';

interface InvestmentItem {
  id: string;
  section: string;
  category: string;
  description: string;
  maxLimit: number;
  declaredAmount: number;
  proofSubmitted: boolean;
}

const INVESTMENT_SECTIONS: { section: string; icon: React.ElementType; color: string; bg: string; limit: number; items: Omit<InvestmentItem, 'id' | 'declaredAmount' | 'proofSubmitted'>[] }[] = [
  {
    section: '80C – Investments & Savings',
    icon: Shield,
    color: 'text-indigo-400',
    bg: 'bg-indigo-500/10',
    limit: 150000,
    items: [
      { section: '80C', category: 'PPF', description: 'Public Provident Fund', maxLimit: 150000 },
      { section: '80C', category: 'ELSS', description: 'Equity Linked Savings Scheme', maxLimit: 150000 },
      { section: '80C', category: 'LIC', description: 'Life Insurance Premium', maxLimit: 150000 },
      { section: '80C', category: 'NSC', description: 'National Savings Certificate', maxLimit: 150000 },
      { section: '80C', category: 'EPF', description: 'Employee Provident Fund', maxLimit: 150000 },
      { section: '80C', category: 'Home Loan Principal', description: 'Principal repayment of home loan', maxLimit: 150000 },
      { section: '80C', category: 'Tuition Fees', description: 'Children tuition fees (up to 2 children)', maxLimit: 150000 },
    ],
  },
  {
    section: '80D – Health Insurance',
    icon: Heart,
    color: 'text-rose-400',
    bg: 'bg-rose-500/10',
    limit: 75000,
    items: [
      { section: '80D', category: 'Self & Family', description: 'Health insurance for self, spouse & children', maxLimit: 25000 },
      { section: '80D', category: 'Parents', description: 'Health insurance for parents (below 60)', maxLimit: 25000 },
      { section: '80D', category: 'Senior Parents', description: 'Health insurance for senior citizen parents', maxLimit: 50000 },
    ],
  },
  {
    section: '80CCD(1B) – NPS',
    icon: TrendingUp,
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    limit: 50000,
    items: [
      { section: '80CCD(1B)', category: 'NPS Contribution', description: 'National Pension System (additional contribution)', maxLimit: 50000 },
    ],
  },
  {
    section: '80E – Education Loan Interest',
    icon: GraduationCap,
    color: 'text-blue-400',
    bg: 'bg-blue-500/10',
    limit: 999999,
    items: [
      { section: '80E', category: 'Education Loan', description: 'Interest on education loan (no upper limit)', maxLimit: 999999 },
    ],
  },
  {
    section: '24B – Home Loan Interest',
    icon: Home,
    color: 'text-purple-400',
    bg: 'bg-purple-500/10',
    limit: 200000,
    items: [
      { section: '24B', category: 'Home Loan Interest', description: 'Interest on home loan for self-occupied property', maxLimit: 200000 },
    ],
  },
  {
    section: '80G – Donations',
    icon: Building2,
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    limit: 999999,
    items: [
      { section: '80G', category: 'Charitable Donations', description: 'Donations to approved institutions (50%–100% deduction)', maxLimit: 999999 },
    ],
  },
];

const CURRENT_FY = 'FY 2025-26';
const DEADLINE = 'January 31, 2026';
const STATUS = 'draft'; // draft | submitted | approved

export default function InvestmentDeclarationPage() {
  const { user } = useAuthStore();
  const { success: toastSuccess, error: toastError } = useToast();

  const [declarations, setDeclarations] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    INVESTMENT_SECTIONS.forEach(s => s.items.forEach(item => { init[`${item.section}_${item.category}`] = 0; }));
    init['80C_EPF'] = 21600;
    init['80C_LIC'] = 35000;
    init['80D_Self & Family'] = 18000;
    init['80CCD(1B)_NPS Contribution'] = 50000;
    return init;
  });

  const [expanded, setExpanded] = useState<Record<string, boolean>>({ '80C – Investments & Savings': true });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [proofStatus, setProofStatus] = useState<Record<string, boolean>>({ '80C_EPF': true, '80D_Self & Family': true });

  const totalDeclared = Object.values(declarations).reduce((s, v) => s + v, 0);

  // Tax estimate (simplified)
  const grossSalary = 1200000;
  const standardDeduction = 50000;
  const totalDeductions = Math.min(
    (declarations['80C_PPF'] || 0) + (declarations['80C_ELSS'] || 0) + (declarations['80C_LIC'] || 0) +
    (declarations['80C_NSC'] || 0) + (declarations['80C_EPF'] || 0) + (declarations['80C_Home Loan Principal'] || 0) +
    (declarations['80C_Tuition Fees'] || 0), 150000
  ) + Math.min((declarations['80D_Self & Family'] || 0) + (declarations['80D_Parents'] || 0) + (declarations['80D_Senior Parents'] || 0), 75000)
    + Math.min(declarations['80CCD(1B)_NPS Contribution'] || 0, 50000);

  const taxableIncome = Math.max(grossSalary - standardDeduction - totalDeductions, 0);
  const estimatedTax = taxableIncome <= 250000 ? 0 :
    taxableIncome <= 500000 ? (taxableIncome - 250000) * 0.05 :
    taxableIncome <= 1000000 ? 12500 + (taxableIncome - 500000) * 0.2 :
    112500 + (taxableIncome - 1000000) * 0.3;
  const monthlyTDS = Math.round((estimatedTax * 1.04) / 12);

  const handleAmountChange = (key: string, val: string) => {
    setDeclarations(prev => ({ ...prev, [key]: Math.max(0, Number(val)) }));
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    await new Promise(r => setTimeout(r, 1500));
    setIsSubmitting(false);
    toastSuccess('Investment Declaration submitted successfully!');
  };

  const toggleSection = (section: string) => setExpanded(prev => ({ ...prev, [section]: !prev[section] }));

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="Investment Declaration"
        subtitle={`${CURRENT_FY} · Submit your investment proofs for TDS computation`}
        icon={Shield}
        actions={
          <button onClick={handleSubmit} disabled={isSubmitting}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-indigo-500/20">
            {isSubmitting ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
            {isSubmitting ? 'Submitting...' : 'Submit Declaration'}
          </button>
        }
      />

      {/* Alert */}
      <div className="flex items-start gap-3 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20">
        <AlertTriangle size={16} className="text-amber-400 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-[var(--text-muted)]">
          Last date to submit investment declarations: <strong className="text-amber-400">{DEADLINE}</strong>. 
          Submission after deadline will result in higher TDS deduction. Please ensure proof documents are uploaded.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Declarations Form */}
        <div className="lg:col-span-2 space-y-4">
          {INVESTMENT_SECTIONS.map(sec => {
            const secTotal = sec.items.reduce((s, item) => s + (declarations[`${item.section}_${item.category}`] || 0), 0);
            const cappedTotal = Math.min(secTotal, sec.limit);
            const isExpanded = expanded[sec.section];

            return (
              <div key={sec.section} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
                <button onClick={() => toggleSection(sec.section)}
                  className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--surface-alt)] transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl ${sec.bg}`}><sec.icon size={16} className={sec.color} /></div>
                    <div className="text-left">
                      <div className="font-semibold text-sm text-[var(--text-primary)]">{sec.section}</div>
                      <div className="text-xs text-[var(--text-muted)]">
                        Max: {sec.limit === 999999 ? 'No Limit' : '₹' + sec.limit.toLocaleString('en-IN')}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className={`font-mono font-bold text-sm ${sec.limit !== 999999 && secTotal > sec.limit ? 'text-red-400' : sec.color}`}>
                        ₹{cappedTotal.toLocaleString('en-IN')}
                      </div>
                      {sec.limit !== 999999 && secTotal > sec.limit && (
                        <div className="text-xs text-red-400">Capped at limit</div>
                      )}
                    </div>
                    {isExpanded ? <ChevronUp size={16} className="text-[var(--text-muted)]" /> : <ChevronDown size={16} className="text-[var(--text-muted)]" />}
                  </div>
                </button>

                {isExpanded && (
                  <div className="border-t border-[var(--border)] divide-y divide-[var(--border)]">
                    {sec.items.map(item => {
                      const key = `${item.section}_${item.category}`;
                      const val = declarations[key] || 0;
                      return (
                        <div key={key} className="flex items-center gap-4 px-5 py-4">
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm text-[var(--text-primary)]">{item.category}</div>
                            <div className="text-xs text-[var(--text-muted)] mt-0.5">{item.description}</div>
                            {item.maxLimit !== 999999 && <div className="text-xs text-[var(--text-muted)]">Max: ₹{item.maxLimit.toLocaleString('en-IN')}</div>}
                          </div>
                          <div className="flex items-center gap-2 flex-shrink-0">
                            {proofStatus[key] && (
                              <span className="text-xs text-green-400 flex items-center gap-1">
                                <CheckCircle size={11} /> Proof
                              </span>
                            )}
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)] text-sm">₹</span>
                              <input
                                type="number"
                                value={val || ''}
                                onChange={e => handleAmountChange(key, e.target.value)}
                                placeholder="0"
                                min="0"
                                max={item.maxLimit !== 999999 ? item.maxLimit : undefined}
                                className="w-32 pl-7 pr-3 py-2 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-primary)] text-sm text-right font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Tax Summary Sidebar */}
        <div className="space-y-4">
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden sticky top-6">
            <div className="px-5 py-4 border-b border-[var(--border)] bg-gradient-to-r from-indigo-500/5 to-transparent">
              <div className="flex items-center gap-2">
                <Calculator size={16} className="text-indigo-400" />
                <h3 className="font-semibold text-sm text-[var(--text-primary)]">Live Tax Estimate</h3>
              </div>
              <p className="text-xs text-[var(--text-muted)] mt-0.5">Updates as you fill declarations</p>
            </div>
            <div className="p-5 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-[var(--text-muted)]">Gross Salary</span>
                <span className="font-mono font-medium text-[var(--text-primary)]">₹{grossSalary.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[var(--text-muted)]">Standard Deduction</span>
                <span className="font-mono text-green-400">(₹50,000)</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[var(--text-muted)]">Total Investments</span>
                <span className="font-mono text-green-400">(₹{totalDeductions.toLocaleString('en-IN')})</span>
              </div>
              <div className="border-t border-[var(--border)] pt-3">
                <div className="flex justify-between text-sm font-semibold">
                  <span className="text-[var(--text-primary)]">Taxable Income</span>
                  <span className="font-mono text-[var(--text-primary)]">₹{taxableIncome.toLocaleString('en-IN')}</span>
                </div>
              </div>
              <div className="flex justify-between text-sm font-semibold">
                <span className="text-[var(--text-primary)]">Estimated Tax</span>
                <span className="font-mono text-amber-400">₹{Math.round(estimatedTax).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-sm font-bold">
                <span className="text-[var(--text-primary)]">+ Health & Ed. Cess</span>
                <span className="font-mono text-[var(--text-primary)]">₹{Math.round(estimatedTax * 0.04).toLocaleString('en-IN')}</span>
              </div>
              <div className="border-t-2 border-indigo-500/30 pt-3">
                <div className="flex justify-between font-bold">
                  <span className="text-[var(--text-primary)]">Monthly TDS</span>
                  <span className="font-mono text-indigo-400 text-lg">₹{monthlyTDS.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>

            {/* Investment Summary */}
            <div className="border-t border-[var(--border)] p-5 space-y-3">
              <div className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wider">Declared Investments</div>
              {INVESTMENT_SECTIONS.map(sec => {
                const secTotal = sec.items.reduce((s, item) => s + (declarations[`${item.section}_${item.category}`] || 0), 0);
                if (secTotal === 0) return null;
                const cappedTotal = Math.min(secTotal, sec.limit);
                return (
                  <div key={sec.section} className="flex items-center justify-between text-xs">
                    <span className="text-[var(--text-muted)] truncate mr-2">{sec.section.split('–')[0].trim()}</span>
                    <span className={`font-mono font-medium flex-shrink-0 ${sec.color}`}>₹{cappedTotal.toLocaleString('en-IN')}</span>
                  </div>
                );
              })}
              <div className="border-t border-[var(--border)] pt-2 flex justify-between text-sm font-bold">
                <span className="text-[var(--text-primary)]">Total Savings</span>
                <span className="font-mono text-green-400">₹{totalDeductions.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
