import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Fingerprint, Clock, FileText, CheckCircle, AlertCircle, Play, Square, RefreshCw, Sparkles, Send, Award
} from 'lucide-react';
import { attendanceApi, attendanceApiExt } from '../../api/client';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { Spinner } from '../../components/ui/Spinner';
import { useToast } from '../../components/ui/ToastProvider';

type TabKey = 'checkin' | 'regularize';

const SUB_TO_TAB: Record<string, TabKey> = {
  daily: 'checkin',
  regularization: 'regularize'
};

const TAB_TO_SUB: Record<TabKey, string> = {
  checkin: 'daily',
  regularize: 'regularization'
};

export default function MyAttendancePage() {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const { sub } = useParams<{ sub?: string }>();
  const navigate = useNavigate();
  const { success: toastSuccess, error: toastError } = useToast();

  const myEmpId = user?.employee?.id || '';
  const initialTab = sub ? SUB_TO_TAB[sub] || 'checkin' : 'checkin';
  const [tab, setTab] = useState<TabKey>(initialTab);

  const [currentYear] = useState(new Date().getFullYear());
  const [currentMonth] = useState(new Date().getMonth() + 1);

  // Regularization state
  const [selectedLogId, setSelectedLogId] = useState('');
  const [regularizeReason, setRegularizeReason] = useState('');

  useEffect(() => {
    if (sub && SUB_TO_TAB[sub]) {
      setTab(SUB_TO_TAB[sub]);
    }
  }, [sub]);

  const handleTabChange = (t: TabKey) => {
    setTab(t);
    navigate(`/attendance/${TAB_TO_SUB[t]}`);
  };

  // Queries
  const { data: todayLogs } = useQuery({
    queryKey: ['attendance-today', myEmpId],
    queryFn: async () => {
      const today = new Date();
      const tzOffset = today.getTimezoneOffset() * 60000;
      const localISODate = new Date(today.getTime() - tzOffset).toISOString().split('T')[0];
      return await attendanceApi.list(myEmpId, localISODate, localISODate) || [];
    },
    enabled: !!myEmpId
  });

  const { data: historyLogs, isLoading: isLoadingHistory } = useQuery({
    queryKey: ['attendance-history', myEmpId],
    queryFn: async () => {
      const today = new Date();
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
      const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().split('T')[0];
      return await attendanceApi.list(myEmpId, firstDay, lastDay) || [];
    },
    enabled: !!myEmpId
  });



  // Check check-in status
  const activeLog = todayLogs?.find((log: any) => !log.checkOut);
  const isCheckedIn = !!activeLog;

  // Mutations
  const checkInMutation = useMutation({
    mutationFn: () => attendanceApi.checkIn({ employeeId: myEmpId, method: 'WEB' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['attendance-today', myEmpId] });
      queryClient.invalidateQueries({ queryKey: ['attendance-history', myEmpId] });
      queryClient.invalidateQueries({ queryKey: ['attendance-summary', myEmpId] });
      toastSuccess('Successfully Checked In');
    },
    onError: (err: any) => toastError(err.message || 'Failed to check in'),
  });

  const checkOutMutation = useMutation({
    mutationFn: (logId: string) => attendanceApi.checkOut(logId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['attendance-today', myEmpId] });
      queryClient.invalidateQueries({ queryKey: ['attendance-history', myEmpId] });
      queryClient.invalidateQueries({ queryKey: ['attendance-summary', myEmpId] });
      toastSuccess('Successfully Checked Out');
    },
    onError: (err: any) => toastError(err.message || 'Failed to check out'),
  });

  const regularizeMutation = useMutation({
    mutationFn: ({ logId, reason }: { logId: string; reason: string }) => 
      attendanceApiExt.regularize(logId, reason),
    onSuccess: () => {
      toastSuccess('Regularization request submitted successfully!');
      setSelectedLogId('');
      setRegularizeReason('');
      queryClient.invalidateQueries({ queryKey: ['attendance-history', myEmpId] });
      handleTabChange('checkin');
    },
    onError: (err: any) => toastError(err.message || 'Failed to submit regularization'),
  });

  const handleRegularizeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLogId || !regularizeReason) {
      toastError('Please fill in all fields');
      return;
    }
    regularizeMutation.mutate({ logId: selectedLogId, reason: regularizeReason });
  };

  return (
    <div className="p-6 space-y-6">
      <PageHeader 
        title="Attendance & Check-in" 
        subtitle="Manage daily shifts, request attendance regularization, and track hours."
        icon={Fingerprint}
      />

      {/* Stats Summary Cards Removed - Now in dedicated View Attendance Page */}

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-[var(--surface-alt)] rounded-xl w-fit flex-wrap">
        {([
          ['checkin', 'Daily Check-in', Play],
          ['regularize', 'Regularization', RefreshCw]
        ] as const).map(([key, label, Icon]) => (
          <button key={key} onClick={() => handleTabChange(key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === key ? 'bg-[var(--surface)] text-[var(--text-primary)] shadow-sm' : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
            }`}>
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* Check-in panel */}
        {tab === 'checkin' && (
          <div className="max-w-md mx-auto w-full rounded-2xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden p-6 text-center space-y-6">
            <div className="relative w-28 h-28 bg-indigo-500/10 rounded-full flex items-center justify-center mx-auto">
              <Fingerprint size={48} className={isCheckedIn ? 'text-green-400' : 'text-indigo-400'} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[var(--text-primary)]">{isCheckedIn ? 'You are Checked In' : 'Ready to Start Work?'}</h3>
              <p className="text-sm text-[var(--text-muted)] mt-1">
                {isCheckedIn 
                  ? `Shift started at ${activeLog?.checkIn ? new Date(activeLog.checkIn).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—'}`
                  : 'Check in to record your shift timings for today.'}
              </p>
            </div>
            <div>
              {isCheckedIn ? (
                <button
                  onClick={() => checkOutMutation.mutate(activeLog.id)}
                  disabled={checkOutMutation.isPending}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-red-650 hover:bg-red-500 text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-red-500/20"
                >
                  <Square size={16} /> Check Out Now
                </button>
              ) : (
                <button
                  onClick={() => checkInMutation.mutate()}
                  disabled={checkInMutation.isPending}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-indigo-500/20"
                >
                  <Play size={16} /> Check In Now
                </button>
              )}
            </div>
          </div>
        )}



        {/* Regularize */}
        {tab === 'regularize' && (
          <div className="max-w-xl mx-auto w-full rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-5">
            <h3 className="text-sm font-bold text-[var(--text-primary)] border-b border-[var(--border)] pb-3 flex items-center gap-2">
              <RefreshCw size={16} className="text-indigo-500" /> Attendance Regularization
            </h3>
            <form onSubmit={handleRegularizeSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">Select Date to Regularize</label>
                <select
                  value={selectedLogId}
                  onChange={(e) => setSelectedLogId(e.target.value)}
                  className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none"
                  required
                >
                  <option value="">Choose log entry...</option>
                  {historyLogs?.map((log: any) => (
                    <option key={log.id} value={log.id}>
                      {new Date(log.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })} (In: {log.checkIn ? new Date(log.checkIn).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'Missed'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">Reason for Regularization</label>
                <textarea
                  rows={4}
                  value={regularizeReason}
                  onChange={(e) => setRegularizeReason(e.target.value)}
                  placeholder="Explain why the regularization is required (e.g. client meeting, network issue, forgot check-in)..."
                  className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none resize-none"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={regularizeMutation.isPending}
                className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-indigo-500/20"
              >
                <Send size={15} /> Submit Request
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
