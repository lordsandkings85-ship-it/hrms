import { useQuery } from '@tanstack/react-query';
import { shiftsApi, employeesApi } from '../../api/client';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { Spinner } from '../../components/ui/Spinner';
import { Clock3, CalendarDays, Sun } from 'lucide-react';

const formatTime12 = (time24: string) => {
  if (!time24) return '';
  const [h, m] = time24.split(':');
  let hour = parseInt(h, 10);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  hour = hour % 12;
  hour = hour ? hour : 12;
  return `${hour.toString().padStart(2, '0')}:${m} ${ampm}`;
};

export default function MyShiftsPage() {
  const { user } = useAuthStore();
  const myEmpId = user?.employee?.id || '';

  // Fetch employee record to extract shifts
  const { data: emp, isLoading: isLoadingEmp } = useQuery({
    queryKey: ['my-profile', myEmpId],
    queryFn: () => employeesApi.get(myEmpId),
    enabled: !!myEmpId
  });

  // Fetch holidays
  const { data: holidays, isLoading: isLoadingHolidays } = useQuery({
    queryKey: ['holidays-list'],
    queryFn: () => shiftsApi.listHolidays(),
  });

  const activeAssignment = (emp as any)?.shiftAssignments?.find((sa: any) => !sa.effectiveTo || new Date(sa.effectiveTo) > new Date());
  const activeShift = activeAssignment?.shift;

  return (
    <div className="page-container max-w-5xl space-y-6">
      <PageHeader
        title="My Work Schedule & Shifts"
        subtitle="Review your roster plan, working hours, and calendar of holidays."
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Active Shift Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
            <Clock3 className="text-indigo-500" size={16} /> Active Roster Plan
          </h3>

          {isLoadingEmp ? (
            <div className="flex justify-center py-6"><Spinner /></div>
          ) : activeShift ? (
            <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-850 rounded-xl space-y-3">
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Shift Name</p>
                <p className="text-lg font-extrabold text-slate-800 dark:text-slate-200 mt-0.5">{activeShift.name}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Timings</p>
                  <p className="text-sm font-bold text-indigo-500 font-mono mt-0.5">
                    {formatTime12(activeShift.startTime)} - {formatTime12(activeShift.endTime)}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Schedule Type</p>
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-300 capitalize mt-0.5">{activeShift.type}</p>
                </div>
              </div>
              <div className="text-[10px] text-slate-400 font-semibold border-t border-slate-200/50 dark:border-slate-800/50 pt-2 flex items-center gap-1">
                <CalendarDays size={12} />
                <span>Effective Date: {new Date(activeAssignment.effectiveFrom).toLocaleDateString('en-IN')}</span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">No active work shift assigned. Default organization hours apply.</p>
          )}
        </div>

        {/* Holidays Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
            <Sun className="text-indigo-500" size={16} /> Calendar Holidays List
          </h3>

          {isLoadingHolidays ? (
            <div className="flex justify-center py-6"><Spinner /></div>
          ) : !holidays || holidays.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No company holidays defined yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800/80 max-h-60 overflow-y-auto pr-1">
              {holidays.map((h: any) => (
                <div key={h.id} className="py-2.5 flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-700 dark:text-slate-300">{h.name}</span>
                  <span className="font-mono font-semibold text-slate-400">{new Date(h.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
