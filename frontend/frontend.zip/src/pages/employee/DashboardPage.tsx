import { useAuthStore } from '../../store/useAuthStore';
import AdminDashboard from '../../components/admin/AdminDashboard';
import HrDashboard from '../../components/hr/HrDashboard';
import EmployeeDashboard from '../../components/employee/EmployeeDashboard';

export default function DashboardPage() {
  const { user } = useAuthStore();

  if (!user) {
    return <div className="p-8">Loading dashboard...</div>;
  }

  const roleName = user.role?.name?.toLowerCase() || '';

  // Super Admin / System Admin -> AdminDashboard
  if (user.isSuperAdmin || user.role?.isSystem || roleName === 'super admin' || roleName === 'system admin' || roleName === 'admin') {
    return <AdminDashboard />;
  }

  // HR Manager / Line Manager -> HrDashboard
  if (roleName.includes('hr') || roleName.includes('human resource') || roleName.includes('manager')) {
    return <HrDashboard />;
  }

  // Otherwise, default to the Employee Dashboard
  return <EmployeeDashboard />;
}

