import { useState } from 'react';
import { PageHeader } from '../../components/ui/PageHeader';
import { Calendar, CheckCircle2, RefreshCw } from 'lucide-react';
import { useToast } from '../../components/ui/ToastProvider';

export default function MyFlexibleHolidayPage() {
  const { success, error } = useToast();
  const [selectedHolidayId, setSelectedHolidayId] = useState('');

  const [flexibleHolidays] = useState([
    { id: '1', name: 'Optional Holiday - Raksha Bandhan', date: '2026-08-28' },
    { id: '2', name: 'Optional Holiday - Guru Nanak Jayanti', date: '2026-11-24' },
    { id: '3', name: 'Optional Holiday - Christmas Eve', date: '2026-12-24' }
  ]);

  const [requests] = useState([
    { id: 'req-1', name: 'Optional Holiday - Easter Monday', date: '2026-04-06', status: 'approved' }
  ]);

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHolidayId) {
      error('Please select a flexible holiday.');
      return;
    }
    const holiday = flexibleHolidays.find(h => h.id === selectedHolidayId);
    success(`Flexible holiday request for "${holiday?.name}" submitted successfully!`);
    setSelectedHolidayId('');
  };

  return (
    <div className="page-container max-w-4xl space-y-6">
      <PageHeader
        title="Flexible / Optional Holidays"
        subtitle="Submit selection requests for restricted/optional holidays from the approved corporate schedule."
        icon={Calendar}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Selection Form */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-bold text-[var(--text-primary)] border-b border-[var(--border)] pb-3 flex items-center gap-2">
            <Calendar size={16} className="text-indigo-500" /> Apply Restricted Holiday
          </h3>

          <form onSubmit={handleApply} className="space-y-4 pt-2">
            <div>
              <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">Select Optional Holiday</label>
              <select
                value={selectedHolidayId}
                onChange={(e) => setSelectedHolidayId(e.target.value)}
                className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2.5 mt-1 rounded-lg border border-[var(--border)] focus:outline-none"
                required
              >
                <option value="">Choose holiday option...</option>
                {flexibleHolidays.map((h) => (
                  <option key={h.id} value={h.id}>
                    {h.name} ({new Date(h.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })})
                  </option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-medium transition-all shadow-md shadow-indigo-500/20"
            >
              Request Holiday Leave
            </button>
          </form>
        </div>

        {/* Status Tracker */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-4 shadow-xs">
          <h3 className="text-sm font-bold text-[var(--text-primary)] border-b border-[var(--border)] pb-3">
            Selection Status History
          </h3>

          <div className="divide-y divide-[var(--border)]">
            {requests.map((r) => (
              <div key={r.id} className="py-3 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-[var(--text-primary)]">{r.name}</div>
                  <div className="text-[11px] text-[var(--text-muted)] mt-0.5">
                    Date: {new Date(r.date).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}
                  </div>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border bg-green-500/10 text-green-400 border-green-500/20 flex items-center gap-1">
                    <CheckCircle2 size={10} /> {r.status}
                  </span>
                </div>
              </div>
            ))}
            {requests.length === 0 && (
              <p className="text-xs text-[var(--text-muted)] text-center py-6">No previous restriction selections recorded.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
