import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Calendar, FileText, CheckCircle, Clock, Search, Download, 
  MapPin, Sparkles, Filter 
} from 'lucide-react';
import { attendanceApi } from '../../api/client';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { Spinner } from '../../components/ui/Spinner';

export default function MyCustomAttendancePage() {
  const { user } = useAuthStore();
  const myEmpId = user?.employee?.id || '';

  const today = new Date();
  const [fromDate, setFromDate] = useState(
    new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0]
  );
  const [toDate, setToDate] = useState(
    new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().split('T')[0]
  );

  const { data: logs, isLoading } = useQuery({
    queryKey: ['attendance-custom', myEmpId, fromDate, toDate],
    queryFn: () => attendanceApi.list(myEmpId, fromDate, toDate),
    enabled: !!myEmpId && !!fromDate && !!toDate,
  });

  const getStatusConfig = (status: string, regularizationStatus?: string) => {
    if (regularizationStatus === 'approved') return { label: 'Regularized', color: 'text-blue-400', bg: 'bg-blue-500/10' };
    if (regularizationStatus === 'pending') return { label: 'Pending Regularization', color: 'text-amber-400', bg: 'bg-amber-500/10' };
    
    switch(status) {
      case 'present': return { label: 'Present', color: 'text-green-400', bg: 'bg-green-500/10' };
      case 'late': return { label: 'Late', color: 'text-amber-400', bg: 'bg-amber-500/10' };
      case 'half_day': return { label: 'Half Day', color: 'text-indigo-400', bg: 'bg-indigo-500/10' };
      case 'on_leave': return { label: 'On Leave', color: 'text-purple-400', bg: 'bg-purple-500/10' };
      case 'absent': return { label: 'Absent', color: 'text-red-400', bg: 'bg-red-500/10' };
      default: return { label: status, color: 'text-slate-400', bg: 'bg-slate-500/10' };
    }
  };

  // Derive custom stats
  const uniqueDays = new Set((logs || []).map((l: any) => l.date.split('T')[0])).size;
  const presentDays = (logs || []).filter((l: any) => l.status === 'present').length;
  const lateDays = (logs || []).filter((l: any) => l.status === 'late').length;

  const validLogs = (logs || []).filter((l: any) => l.checkIn && l.checkOut);
  const totalMins = validLogs.reduce((acc: number, l: any) => {
    return acc + (new Date(l.checkOut).getTime() - new Date(l.checkIn).getTime()) / 60000;
  }, 0);
  const avgHours = validLogs.length ? (totalMins / 60 / validLogs.length).toFixed(1) : 0;

  return (
    <div className="p-6 space-y-6">
      <PageHeader 
        title="Custom View Attendance" 
        subtitle="Filter and analyze your attendance logs over any custom date range."
        icon={Sparkles}
      />

      <div className="flex flex-col xl:flex-row gap-6">
        
        {/* Left Column: Filter & Stats */}
        <div className="xl:w-1/3 space-y-6">
          
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 right-0 p-12 bg-indigo-500/5 rounded-bl-full -z-0"></div>
             <div className="relative z-10">
              <h3 className="text-sm font-bold text-[var(--text-primary)] border-b border-[var(--border)] pb-3 flex items-center gap-2 mb-5">
                <Filter size={16} className="text-indigo-500" /> Filter Criteria
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">From Date</label>
                  <input
                    type="date"
                    value={fromDate}
                    onChange={(e) => setFromDate(e.target.value)}
                    className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none focus:border-indigo-500/50 transition-colors"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">To Date</label>
                  <input
                    type="date"
                    value={toDate}
                    onChange={(e) => setToDate(e.target.value)}
                    className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none focus:border-indigo-500/50 transition-colors"
                  />
                </div>
              </div>
             </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Logged Days', value: uniqueDays, icon: Calendar, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
              { label: 'Present Entries', value: presentDays, icon: CheckCircle, color: 'text-green-400', bg: 'bg-green-500/10' },
              { label: 'Late Entries', value: lateDays, icon: Clock, color: 'text-amber-400', bg: 'bg-amber-500/10' },
              { label: 'Avg Hrs/Day', value: `${avgHours}h`, icon: FileText, color: 'text-purple-400', bg: 'bg-purple-500/10' },
            ].map((c, i) => (
              <div key={i} className={`${c.bg} border border-[var(--border)] rounded-2xl p-4 flex flex-col justify-center items-center text-center gap-2`}>
                <c.icon size={20} className={c.color} />
                <div>
                  <div className={`text-xl font-bold font-mono ${c.color}`}>{c.value}</div>
                  <div className="text-[10px] text-[var(--text-muted)] uppercase tracking-wider">{c.label}</div>
                </div>
              </div>
            ))}
          </div>

        </div>

        {/* Right Column: Results Ledger */}
        <div className="xl:w-2/3">
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 shadow-sm h-full flex flex-col">
            <div className="flex items-center justify-between border-b border-[var(--border)] pb-3 mb-4">
              <h3 className="text-sm font-bold text-[var(--text-primary)] flex items-center gap-2">
                <Search size={16} className="text-indigo-500" /> Attendance Ledger
              </h3>
              <button 
                disabled={isLoading || !logs?.length}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 transition-colors disabled:opacity-50"
              >
                <Download size={14} /> Export CSV
              </button>
            </div>

            {isLoading ? (
              <div className="flex-1 flex justify-center items-center py-20"><Spinner /></div>
            ) : !logs || logs.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center py-20 opacity-50">
                <FileText size={48} className="text-slate-600 mb-4" />
                <p className="text-sm text-[var(--text-muted)]">No attendance logs found for the selected range.</p>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto max-h-[600px] pr-2 space-y-3">
                {logs.map((log: any) => {
                  const conf = getStatusConfig(log.status, log.regularizationStatus);
                  const dateObj = new Date(log.date);
                  return (
                    <div key={log.id} className="p-4 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] flex items-center justify-between hover:border-indigo-500/30 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-lg bg-[var(--surface)] border border-[var(--border)] flex flex-col items-center justify-center shadow-sm">
                          <span className="text-[10px] uppercase font-bold text-[var(--text-muted)]">{dateObj.toLocaleDateString('en-IN', { weekday: 'short' })}</span>
                          <span className="text-lg font-bold text-[var(--text-primary)] leading-none mt-0.5">{dateObj.getDate()}</span>
                        </div>
                        <div>
                          <div className="text-sm font-semibold text-[var(--text-primary)]">
                            {dateObj.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}
                          </div>
                          <div className="text-xs text-[var(--text-muted)] mt-1 flex items-center gap-3">
                            <span className="flex items-center gap-1"><MapPin size={12}/> In: {log.checkIn ? new Date(log.checkIn).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—'}</span>
                            <span className="flex items-center gap-1"><MapPin size={12}/> Out: {log.checkOut ? new Date(log.checkOut).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—'}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        {log.overtimeMinutes > 0 && (
                          <div className="text-[10px] text-purple-400 border border-purple-500/20 bg-purple-500/10 px-2 py-0.5 rounded-full font-mono">
                            +{log.overtimeMinutes}m OT
                          </div>
                        )}
                        <span className={`text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-md border ${conf.bg} ${conf.color} border-current/20`}>
                          {conf.label}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
