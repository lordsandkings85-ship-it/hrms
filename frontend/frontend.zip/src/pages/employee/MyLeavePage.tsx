import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  CalendarDays, Calendar, FileText, CalendarPlus, CheckCircle2, Clock, XCircle, Send, Award
} from 'lucide-react';
import { leaveApi } from '../../api/client';
import { useAuthStore } from '../../store/useAuthStore';
import { PageHeader } from '../../components/ui/PageHeader';
import { Spinner } from '../../components/ui/Spinner';
import { useToast } from '../../components/ui/ToastProvider';

type TabKey = 'apply' | 'history' | 'balances' | 'holidays';

const SUB_TO_TAB: Record<string, TabKey> = {
  apply: 'apply',
  requests: 'history',
  balances: 'balances',
  holidays: 'holidays'
};

const TAB_TO_SUB: Record<TabKey, string> = {
  apply: 'apply',
  history: 'requests',
  balances: 'balances',
  holidays: 'holidays'
};

export default function MyLeavePage() {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const { sub } = useParams<{ sub?: string }>();
  const navigate = useNavigate();
  const { success: toastSuccess, error: toastError } = useToast();

  const myEmpId = user?.employee?.id || '';
  const initialTab = sub ? SUB_TO_TAB[sub] || 'apply' : 'apply';
  const [tab, setTab] = useState<TabKey>(initialTab);

  useEffect(() => {
    if (sub && SUB_TO_TAB[sub]) {
      setTab(SUB_TO_TAB[sub]);
    }
  }, [sub]);

  const handleTabChange = (t: TabKey) => {
    setTab(t);
    navigate(`/leave/${TAB_TO_SUB[t]}`);
  };

  const [leaveTypeId, setLeaveTypeId] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isHalfDay, setIsHalfDay] = useState(false);
  const [reason, setReason] = useState('');

  // Fetching
  const { data: leaveTypes } = useQuery({ queryKey: ['leave-types'], queryFn: () => leaveApi.listTypes() });
  const { data: myLeaveHistory, isLoading: isLoadingHistory } = useQuery({ 
    queryKey: ['leave-history', myEmpId], 
    queryFn: () => leaveApi.listForEmployee(myEmpId), 
    enabled: !!myEmpId 
  });
  const { data: balances, isLoading: isLoadingBalances } = useQuery({ 
    queryKey: ['leave-balances', myEmpId], 
    queryFn: () => leaveApi.balances(myEmpId), 
    enabled: !!myEmpId 
  });
  const { data: holidays } = useQuery({ queryKey: ['holidays-list'], queryFn: () => leaveApi.listHolidays() });

  // Mutations
  const applyLeaveMutation = useMutation({
    mutationFn: leaveApi.apply,
    onSuccess: () => {
      toastSuccess('Leave applied successfully!');
      setReason(''); setStartDate(''); setEndDate(''); setIsHalfDay(false);
      queryClient.invalidateQueries({ queryKey: ['leave-history', myEmpId] });
      queryClient.invalidateQueries({ queryKey: ['leave-balances', myEmpId] });
      handleTabChange('history');
    },
    onError: (err: any) => toastError(err.message || 'Failed to apply leave'),
  });

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!leaveTypeId || !startDate || !endDate) {
      toastError('Please fill in all required fields');
      return;
    }
    applyLeaveMutation.mutate({
      employeeId: myEmpId,
      leaveTypeId,
      startDate,
      endDate,
      isHalfDay,
      reason,
    });
  };

  return (
    <div className="p-6 space-y-6">
      <PageHeader 
        title="Leaves & Time Off" 
        subtitle="Manage your leave applications, check balances, and view scheduled holidays."
        icon={CalendarDays}
      />

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-[var(--surface-alt)] rounded-xl w-fit flex-wrap">
        {([
          ['apply', 'Apply Leave', CalendarPlus],
          ['history', 'Leave History', FileText],
          ['balances', 'My Balance', CalendarDays],
          ['holidays', 'Holidays', Calendar]
        ] as const).map(([key, label, Icon]) => (
          <button key={key} onClick={() => handleTabChange(key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === key ? 'bg-[var(--surface)] text-[var(--text-primary)] shadow-sm' : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
            }`}>
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* Apply Leave */}
        {tab === 'apply' && (
          <div className="max-w-xl mx-auto w-full rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-5">
            <h3 className="text-sm font-bold text-[var(--text-primary)] border-b border-[var(--border)] pb-3 flex items-center gap-2">
              <CalendarPlus size={16} className="text-indigo-500" /> New Leave Application
            </h3>
            <form onSubmit={handleApply} className="space-y-4">
              <div>
                <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">Leave Type</label>
                <select
                  value={leaveTypeId}
                  onChange={(e) => setLeaveTypeId(e.target.value)}
                  className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none"
                  required
                >
                  <option value="">Select Leave Type</option>
                  {leaveTypes?.map((lt) => (
                    <option key={lt.id} value={lt.id}>
                      {lt.name} {lt.paid ? '(Paid)' : '(Unpaid)'}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">End Date</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="halfday"
                  checked={isHalfDay}
                  onChange={(e) => setIsHalfDay(e.target.checked)}
                  className="rounded border-slate-350 text-indigo-600 focus:ring-indigo-500"
                />
                <label htmlFor="halfday" className="text-xs font-semibold text-[var(--text-muted)] select-none">
                  Apply as Half Day Leave
                </label>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-[var(--text-muted)]">Reason</label>
                <textarea
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full bg-[var(--surface-alt)] text-sm text-[var(--text-primary)] px-3 py-2 mt-1 rounded-lg border border-[var(--border)] focus:outline-none resize-none"
                  placeholder="Provide reason for leave request..."
                />
              </div>

              <button
                type="submit"
                disabled={applyLeaveMutation.isPending}
                className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-medium transition-all shadow-lg shadow-indigo-500/20"
              >
                <Send size={15} /> Submit Application
              </button>
            </form>
          </div>
        )}

        {/* History */}
        {tab === 'history' && (
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-4">
            <h3 className="text-sm font-bold text-[var(--text-primary)] border-b border-[var(--border)] pb-3 flex items-center gap-2">
              <FileText size={16} className="text-indigo-500" /> My Leave Requests
            </h3>
            {isLoadingHistory ? (
              <div className="flex justify-center py-6"><Spinner /></div>
            ) : !myLeaveHistory || myLeaveHistory.length === 0 ? (
              <p className="text-xs text-[var(--text-muted)] py-8 text-center">No leave requests found.</p>
            ) : (
              <div className="divide-y divide-[var(--border)]">
                {myLeaveHistory.map((row: any) => {
                  const statusColors: Record<string, { badge: string, icon: React.ElementType }> = {
                    pending: { badge: 'bg-amber-500/10 text-amber-500 border-amber-500/20', icon: Clock },
                    approved: { badge: 'bg-green-500/10 text-green-400 border-green-500/20', icon: CheckCircle2 },
                    rejected: { badge: 'bg-red-500/10 text-red-400 border-red-500/20', icon: XCircle }
                  };
                  const cfg = statusColors[row.status] || { badge: 'bg-slate-500/10 text-slate-400 border-slate-500/20', icon: Clock };
                  const Icon = cfg.icon;
                  return (
                    <div key={row.id} className="py-4 flex items-center justify-between">
                      <div className="min-w-0 flex-1 pr-4">
                        <div className="font-semibold text-sm text-[var(--text-primary)]">
                          {row.leaveType?.name}
                        </div>
                        <div className="text-xs text-[var(--text-muted)] mt-0.5">
                          {new Date(row.startDate).toLocaleDateString('en-IN')} to {new Date(row.endDate).toLocaleDateString('en-IN')}
                          {row.isHalfDay && ' (Half Day)'}
                        </div>
                        {row.reason && (
                          <div className="text-xs text-[var(--text-muted)] italic mt-1 font-mono">
                            "{row.reason}"
                          </div>
                        )}
                      </div>
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${cfg.badge}`}>
                        <Icon size={11} />
                        {row.status}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Balances */}
        {tab === 'balances' && (
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-4">
            <h3 className="text-sm font-bold text-[var(--text-primary)] border-b border-[var(--border)] pb-3 flex items-center gap-2">
              <CalendarDays size={16} className="text-indigo-500" /> Leave Balance
            </h3>
            {isLoadingBalances ? (
              <div className="flex justify-center py-6"><Spinner /></div>
            ) : !balances || balances.length === 0 ? (
              <p className="text-xs text-[var(--text-muted)] py-8 text-center">No leave balance metrics found.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {balances.map((bal: any) => {
                  const used = bal.used ?? 0;
                  const total = bal.leaveType?.daysPerYear ?? (bal.balance + used);
                  const pct = total > 0 ? Math.min(100, (bal.balance / total) * 100) : 0;
                  return (
                    <div key={bal.id} className="p-4 border border-[var(--border)] rounded-2xl bg-[var(--surface-alt)] space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm font-bold text-[var(--text-primary)]">{bal.leaveType?.name}</p>
                          <p className="text-[10px] text-[var(--text-muted)] font-bold uppercase mt-0.5">Year: {bal.year}</p>
                        </div>
                        <span className="text-2xl font-black text-indigo-400 font-mono">{bal.balance}</span>
                      </div>
                      <div className="space-y-1">
                        <div className="h-2 rounded-full bg-[var(--surface)] overflow-hidden">
                          <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                        <div className="flex justify-between text-[10px] text-[var(--text-muted)]">
                          <span>{used} Used</span>
                          <span>{total} Total</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Holidays */}
        {tab === 'holidays' && (
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-4">
            <h3 className="text-sm font-bold text-[var(--text-primary)] border-b border-[var(--border)] pb-3 flex items-center gap-2">
              <Calendar size={16} className="text-indigo-500" /> Holiday Calendar
            </h3>
            {!holidays || holidays.length === 0 ? (
              <p className="text-xs text-[var(--text-muted)] py-8 text-center">No holidays declared yet.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {holidays.map((h: any) => (
                  <div key={h.id} className="flex items-center gap-3 p-4 rounded-xl border border-[var(--border)] bg-[var(--surface-alt)]">
                    <div className="p-2.5 rounded-lg bg-indigo-500/10 text-indigo-400 flex-shrink-0">
                      <Calendar size={18} />
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-[var(--text-primary)]">{h.name}</div>
                      <div className="text-xs text-[var(--text-muted)] mt-0.5">
                        {new Date(h.date).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
