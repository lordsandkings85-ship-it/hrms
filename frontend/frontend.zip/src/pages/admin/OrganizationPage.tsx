import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Building2, Landmark, ShieldAlert, Award, Plus, Trash2, MapPin, Users, Layers, Search, Filter } from 'lucide-react';
import { organizationApi } from '../../api/client';
import { DataTable, Column } from '../../components/ui/DataTable';

type TabKey = 'branches' | 'categories' | 'departments' | 'designations' | 'grades';

const SUB_TO_TAB: Record<string, TabKey> = {
  branches: 'branches',
  categories: 'categories',
  departments: 'departments',
  designations: 'designations',
  grades: 'grades',
};

const TAB_TO_SUB: Record<TabKey, string> = {
  branches: 'branches',
  categories: 'categories',
  departments: 'departments',
  designations: 'designations',
  grades: 'grades',
};

export default function OrganizationPage() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const location = useLocation();
  const pathParts = location.pathname.split('/');
  const subAction = pathParts.length > 2 ? pathParts[2] : 'branches';

  const initialTab = SUB_TO_TAB[subAction] || 'branches';
  const [tab, setTab] = useState<TabKey>(initialTab);

  useEffect(() => {
    if (subAction && SUB_TO_TAB[subAction]) {
      setTab(SUB_TO_TAB[subAction]);
    }
  }, [subAction]);

  const handleTabChange = (t: TabKey) => {
    setTab(t);
    navigate(`/organization/${TAB_TO_SUB[t]}`);
  };

  const TABS = [
    { key: 'branches', label: 'Branch / Location', icon: <MapPin size={16} /> },
    { key: 'categories', label: 'Employee Category', icon: <Users size={16} /> },
    { key: 'departments', label: 'Department', icon: <Building2 size={16} /> },
    { key: 'designations', label: 'Designations', icon: <Award size={16} /> },
    { key: 'grades', label: 'Grade (Pay Cadre)', icon: <Layers size={16} /> },
  ] as const;

  const currentTab = TABS.find(t => t.key === tab) || TABS[0];

  // Fetch lists
  const { data: departments, isLoading: isLoadingDepts } = useQuery({
    queryKey: ['departments-list'],
    queryFn: () => organizationApi.listDepartments(),
  });

  const { data: branches, isLoading: isLoadingBranches } = useQuery({
    queryKey: ['branches-list'],
    queryFn: () => organizationApi.listBranches(),
  });

  const { data: designations, isLoading: isLoadingDesigs } = useQuery({
    queryKey: ['designations-list'],
    queryFn: () => organizationApi.listDesignations(),
  });

  const deptColumns: Column<any>[] = [
    { key: 'name', header: 'Department Name', render: (row) => <span className="font-bold text-[var(--text-primary)]">{row.name}</span> },
    { key: 'code', header: 'Code', render: (row) => <span className="text-[var(--text-muted)] font-mono text-xs uppercase tracking-wider">{row.id.substring(0,8)}</span> },
  ];

  const branchColumns: Column<any>[] = [
    { key: 'name', header: 'Branch Name', render: (row) => <span className="font-bold text-[var(--text-primary)]">{row.name}</span> },
    { key: 'address', header: 'Address', render: (row) => <span className="text-[var(--text-muted)] text-xs">{row.address || '—'}</span> },
  ];

  const desigColumns: Column<any>[] = [
    { key: 'title', header: 'Designation Title', render: (row) => <span className="font-bold text-[var(--text-primary)]">{row.title}</span> },
    { key: 'grade', header: 'Grade/Band', render: (row) => <span className="text-indigo-500 bg-indigo-500/10 px-2 py-0.5 rounded font-bold uppercase tracking-wider text-[10px] border border-indigo-500/20">{row.grade || '—'}</span> },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      
      {/* Premium Header */}
      <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="absolute top-0 right-0 p-32 bg-purple-500/10 rounded-bl-full -z-0 blur-2xl"></div>
        <div className="relative z-10 flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-500 shadow-inner">
             <Building2 size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--text-primary)] tracking-tight">Company Setup Command Center</h1>
            <p className="text-sm text-[var(--text-muted)] mt-1 font-medium">Configure branches, departments, and designations.</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {TABS.map(t => (
          <button
            key={t.key}
            onClick={() => handleTabChange(t.key)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all border ${
              tab === t.key
                ? 'bg-purple-500 text-white border-purple-500 shadow-md shadow-purple-500/20'
                : 'bg-[var(--surface)] text-[var(--text-muted)] border-[var(--border)] hover:bg-[var(--surface-hover)] hover:text-[var(--text-primary)]'
            }`}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      {/* Dynamic Content Area */}
      <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm min-h-[400px]">
          
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6 pb-4 border-b border-[var(--border)]">
            <div>
               <h3 className="text-lg font-bold text-[var(--text-primary)] flex items-center gap-2">
                 {currentTab.icon} {currentTab.label}
               </h3>
               <p className="text-xs text-[var(--text-muted)] mt-1 font-medium">Manage {currentTab.label.toLowerCase()} settings.</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                <input 
                  type="text" 
                  placeholder="Search..." 
                  className="pl-9 pr-4 py-2 bg-[var(--surface-alt)] border border-[var(--border)] rounded-xl text-xs text-[var(--text-primary)] focus:outline-none focus:border-purple-500/50 transition-colors w-64"
                />
              </div>
              <button className="flex items-center gap-2 px-3 py-2 bg-purple-500 text-white text-xs font-bold rounded-xl hover:bg-purple-600 transition-colors shadow-sm">
                 <Plus size={14} /> New Entry
              </button>
            </div>
          </div>

          <div className="premium-datatable">
            <style>{`
               .premium-datatable table { width: 100%; border-collapse: separate; border-spacing: 0 8px; }
               .premium-datatable th { padding: 12px 16px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); font-weight: 700; border-bottom: 1px solid var(--border); text-align: left; }
               .premium-datatable td { padding: 12px 16px; background: var(--surface-alt); border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); transition: background 0.2s; }
               .premium-datatable tr td:first-child { border-left: 1px solid var(--border); border-top-left-radius: 12px; border-bottom-left-radius: 12px; }
               .premium-datatable tr td:last-child { border-right: 1px solid var(--border); border-top-right-radius: 12px; border-bottom-right-radius: 12px; }
               .premium-datatable tbody tr:hover td { background: var(--surface-hover); }
            `}</style>
            
            {tab === 'departments' && <DataTable columns={deptColumns} data={departments || []} loading={isLoadingDepts} keyField="id" />}
            {tab === 'branches' && <DataTable columns={branchColumns} data={branches || []} loading={isLoadingBranches} keyField="id" />}
            {(tab === 'designations' || tab === 'grades') && <DataTable columns={desigColumns} data={designations || []} loading={isLoadingDesigs} keyField="id" />}
            {tab === 'categories' && (
               <div className="flex flex-col items-center justify-center h-64 text-[var(--text-muted)]">
                 <div className="w-16 h-16 rounded-2xl bg-[var(--surface-alt)] border border-[var(--border)] flex items-center justify-center mb-4">
                   <Users size={24} />
                 </div>
                 <p className="text-sm font-bold text-[var(--text-primary)]">Employee Categories</p>
                 <p className="text-xs mt-1">This module is currently being configured.</p>
               </div>
            )}
          </div>

        </div>
      </div>

    </div>
  );
}
