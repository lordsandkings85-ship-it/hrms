import MyPayrollPage from './employee/MyPayrollPage';
export default function PayrollPage() { return <MyPayrollPage />; }
