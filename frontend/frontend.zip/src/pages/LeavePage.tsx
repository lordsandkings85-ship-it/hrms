import MyLeavePage from './employee/MyLeavePage';
export default function LeavePage() { return <MyLeavePage />; }
