import MyAssetsPage from './employee/MyAssetsPage';
export default function AssetsPage() { return <MyAssetsPage />; }
