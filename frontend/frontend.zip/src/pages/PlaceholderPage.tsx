import React from 'react';
import { useLocation } from 'react-router-dom';

export default function PlaceholderPage() {
  const location = useLocation();
  const pathParts = location.pathname.split('/').filter(Boolean);
  const title = pathParts.map(p => p.charAt(0).toUpperCase() + p.slice(1).replace(/-/g, ' ')).join(' / ');

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center animate-in fade-in zoom-in duration-500">
        <div className="w-24 h-24 mb-6 rounded-full bg-white/5 flex items-center justify-center">
          <div className="w-12 h-12 border-4 border-dashed border-[var(--brand-primary)] rounded-full animate-spin-slow" style={{ animationDuration: '4s' }} />
        </div>
        <h2 className="text-2xl font-semibold text-white mb-2">{title}</h2>
        <p className="text-[var(--text-muted)] max-w-sm mx-auto mb-8">
          This module is part of the Enterprise architecture overhaul and is currently under construction.
        </p>
        <button 
          onClick={() => window.history.back()}
          className="px-4 py-2 text-sm font-medium bg-[var(--surface-elevated)] text-white border border-[var(--sidebar-border)] rounded-md hover:bg-white/10 transition-colors"
        >
          Go Back
        </button>
      </div>
    </div>
  );
}

