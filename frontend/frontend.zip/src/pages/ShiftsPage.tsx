
import MyShiftsPage from './employee/MyShiftsPage';
export default function ShiftsPage() { return <MyShiftsPage />; }
