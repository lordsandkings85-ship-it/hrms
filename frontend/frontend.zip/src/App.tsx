import { Navigate, Route, Routes } from 'react-router-dom';
import { lazy, Suspense, useEffect } from 'react';
import Layout from './components/Layout';
import { useAuthStore } from './store/useAuthStore';
import { authApi } from './api/client';
import { FullPageSpinner } from './components/ui/Spinner';
import { ErrorBoundary } from './components/ui/ErrorBoundary';

// ── Lazy route imports (code splitting per page) ─────────────────
const LoginPage           = lazy(() => import('./pages/LoginPage'));
const DashboardPage       = lazy(() => import('./pages/employee/DashboardPage'));
const MyProfilePage       = lazy(() => import('./pages/employee/MyProfilePage'));
const LeavePage           = lazy(() => import('./pages/LeavePage'));
const PayrollPage         = lazy(() => import('./pages/PayrollPage'));

const DocumentsPage       = lazy(() => import('./pages/employee/MyDocumentsPage'));
const AssetsPage          = lazy(() => import('./pages/AssetsPage'));
const ExpensesPage        = lazy(() => import('./pages/ExpensesPage'));
const TravelPage          = lazy(() => import('./pages/TravelPage'));
const ShiftsPage          = lazy(() => import('./pages/ShiftsPage'));




const TimesheetsPage      = lazy(() => import('./pages/employee/TimesheetsPage'));
const ProjectsPage        = lazy(() => import('./pages/employee/ProjectsPage'));
const AnnouncementsPage   = lazy(() => import('./pages/AnnouncementsPage'));
const TrainingPage        = lazy(() => import('./pages/employee/TrainingPage'));

// ── Auxiliary Missing Pages (Tax, Employee Attendance, Promotion) ──────
const TaxMasterPage = lazy(() => import('./pages/tax/TaxMasterPage'));
const TaxDeclarationsPage = lazy(() => import('./pages/tax/TaxDeclarationsPage'));
const DailyAttendancePage = lazy(() => import('./pages/employee/attendance/DailyAttendancePage'));
const ManualPunchPage = lazy(() => import('./pages/employee/attendance/ManualPunchPage'));
const CustomAttendancePage = lazy(() => import('./pages/employee/attendance/CustomAttendancePage'));
const OvertimePage = lazy(() => import('./pages/employee/attendance/OvertimePage'));
const GeofencePage = lazy(() => import('./pages/employee/attendance/GeofencePage'));
const DailyReportPage = lazy(() => import('./pages/employee/attendance/DailyReportPage'));
const SummaryPage = lazy(() => import('./pages/employee/attendance/SummaryPage'));
const EmployeePromotionPage = lazy(() => import('./pages/hr/employees/EmployeePromotionPage'));

const OrganizationPage    = lazy(() => import('./pages/admin/OrganizationPage'));
const ReportsPage         = lazy(() => import('./pages/admin/ReportsPage'));
const SettingsPage        = lazy(() => import('./pages/admin/SettingsPage'));
const BillingPage         = lazy(() => import('./pages/admin/BillingPage'));
const IntegrationsPage    = lazy(() => import('./pages/admin/IntegrationsPage'));
const SuperAdminPage      = lazy(() => import('./pages/admin/SuperAdminPage'));
const FnfPage             = lazy(() => import('./pages/employee/FnfPage'));
const ExitPage            = lazy(() => import('./pages/employee/ExitPage'));
const HelpdeskPage           = lazy(() => import('./pages/HelpdeskPage'));
const CompliancePage         = lazy(() => import('./pages/hr/CompliancePage'));

// ── HR Approval Pages (9 files) ──────────────────────────────────
const LeaveApprovalPage = lazy(() => import('./pages/hr/approvals/LeaveApprovalPage'));
const CancelLeaveApprovalPage = lazy(() => import('./pages/hr/approvals/CancelLeaveApprovalPage'));
const ColCoffApprovalPage = lazy(() => import('./pages/hr/approvals/ColCoffApprovalPage'));
const TravelClaimApprovalPage = lazy(() => import('./pages/hr/approvals/TravelClaimApprovalPage'));
const AdvanceClaimApprovalPage = lazy(() => import('./pages/hr/approvals/AdvanceClaimApprovalPage'));
const LoanAdvanceApprovalPage = lazy(() => import('./pages/hr/approvals/LoanAdvanceApprovalPage'));
const ShiftChangeApprovalPage = lazy(() => import('./pages/hr/approvals/ShiftChangeApprovalPage'));
const OptionalHolidayApprovalPage = lazy(() => import('./pages/hr/approvals/OptionalHolidayApprovalPage'));
const OvertimeApprovalPage = lazy(() => import('./pages/hr/approvals/OvertimeApprovalPage'));

// ── HR Attendance Pages (5 files) ────────────────────────────────
const CorrectionRequestApprovalPage = lazy(() => import('./pages/hr/attendance/CorrectionRequestApprovalPage'));
const MarkAttendanceApprovalPage = lazy(() => import('./pages/hr/attendance/MarkAttendanceApprovalPage'));
const RegularizationApprovalPage = lazy(() => import('./pages/hr/attendance/RegularizationApprovalPage'));
const GeoAttendanceApprovalPage = lazy(() => import('./pages/hr/attendance/GeoAttendanceApprovalPage'));
const TeamDailyAttendanceReportPage = lazy(() => import('./pages/hr/attendance/TeamDailyAttendanceReportPage'));

// ── HR Performance Pages (4 files) ───────────────────────────────
const ManagerEvaluationPage = lazy(() => import('./pages/hr/performance/ManagerEvaluationPage'));
const ApproveTargetsPage = lazy(() => import('./pages/hr/performance/ApproveTargetsPage'));
const ViewScorecardPage = lazy(() => import('./pages/hr/performance/ViewScorecardPage'));
const ViewPeriodicScorecardPage = lazy(() => import('./pages/hr/performance/ViewPeriodicScorecardPage'));

// ── HR Recruitment Pages (4 files) ───────────────────────────────
const RequisitionsPage = lazy(() => import('./pages/hr/recruitment/RequisitionsPage'));
const ResumesScreeningPage = lazy(() => import('./pages/hr/recruitment/ResumesScreeningPage'));
const InterviewSchedulePage = lazy(() => import('./pages/hr/recruitment/InterviewSchedulePage'));
const InterviewFeedbackPage = lazy(() => import('./pages/hr/recruitment/InterviewFeedbackPage'));
const RecruitmentFormsPage = lazy(() => import('./pages/hr/recruitment/RecruitmentFormsPage'));
const PerformanceFormsPage = lazy(() => import('./pages/hr/performance/PerformanceFormsPage'));
const HrProjectsPage = lazy(() => import('./pages/hr/ProjectsPage'));

// ── New Employee Portal Pages ─────────────────────────────────────
const MyHelpdeskPage         = lazy(() => import('./pages/employee/MyHelpdeskPage'));
const MyResponsibilitiesPage = lazy(() => import('./pages/employee/MyResponsibilitiesPage'));
const EmployeeDirectoryPage  = lazy(() => import('./pages/employee/EmployeeDirectoryPage'));
const MyAnnouncementsPage    = lazy(() => import('./pages/employee/MyAnnouncementsPage'));
const MySeparationPage       = lazy(() => import('./pages/employee/MySeparationPage'));
const MyDocumentsPage        = lazy(() => import('./pages/employee/MyDocumentsPage'));
const JobOpeningsPage        = lazy(() => import('./pages/employee/JobOpeningsPage'));
const FeedbackPage           = lazy(() => import('./pages/employee/FeedbackPage'));

// ── Salary Detail Pages ───────────────────────────────────────────
const Form16Page                 = lazy(() => import('./pages/employee/Form16Page'));
const LoansAdvancesPage          = lazy(() => import('./pages/employee/LoansAdvancesPage'));
const InvestmentDeclarationPage  = lazy(() => import('./pages/employee/InvestmentDeclarationPage'));
const ITStatementPage            = lazy(() => import('./pages/employee/ITStatementPage'));
const SalaryRevisionHistoryPage  = lazy(() => import('./pages/employee/SalaryRevisionHistoryPage'));

// ── Comp Off & Flexible Holidays Pages ─────────────────────────────
const MyCompOffPage              = lazy(() => import('./pages/employee/MyCompOffPage'));
const MyFlexibleHolidayPage      = lazy(() => import('./pages/employee/MyFlexibleHolidayPage'));



function isAuthed() {
  return !!localStorage.getItem('accessToken');
}

function Protected({ children }: { children: React.ReactNode }) {
  const { user, setUser, isLoading, setLoading, logout } = useAuthStore();

  useEffect(() => {
    if (isAuthed() && !user) {
      setLoading(true);
      authApi.me()
        .then(setUser)
        .catch(() => logout())
        .finally(() => setLoading(false));
    } else if (!isAuthed()) {
      setLoading(false);
    }
  }, [user, setUser, setLoading, logout]);

  if (!isAuthed()) return <Navigate to="/login" replace />;
  if (isLoading) return <FullPageSpinner />;

  return <>{children}</>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={
        <Suspense fallback={<FullPageSpinner />}>
          <LoginPage />
        </Suspense>
      } />
      <Route
        path="/"
        element={
          <Protected>
            <Layout />
          </Protected>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        {[
          // Core pages
          { path: 'dashboard',      El: DashboardPage },

          // Employees
          { path: 'employees/resignation',   El: EmployeeResignationPage },
          { path: 'employees/offboarding',   El: EmployeeOffboardingPage },
          { path: 'employees/promotion',     El: EmployeePromotionPage },
          { path: 'employees/me',            El: MyProfilePage },

          // Attendance
          { path: 'attendance/correction',   El: CorrectionRequestApprovalPage },
          { path: 'attendance/mark',         El: MarkAttendanceApprovalPage },
          { path: 'attendance/regularization', El: RegularizationApprovalPage },
          { path: 'attendance/geo',          El: GeoAttendanceApprovalPage },
          { path: 'reports/attendance',      El: TeamDailyAttendanceReportPage },
          
          // Employee Attendance Subpages
          { path: 'attendance/daily',        El: DailyAttendancePage },
          { path: 'attendance/manual',       El: ManualPunchPage },
          { path: 'attendance/custom',       El: CustomAttendancePage },
          { path: 'attendance/overtime',     El: OvertimePage },
          { path: 'attendance/geofence',     El: GeofencePage },
          { path: 'attendance/daily-report', El: DailyReportPage },
          { path: 'attendance/summary',      El: SummaryPage },

          // Leave
          { path: 'leave',                   El: LeavePage },
          { path: 'leave/:sub',              El: LeavePage },

          // Payroll & Salary
          { path: 'payroll',                 El: PayrollPage },
          { path: 'payroll/:sub',            El: PayrollPage },

          // Recruitment (Separated)
          { path: 'recruitment/requisitions',     El: RequisitionsPage },
          { path: 'recruitment/assign-screening', El: ResumesScreeningPage },
          { path: 'recruitment/interviews',       El: InterviewSchedulePage },
          { path: 'recruitment/interview-feedback', El: InterviewFeedbackPage },
          { path: 'recruitment/forms',            El: RecruitmentFormsPage },

          // Performance (Separated)
          { path: 'performance/evaluation',       El: ManagerEvaluationPage },
          { path: 'performance/approve-targets',  El: ApproveTargetsPage },
          { path: 'performance/scorecard',        El: ViewScorecardPage },
          { path: 'performance/periodic-scorecard', El: ViewPeriodicScorecardPage },
          { path: 'performance/forms',            El: PerformanceFormsPage },

          // Documents / HR Forms / Payroll Forms
          { path: 'documents',               El: DocumentsPage },
          { path: 'documents/payroll',       El: DocumentsPage }, // Assuming DocumentsPage handles /payroll subpath or use sub
          
          // Projects / Task Management
          { path: 'projects',                El: HrProjectsPage },
          { path: 'documents/:sub',          El: DocumentsPage },

          // Assets
          { path: 'assets',                  El: AssetsPage },
          { path: 'assets/:sub',             El: AssetsPage },

          // Expenses / Claims / Advances / Loans
          { path: 'expenses',                El: ExpensesPage },
          { path: 'expenses/:sub',           El: ExpensesPage },

          // Travel
          { path: 'travel',                  El: TravelPage },
          { path: 'travel/:sub',             El: TravelPage },

          // Shifts
          { path: 'shifts',                  El: ShiftsPage },
          { path: 'shifts/:sub',             El: ShiftsPage },

          // Timesheets
          { path: 'timesheets',              El: TimesheetsPage },
          { path: 'timesheets/:sub',         El: TimesheetsPage },

          // Projects & Tasks
          { path: 'projects',                El: ProjectsPage },
          { path: 'projects/:sub',           El: ProjectsPage },

          // Announcements
          { path: 'announcements',           El: AnnouncementsPage },
          { path: 'announcements/:sub',      El: AnnouncementsPage },

          // Training
          { path: 'training',                El: TrainingPage },
          { path: 'training/:sub',           El: TrainingPage },

          // Organization / Company Setup
          { path: 'organization',            El: OrganizationPage },
          { path: 'organization/:sub',       El: OrganizationPage },

          // Reports
          { path: 'reports',                 El: ReportsPage },
          { path: 'reports/:sub',            El: ReportsPage },

          // Settings / Role Setup
          { path: 'settings',                El: SettingsPage },
          { path: 'settings/:sub',           El: SettingsPage },

          // Billing
          { path: 'billing',                 El: BillingPage },
          { path: 'billing/:sub',            El: BillingPage },

          // Integrations
          { path: 'integrations',            El: IntegrationsPage },
          { path: 'integrations/:sub',       El: IntegrationsPage },

          // Super Admin
          { path: 'super-admin',             El: SuperAdminPage },
          { path: 'super-admin/:sub',        El: SuperAdminPage },

          // FnF Settlement
          { path: 'fnf',                     El: FnfPage },
          { path: 'fnf/:sub',                El: FnfPage },

          // Exit Management
          { path: 'exit',                    El: ExitPage },
          { path: 'exit/:sub',               El: ExitPage },

          // Helpdesk
          { path: 'helpdesk',                El: HelpdeskPage },
          { path: 'helpdesk/:sub',           El: HelpdeskPage },

          // Statutory Compliance (PF, ESI, PT, LWF)
          { path: 'compliance',              El: CompliancePage },
          { path: 'compliance/:sub',         El: CompliancePage },

          // Approvals (Separated)
          { path: 'approvals/leave',         El: LeaveApprovalPage },
          { path: 'approvals/cancel-leave',  El: CancelLeaveApprovalPage },
          { path: 'approvals/compoff',       El: ColCoffApprovalPage },
          { path: 'approvals/travel',        El: TravelClaimApprovalPage },
          { path: 'approvals/advance',       El: AdvanceClaimApprovalPage },
          { path: 'approvals/loan',          El: LoanAdvanceApprovalPage },
          { path: 'approvals/shift',         El: ShiftChangeApprovalPage },
          { path: 'approvals/optional-holiday', El: OptionalHolidayApprovalPage },
          { path: 'approvals/overtime',      El: OvertimeApprovalPage },

          // More / Misc catch-all
          { path: 'more',                    El: DashboardPage },

          // Employee portal – Helpdesk (My Tickets)
          { path: 'helpdesk/my-tickets',     El: MyHelpdeskPage },

          // Employee portal – Responsibilities / Performance
          { path: 'performance/kpi',         El: MyResponsibilitiesPage },
          { path: 'performance/kra',         El: MyResponsibilitiesPage },
          { path: 'performance/evaluation',  El: MyResponsibilitiesPage },
          { path: 'performance/scorecard',   El: MyResponsibilitiesPage },

          // Employee portal – Directory
          { path: 'employees/directory',     El: EmployeeDirectoryPage },

          // Employee portal – Announcements
          { path: 'announcements/company',   El: MyAnnouncementsPage },

          // Employee portal – Separation
          { path: 'exit/clearance',          El: MySeparationPage },
          { path: 'exit/interview',          El: MySeparationPage },

          // Employee portal – Documents
          { path: 'documents/newsletter',    El: MyDocumentsPage },
          { path: 'documents/hr-links',      El: MyDocumentsPage },
          { path: 'documents/salary-links',  El: MyDocumentsPage },

          // Employee portal – Feedback
          { path: 'helpdesk/feedback',       El: FeedbackPage },

          // Employee portal – Job Openings
          { path: 'recruitment/job-ads',     El: JobOpeningsPage },

          // ── Salary Detail Pages ─────────────────────────────────
          { path: 'tax-calculator',              El: TaxCalculatorPage },
          { path: 'tax-calculator/form16',       El: Form16Page },
          { path: 'tax-calculator/investment',   El: InvestmentDeclarationPage },
          { path: 'tax-calculator/it-statement', El: ITStatementPage },
          { path: 'tax-calculator/master',       El: TaxMasterPage },
          { path: 'tax-calculator/declarations', El: TaxDeclarationsPage },
          { path: 'expenses/loans',              El: LoansAdvancesPage },
          { path: 'payroll/history',             El: SalaryRevisionHistoryPage },

          // ── Comp Off & Flexible Holidays Routes ──────────────────
          { path: 'leave/compoff',               El: MyCompOffPage },
          { path: 'leave/compoff-history',       El: MyCompOffPage },
          { path: 'leave/flexible',              El: MyFlexibleHolidayPage },


        ].map(({ path, El }) => (
          <Route
            key={path}
            path={path}
            element={
              <ErrorBoundary>
                <Suspense fallback={<FullPageSpinner />}>
                  <El />
                </Suspense>
              </ErrorBoundary>
            }
          />
        ))}
      </Route>
    </Routes>
  );
}
