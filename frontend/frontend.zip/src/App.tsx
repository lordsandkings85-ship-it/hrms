import { Navigate, Route, Routes } from 'react-router-dom';
import { lazy, Suspense, useEffect } from 'react';
import Layout from './components/Layout';
import { useAuthStore } from './store/useAuthStore';
import { authApi } from './api/client';
import { FullPageSpinner } from './components/ui/Spinner';
import { ErrorBoundary } from './components/ui/ErrorBoundary';

// ── Lazy route imports (code splitting per page) ─────────────────
const LoginPage           = lazy(() => import('./pages/LoginPage'));
const DashboardPage       = lazy(() => import('./pages/DashboardPage'));
const EmployeesPage       = lazy(() => import('./pages/EmployeesPage'));
const EmployeeDetailPage  = lazy(() => import('./pages/EmployeeDetailPage'));
const AttendancePage      = lazy(() => import('./pages/AttendancePage'));
const LeavePage           = lazy(() => import('./pages/LeavePage'));
const PayrollPage         = lazy(() => import('./pages/PayrollPage'));
const RecruitmentPage     = lazy(() => import('./pages/RecruitmentPage'));
const PerformancePage     = lazy(() => import('./pages/PerformancePage'));
const DocumentsPage       = lazy(() => import('./pages/DocumentsPage'));
const AssetsPage          = lazy(() => import('./pages/AssetsPage'));
const ExpensesPage        = lazy(() => import('./pages/ExpensesPage'));
const TravelPage          = lazy(() => import('./pages/TravelPage'));
const ShiftsPage          = lazy(() => import('./pages/ShiftsPage'));
const TimesheetsPage      = lazy(() => import('./pages/TimesheetsPage'));
const ProjectsPage        = lazy(() => import('./pages/ProjectsPage'));
const AnnouncementsPage   = lazy(() => import('./pages/AnnouncementsPage'));
const TrainingPage        = lazy(() => import('./pages/TrainingPage'));
const OrganizationPage    = lazy(() => import('./pages/OrganizationPage'));
const ReportsPage         = lazy(() => import('./pages/ReportsPage'));
const SettingsPage        = lazy(() => import('./pages/SettingsPage'));
const BillingPage         = lazy(() => import('./pages/BillingPage'));
const IntegrationsPage    = lazy(() => import('./pages/IntegrationsPage'));
const SuperAdminPage      = lazy(() => import('./pages/SuperAdminPage'));
const FnfPage             = lazy(() => import('./pages/FnfPage'));
const ExitPage            = lazy(() => import('./pages/ExitPage'));
const TaxCalculatorPage   = lazy(() => import('./pages/TaxCalculatorPage'));
const HelpdeskPage        = lazy(() => import('./pages/HelpdeskPage'));
const CompliancePage      = lazy(() => import('./pages/CompliancePage'));
const ApprovalsPage       = lazy(() => import('./pages/ApprovalsPage'));


function isAuthed() {
  return !!localStorage.getItem('accessToken');
}

function Protected({ children }: { children: React.ReactNode }) {
  const { user, setUser, isLoading, setLoading, logout } = useAuthStore();

  useEffect(() => {
    if (isAuthed() && !user) {
      setLoading(true);
      authApi.me()
        .then(setUser)
        .catch(() => logout())
        .finally(() => setLoading(false));
    } else if (!isAuthed()) {
      setLoading(false);
    }
  }, [user, setUser, setLoading, logout]);

  if (!isAuthed()) return <Navigate to="/login" replace />;
  if (isLoading) return <FullPageSpinner />;

  return <>{children}</>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={
        <Suspense fallback={<FullPageSpinner />}>
          <LoginPage />
        </Suspense>
      } />
      <Route
        path="/"
        element={
          <Protected>
            <Layout />
          </Protected>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        {[
          // Core pages
          { path: 'dashboard',      El: DashboardPage },

          // Employees
          { path: 'employees',               El: EmployeesPage },
          { path: 'employees/add',           El: EmployeesPage },
          { path: 'employees/transfer',      El: EmployeesPage },
          { path: 'employees/promotion',     El: EmployeesPage },
          { path: 'employees/resignation',   El: EmployeesPage },
          { path: 'employees/exit',          El: EmployeesPage },
          { path: 'employees/compliance',    El: EmployeesPage },
          { path: 'employees/me',            El: EmployeeDetailPage },
          { path: 'employees/:id',           El: EmployeeDetailPage },

          // Attendance
          { path: 'attendance',              El: AttendancePage },
          { path: 'attendance/:sub',         El: AttendancePage },

          // Leave
          { path: 'leave',                   El: LeavePage },
          { path: 'leave/:sub',              El: LeavePage },

          // Payroll & Salary
          { path: 'payroll',                 El: PayrollPage },
          { path: 'payroll/:sub',            El: PayrollPage },

          // Recruitment
          { path: 'recruitment',             El: RecruitmentPage },
          { path: 'recruitment/:sub',        El: RecruitmentPage },

          // Performance Appraisal
          { path: 'performance',             El: PerformancePage },
          { path: 'performance/:sub',        El: PerformancePage },

          // Documents / HR Forms / Payroll Forms
          { path: 'documents',               El: DocumentsPage },
          { path: 'documents/:sub',          El: DocumentsPage },

          // Assets
          { path: 'assets',                  El: AssetsPage },
          { path: 'assets/:sub',             El: AssetsPage },

          // Expenses / Claims / Advances / Loans
          { path: 'expenses',                El: ExpensesPage },
          { path: 'expenses/:sub',           El: ExpensesPage },

          // Travel
          { path: 'travel',                  El: TravelPage },
          { path: 'travel/:sub',             El: TravelPage },

          // Shifts
          { path: 'shifts',                  El: ShiftsPage },
          { path: 'shifts/:sub',             El: ShiftsPage },

          // Timesheets
          { path: 'timesheets',              El: TimesheetsPage },
          { path: 'timesheets/:sub',         El: TimesheetsPage },

          // Projects & Tasks
          { path: 'projects',                El: ProjectsPage },
          { path: 'projects/:sub',           El: ProjectsPage },

          // Announcements
          { path: 'announcements',           El: AnnouncementsPage },
          { path: 'announcements/:sub',      El: AnnouncementsPage },

          // Training
          { path: 'training',                El: TrainingPage },
          { path: 'training/:sub',           El: TrainingPage },

          // Organization / Company Setup
          { path: 'organization',            El: OrganizationPage },
          { path: 'organization/:sub',       El: OrganizationPage },

          // Reports
          { path: 'reports',                 El: ReportsPage },
          { path: 'reports/:sub',            El: ReportsPage },

          // Settings / Role Setup
          { path: 'settings',                El: SettingsPage },
          { path: 'settings/:sub',           El: SettingsPage },

          // Billing
          { path: 'billing',                 El: BillingPage },
          { path: 'billing/:sub',            El: BillingPage },

          // Integrations
          { path: 'integrations',            El: IntegrationsPage },
          { path: 'integrations/:sub',       El: IntegrationsPage },

          // Super Admin
          { path: 'super-admin',             El: SuperAdminPage },
          { path: 'super-admin/:sub',        El: SuperAdminPage },

          // FnF Settlement
          { path: 'fnf',                     El: FnfPage },
          { path: 'fnf/:sub',                El: FnfPage },

          // Exit Management
          { path: 'exit',                    El: ExitPage },
          { path: 'exit/:sub',               El: ExitPage },

          // TDS / Tax
          { path: 'tax-calculator',          El: TaxCalculatorPage },
          { path: 'tax-calculator/:sub',     El: TaxCalculatorPage },

          // Helpdesk
          { path: 'helpdesk',                El: HelpdeskPage },
          { path: 'helpdesk/:sub',           El: HelpdeskPage },

          // Statutory Compliance (PF, ESI, PT, LWF)
          { path: 'compliance',              El: CompliancePage },
          { path: 'compliance/:sub',         El: CompliancePage },

          // Approvals (Leave, Travel, Claims, etc.)
          { path: 'approvals',               El: ApprovalsPage },
          { path: 'approvals/:sub',          El: ApprovalsPage },

          // More / Misc catch-all
          { path: 'more',                    El: DashboardPage },
        ].map(({ path, El }) => (
          <Route
            key={path}
            path={path}
            element={
              <ErrorBoundary>
                <Suspense fallback={<FullPageSpinner />}>
                  <El />
                </Suspense>
              </ErrorBoundary>
            }
          />
        ))}
      </Route>
    </Routes>
  );
}
