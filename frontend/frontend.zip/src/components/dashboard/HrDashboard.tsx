import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { dashboardApi, employeesApi, leaveApi } from '../../api/client';
import { useAuthStore } from '../../store/useAuthStore';
import { StatCard } from '../ui/StatCard';
import { Spinner } from '../ui/Spinner';
import {
  Users, CheckCircle, AlertTriangle, Calendar, FileClock,
  Briefcase, FolderKanban, UserMinus, HandCoins, Calculator,
  ArrowRight, Plus, Banknote, Zap, PartyPopper, UserCheck, Target, ArrowUpRight,
  Clock, ClipboardList, CalendarClock, Wallet, UserPlus, CheckSquare, Coins, 
  Fingerprint, FileText, CalendarPlus, MonitorSmartphone, Megaphone, BarChart2, Bell, History, Search
} from 'lucide-react';
import { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';

const WIDGET_META: Record<string, { label: string; accent: string; icon: React.ElementType; color: string }> = {
  totalEmployees:        { label: 'Total Employees', accent: 'var(--info)', icon: Users, color: '#3B82F6' },
  presentToday:          { label: 'Present Today', accent: 'var(--success)', icon: UserCheck, color: '#10B981' },
  absentToday:           { label: 'Absent', accent: 'var(--danger)', icon: UserMinus, color: '#EF4444' },
  onLeaveToday:          { label: 'On Leave', accent: 'var(--warning)', icon: Calendar, color: '#F97316' },
  lateArrivals:          { label: 'Late Arrivals', accent: 'var(--warning)', icon: Clock, color: '#EAB308' },
  pendingApprovals:      { label: 'Pending Leave', accent: 'var(--primary)', icon: ClipboardList, color: '#A855F7' },
  pendingRegularization: { label: 'Pending Regularization', accent: 'var(--danger)', icon: CalendarClock, color: '#EC4899' },
  pendingPayroll:        { label: 'Pending Payroll', accent: 'var(--success)', icon: Wallet, color: '#10B981' }
};

const CHART_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#14B8A6', '#F43F5E', '#6366F1'];
const GENDER_COLORS = ['#3B82F6', '#EC4899', '#9CA3AF'];

function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  const day = now.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const time = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
  return (
    <div className="text-right">
      <div className="font-mono text-2xl font-bold tabular-nums" style={{ color: 'var(--text-primary)' }}>{time}</div>
      <div className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{day}</div>
    </div>
  );
}

export default function HrDashboard() {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const name = user?.employee ? user.employee.firstName : user?.email?.split('@')[0] ?? 'HR';
  const emp = user?.employee as any;
  const empCode = emp?.employeeCode || 'EMP-001';
  const hireDate = emp?.joiningDate ? new Date(emp.joiningDate).toLocaleDateString() : '01/04/2024';
  const locationName = emp?.branch?.name || 'Headquarters';
  const deptName = emp?.department?.name || 'Human Resources';

  const [dirSearch, setDirSearch] = useState('');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [calendarView, setCalendarView] = useState<'day' | 'week' | 'month' | 'timeline'>('month');

  const approveMutation = useMutation({
    mutationFn: leaveApi.approve,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
    }
  });

  const { data, isLoading, error } = useQuery({
    queryKey: ['dashboard-summary'],
    queryFn: dashboardApi.summary,
    refetchInterval: 300000 // Refresh every 5 mins
  });

  const empId = user?.employee?.id;
  const { data: leaveBalances } = useQuery({
    queryKey: ['my-leave-balances', empId],
    queryFn: () => (empId ? leaveApi.balances(empId) : Promise.resolve([])),
    enabled: !!empId,
    retry: false
  });

  const casualLeave = leaveBalances?.find((b: any) => b.leaveType?.code === 'CL' || b.leaveType?.name?.includes('Casual'))?.balance ?? (leaveBalances?.[0]?.balance || 0);
  const earnedLeave = leaveBalances?.find((b: any) => b.leaveType?.code === 'EL' || b.leaveType?.name?.includes('Earned'))?.balance ?? (leaveBalances?.[1]?.balance || 0);
  const sickLeave = leaveBalances?.find((b: any) => b.leaveType?.code === 'SL' || b.leaveType?.name?.includes('Sick'))?.balance ?? (leaveBalances?.[2]?.balance || 0);

  // Calendar Helpers
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthName = currentDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });

  const firstDayIndex = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const calendarDays = [];

  // Previous month padding
  const prevDays = new Date(year, month, 0).getDate();
  for (let i = firstDayIndex - 1; i >= 0; i--) {
    calendarDays.push({ day: prevDays - i, currentMonth: false });
  }

  // Current month days
  for (let d = 1; d <= daysInMonth; d++) {
    calendarDays.push({ day: d, currentMonth: true });
  }

  // Next month padding to fill grid (42 cells max)
  const remaining = 35 - calendarDays.length;
  for (let n = 1; n <= (remaining > 0 ? remaining : (42 - calendarDays.length)); n++) {
    calendarDays.push({ day: n, currentMonth: false });
  }

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const goToday = () => setCurrentDate(new Date());

  return (
    <div className="page-container space-y-6">

      {/* ── Top Header Banner matching user screenshot ───────────────────── */}
      <div className="bg-slate-900/90 text-slate-100 rounded-xl p-3 border border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-4 text-xs font-semibold">
        <div className="flex items-center gap-6">
          <span><span className="text-slate-400">Employee#:</span> <span className="text-indigo-400">{empCode}</span></span>
          <span><span className="text-slate-400">Hire Date:</span> <span className="text-indigo-400">{hireDate}</span></span>
          <span><span className="text-slate-400">Work Location:</span> <span className="text-indigo-400">{locationName}</span></span>
          <span><span className="text-slate-400">Department:</span> <span className="text-indigo-400">{deptName}</span></span>
        </div>
        <div className="hidden md:block">
          <LiveClock />
        </div>
      </div>

      {isLoading && (
        <div className="flex items-center justify-center h-64 section-card">
          <Spinner size="lg" />
        </div>
      )}

      {error && (
        <div className="flex items-center gap-3 p-4 rounded-xl text-sm" style={{ background: 'var(--danger-bg)', border: '1px solid var(--danger-border)', color: 'var(--danger-text)' }}>
          <AlertTriangle size={18} className="flex-shrink-0" />
          <div>
            <p className="font-semibold">Cannot connect to API</p>
            <p className="text-xs mt-0.5 opacity-90">Ensure the NestJS backend is running.</p>
          </div>
        </div>
      )}

      {data && (
        <>
          {/* ── Top 4 Row Cards Grid matching user screenshot ─────────────── */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* 1. LEAVE BALANCE */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm min-h-[110px]">
              <div className="text-[11px] font-bold tracking-wider text-slate-400 uppercase text-center border-b border-slate-800 pb-1.5 mb-2">
                LEAVE BALANCE
              </div>
              <div className="flex items-center justify-around gap-2 text-center my-auto">
                <div>
                  <div className="text-lg font-bold text-emerald-400">{casualLeave}</div>
                  <div className="text-[10px] text-slate-400 font-medium">Casual</div>
                </div>
                <div className="w-px h-7 bg-slate-800" />
                <div>
                  <div className="text-lg font-bold text-sky-400">{earnedLeave}</div>
                  <div className="text-[10px] text-slate-400 font-medium">Earned</div>
                </div>
                <div className="w-px h-7 bg-slate-800" />
                <div>
                  <div className="text-lg font-bold text-amber-400">{sickLeave}</div>
                  <div className="text-[10px] text-slate-400 font-medium">Sick</div>
                </div>
              </div>
            </div>

            {/* 2. OPEN TICKETS */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm min-h-[110px]">
              <div className="text-[11px] font-bold tracking-wider text-slate-400 uppercase text-center border-b border-slate-800 pb-1.5 mb-2">
                OPEN TICKETS
              </div>
              <div className="flex items-center justify-center gap-3 my-auto">
                <div className="text-3xl font-extrabold text-amber-400">
                  {data.widgets?.pendingApprovals ?? 0}
                </div>
                <div className="text-xs text-slate-300 font-medium leading-snug">
                  Active Support<br />Tickets Pending
                </div>
              </div>
            </div>

            {/* 3. OPEN REQUEST */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm min-h-[110px]">
              <div className="text-[11px] font-bold tracking-wider text-slate-400 uppercase text-center border-b border-slate-800 pb-1.5 mb-2">
                OPEN REQUEST
              </div>
              <div className="flex items-center justify-center gap-3 my-auto">
                <div className="text-3xl font-extrabold text-indigo-400">
                  {((data.widgets as any)?.pendingRegularization ?? 0) + (data.widgets?.pendingApprovals ?? 0)}
                </div>
                <div className="text-xs text-slate-300 font-medium leading-snug">
                  Pending Approvals<br />& Regularizations
                </div>
              </div>
            </div>

            {/* 4. COMPANY DIRECTORY SEARCH */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm min-h-[110px]">
              <div className="text-[11px] font-bold tracking-wider text-slate-400 uppercase text-center border-b border-slate-800 pb-1 mb-2">
                COMPANY DIRECTORY
                <div className="text-[9px] text-slate-400 normal-case font-normal">Search by Employee ID OR Name OR Email</div>
              </div>
              <div className="relative my-auto">
                <input
                  type="text"
                  placeholder="Search..."
                  value={dirSearch}
                  onChange={(e) => setDirSearch(e.target.value)}
                  className="w-full bg-slate-950 text-xs text-slate-100 placeholder-slate-500 pr-8 pl-3 py-1.5 rounded-lg border border-slate-700/80 focus:outline-none focus:border-indigo-500 transition-colors"
                />
                <button className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white">
                  <Search size={14} />
                </button>
              </div>
            </div>

          </div>

          {/* ── Middle Interactive Monthly Calendar View matching user screenshot ─ */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
            {/* Calendar Control Bar */}
            <div className="bg-slate-800/80 border-b border-slate-700/70 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <button onClick={prevMonth} className="px-2 py-1 bg-slate-700 hover:bg-slate-600 rounded text-slate-200 font-semibold transition-colors">◀</button>
                <button onClick={nextMonth} className="px-2 py-1 bg-slate-700 hover:bg-slate-600 rounded text-slate-200 font-semibold transition-colors">▶</button>
                <button onClick={goToday} className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 rounded text-slate-200 font-medium transition-colors">today</button>
                <span className="text-sm font-bold text-white ml-2">{monthName}</span>
              </div>

              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                {(['day', 'week', 'month', 'timeline'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setCalendarView(mode)}
                    className={`px-3 py-1 rounded text-xs capitalize font-medium transition-all ${
                      calendarView === mode
                        ? 'bg-slate-700 text-white font-semibold shadow-xs'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            {/* Calendar Day Header */}
            <div className="grid grid-cols-7 border-b border-slate-800 text-center text-xs font-semibold text-slate-400 bg-slate-950/40 py-2">
              <div>Sun</div>
              <div>Mon</div>
              <div>Tue</div>
              <div>Wed</div>
              <div>Thu</div>
              <div>Fri</div>
              <div>Sat</div>
            </div>

            {/* Calendar Days Grid */}
            <div className="grid grid-cols-7 auto-rows-fr gap-px bg-slate-800/60 p-px">
              {calendarDays.map((c, index) => {
                const isToday = c.currentMonth && c.day === new Date().getDate() && month === new Date().getMonth();
                return (
                  <div
                    key={index}
                    className={`min-h-[70px] p-2 bg-slate-900/90 transition-colors flex flex-col justify-start ${
                      c.currentMonth ? 'text-slate-200' : 'text-slate-600 bg-slate-950/40'
                    } ${isToday ? 'ring-2 ring-indigo-500 bg-indigo-950/20' : 'hover:bg-slate-800/40'}`}
                  >
                    <div className="flex justify-between items-start">
                      <span className={`text-xs font-bold ${isToday ? 'text-indigo-400 bg-indigo-500/20 w-5 h-5 rounded-full flex items-center justify-center' : ''}`}>
                        {c.day < 10 ? `0${c.day}` : c.day}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── Bottom Grid: Notice Board & Birthdays/Celebrations ───────── */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Notice Board Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm flex flex-col h-72">
              <div className="bg-sky-600 text-white px-4 py-2.5 font-bold text-sm flex items-center justify-between">
                <span>Notice Board</span>
                <span className="w-5 h-5 rounded-full bg-sky-800/60 flex items-center justify-center text-xs font-semibold">
                  {(data.notifications || []).length}
                </span>
              </div>
              <div className="p-4 flex-1 overflow-y-auto space-y-3">
                {(data.notifications || []).length > 0 ? (
                  (data.notifications || []).map((notif: any) => (
                    <div key={notif.id} className="p-3 rounded-lg border bg-slate-950/60 border-slate-800 flex items-start gap-3">
                      <div className="w-2 h-2 rounded-full bg-sky-400 mt-1 shrink-0" />
                      <div>
                        <p className="text-xs font-semibold text-slate-100">{notif.title}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5">{notif.message || 'Official company announcement for all employees.'}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="h-full flex items-center justify-center text-xs text-slate-500">
                    No new notices posted on notice board.
                  </div>
                )}
              </div>
            </div>

            {/* Birthdays/Celebrations Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm flex flex-col h-72">
              <div className="bg-slate-700 text-white px-4 py-2.5 font-bold text-sm flex items-center justify-between">
                <span>Birthdays/Celebrations</span>
                <span className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center text-xs font-semibold text-white">
                  {(data.milestones?.newJoiners?.length || 0) + (data.milestones?.anniversaries?.length || 0)}
                </span>
              </div>
              <div className="p-4 flex-1 overflow-y-auto space-y-3">
                {data.milestones?.newJoiners && data.milestones.newJoiners.length > 0 && (
                  <div className="p-3 rounded-lg border bg-emerald-950/30 border-emerald-800/40">
                    <p className="text-xs font-bold text-emerald-400 mb-1">🎉 New Joiners</p>
                    <p className="text-[11px] text-slate-300">{data.milestones.newJoiners.length} new employee(s) joined this month!</p>
                  </div>
                )}
                {data.milestones?.anniversaries && data.milestones.anniversaries.length > 0 && (
                  <div className="p-3 rounded-lg border bg-amber-950/30 border-amber-800/40">
                    <p className="text-xs font-bold text-amber-400 mb-1">🎂 Work Anniversaries & Birthdays</p>
                    <p className="text-[11px] text-slate-300">{data.milestones.anniversaries.length} employee(s) celebrating this month!</p>
                  </div>
                )}
                {(!data.milestones?.newJoiners?.length && !data.milestones?.anniversaries?.length) && (
                  <div className="h-full flex items-center justify-center text-xs text-slate-500">
                    No upcoming celebrations scheduled for today.
                  </div>
                )}
              </div>
            </div>

          </div>



          {/* ── 8 Charts (2 Rows of 4 or 4 Rows of 2) ──────────────────────── */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
            
            {/* 1. Attendance Trend */}
            <div className="section-card p-5 xl:col-span-2 min-h-[300px] flex flex-col">
              <h2 className="text-sm font-semibold mb-4 text-ink flex items-center gap-2"><Zap size={16} className="text-warning"/> Attendance Trend</h2>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={data.attendanceTrend || []} barSize={12} barGap={4}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border-subtle)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                  <Tooltip cursor={{ fill: 'var(--surface-active)' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-popover)' }} />
                  <Bar dataKey="present" name="Present" fill="#10B981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="absent" name="Absent" fill="#EF4444" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="leave" name="Leave" fill="#F97316" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* 2. Employee Growth */}
            <div className="section-card p-5 xl:col-span-2 min-h-[300px] flex flex-col">
              <h2 className="text-sm font-semibold mb-4 text-ink flex items-center gap-2"><Users size={16} className="text-info"/> Employee Growth</h2>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={data.headcountTrend || []}>
                  <defs>
                    <linearGradient id="colorGrowth" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border-subtle)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-popover)' }} />
                  <Area type="monotone" dataKey="headcount" name="Headcount" stroke="#3B82F6" strokeWidth={3} fillOpacity={1} fill="url(#colorGrowth)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* 3. Department Distribution */}
            <div className="section-card p-5 flex flex-col items-center min-h-[300px]">
              <h2 className="text-sm font-semibold mb-4 text-ink w-full">Department Mix</h2>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={data.departmentMix || []} innerRadius={50} outerRadius={70} paddingAngle={2} dataKey="value">
                    {(data.departmentMix || []).map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-popover)' }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-wrap gap-2 justify-center mt-2">
                {(data.departmentMix || []).slice(0,3).map((d: any, i: number) => (
                  <div key={d.name} className="flex items-center gap-1 text-[10px] text-muted">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: CHART_COLORS[i % CHART_COLORS.length] }}></div>
                    {d.name}
                  </div>
                ))}
              </div>
            </div>

            {/* 4. Leave Statistics */}
            <div className="section-card p-5 flex flex-col items-center min-h-[300px]">
              <h2 className="text-sm font-semibold mb-4 text-ink w-full">Leave Statistics</h2>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={data.leaveStatistics || []} innerRadius={0} outerRadius={70} dataKey="value">
                    {(data.leaveStatistics || []).map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[(index + 3) % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-popover)' }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-wrap gap-2 justify-center mt-2">
                {(data.leaveStatistics || []).map((d: any, i: number) => (
                  <div key={d.name} className="flex items-center gap-1 text-[10px] text-muted">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: CHART_COLORS[(i + 3) % CHART_COLORS.length] }}></div>
                    {d.name}
                  </div>
                ))}
              </div>
            </div>

            {/* 5. Monthly Payroll Cost */}
            <div className="section-card p-5 xl:col-span-2 min-h-[300px] flex flex-col">
              <h2 className="text-sm font-semibold mb-4 text-ink flex items-center gap-2"><Wallet size={16} className="text-success"/> Payroll Cost (Last 6 Months)</h2>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={data.monthlyPayrollCost || []}>
                  <defs>
                    <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10B981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border-subtle)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} tickFormatter={(val) => `₹${(val/1000).toFixed(0)}k`} />
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-popover)' }} />
                  <Area type="monotone" dataKey="cost" name="Cost" stroke="#10B981" strokeWidth={3} fillOpacity={1} fill="url(#colorCost)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* 6. Recruitment Pipeline */}
            <div className="section-card p-5 min-h-[300px] flex flex-col">
              <h2 className="text-sm font-semibold mb-4 text-ink">Recruitment Funnel</h2>
              <div className="flex-1 flex flex-col justify-center gap-3">
                {[
                  { label: 'Applied', count: data.recruitmentPipeline?.applied || 0, color: '#6B7280' },
                  { label: 'Interview', count: data.recruitmentPipeline?.interview || 0, color: '#3B82F6' },
                  { label: 'Offered', count: data.recruitmentPipeline?.offer || 0, color: '#F59E0B' },
                  { label: 'Hired', count: data.recruitmentPipeline?.hired || 0, color: '#10B981' },
                ].map((stage, i) => {
                  const max = Math.max(1, data.recruitmentPipeline?.applied || 1);
                  const w = Math.max(10, (stage.count / max) * 100);
                  return (
                    <div key={stage.label}>
                      <div className="flex justify-between text-[11px] mb-1.5 text-muted font-medium">
                        <span>{stage.label}</span>
                        <span className="font-bold text-ink">{stage.count}</span>
                      </div>
                      <div className="h-3 rounded-full bg-surface-active overflow-hidden shadow-inner">
                        <div className="h-full rounded-full transition-all duration-1000 relative" style={{ width: `${w}%`, backgroundColor: stage.color }}>
                           <div className="absolute inset-0 bg-white/20 w-full h-full" style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)' }}></div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* 7. Attrition Rate */}
            <div className="section-card p-5 xl:col-span-2 min-h-[300px] flex flex-col">
              <h2 className="text-sm font-semibold mb-4 text-ink flex items-center gap-2"><UserMinus size={16} className="text-danger"/> Attrition Rate (%)</h2>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={data.attritionRate || []}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border-subtle)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} unit="%" />
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-popover)' }} />
                  <Line type="monotone" dataKey="rate" name="Attrition Rate" stroke="#EF4444" strokeWidth={3} dot={{ r: 4, fill: '#EF4444' }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* 8. Gender Distribution */}
            <div className="section-card p-5 flex flex-col items-center min-h-[300px]">
              <h2 className="text-sm font-semibold mb-4 text-ink w-full">Diversity</h2>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={data.genderDistribution || []} innerRadius={60} outerRadius={75} paddingAngle={5} dataKey="value">
                    {(data.genderDistribution || []).map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={GENDER_COLORS[index % GENDER_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-popover)' }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-wrap gap-3 justify-center mt-2">
                {(data.genderDistribution || []).map((d: any, i: number) => (
                  <div key={d.name} className="flex items-center gap-1 text-[11px] text-muted">
                    <div className="w-3 h-3 rounded-md" style={{ backgroundColor: GENDER_COLORS[i % GENDER_COLORS.length] }}></div>
                    {d.name} ({d.value})
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* ── Activity Feeds ──────────────────────── */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Recent Activities */}
            <div className="section-card p-5 h-96 flex flex-col">
              <h2 className="text-sm font-semibold mb-4 text-ink flex items-center gap-2"><History size={16} /> Recent Activities</h2>
              <div className="flex-1 overflow-y-auto pr-2 space-y-4">
                {(data.recentActivities || []).map((act: any, i: number) => (
                  <div key={act.id} className="flex gap-3 relative">
                    {i !== (data.recentActivities || []).length - 1 && <div className="absolute top-6 left-2 w-px h-full bg-border -ml-px"></div>}
                    <div className="w-4 h-4 mt-1 rounded-full border-2 border-surface bg-info z-10"></div>
                    <div>
                      <p className="text-[13px] text-ink font-medium">{act.title}</p>
                      <p className="text-[10px] text-muted">{new Date(act.time).toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pending Actions & Notifications */}
            <div className="section-card p-5 h-96 flex flex-col">
              <h2 className="text-sm font-semibold mb-4 text-ink flex items-center gap-2"><Bell size={16} /> Action Items & Alerts</h2>
              <div className="flex-1 overflow-y-auto pr-2 space-y-3">
                
                {/* Real Pending Leave Requests */}
                {data.pendingLeaveRequests && data.pendingLeaveRequests.length > 0 && (
                  <div className="mb-3">
                    {data.pendingLeaveRequests.map((req: any) => (
                      <div key={req.id} className="block p-3 rounded-lg border bg-warning/10 border-warning/20 mb-2 transition-colors">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-[13px] text-ink font-semibold leading-snug">{req.employeeName}</p>
                            <p className="text-[11px] text-muted mt-0.5 font-medium">{req.leaveType} Request</p>
                          </div>
                          <div className="flex gap-1.5">
                            <button onClick={() => approveMutation.mutate(req.id)} className="text-[9px] bg-success/20 text-success hover:bg-success hover:text-white px-2 py-1 rounded-md uppercase font-bold tracking-wider transition-colors cursor-pointer">Approve</button>
                            <Link to="/leave/requests" className="text-[9px] bg-warning/20 text-warning hover:bg-warning hover:text-white px-2 py-1 rounded-md uppercase font-bold tracking-wider transition-colors">Review</Link>
                          </div>
                        </div>
                        <p className="text-[10px] text-ink/70 mt-2 font-medium">
                          {new Date(req.startDate).toLocaleDateString()} to {new Date(req.endDate).toLocaleDateString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
                {(data.notifications || []).map((notif: any) => {
                  let badge = 'bg-info/10 text-info border-info/20';
                  if (notif.type === 'warning') badge = 'bg-warning/10 text-warning border-warning/20';
                  if (notif.type === 'urgent') badge = 'bg-danger/10 text-danger border-danger/20';
                  
                  return (
                    <div key={notif.id} className="p-3 rounded-lg border bg-surface-active border-border flex items-start gap-3">
                      <div className={`mt-0.5 w-2 h-2 rounded-full ${notif.type === 'urgent' ? 'bg-danger animate-ping' : notif.type === 'warning' ? 'bg-warning' : 'bg-info'}`}></div>
                      <div>
                        <p className="text-[13px] text-ink font-medium leading-snug">{notif.title}</p>
                        <span className={`inline-block mt-2 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded-md border ${badge}`}>
                          {notif.type}
                        </span>
                      </div>
                    </div>
                  )
                })}
                {data.milestones?.newJoiners && data.milestones.newJoiners.length > 0 ? (
                  <div className="p-3 rounded-lg border bg-success/5 border-success/20">
                    <p className="text-[12px] font-bold text-success mb-1">🎉 New Joiners</p>
                    <p className="text-[11px] text-muted">{data.milestones.newJoiners.length} new employee(s) joined this month. Welcome them!</p>
                  </div>
                ) : null}
                {data.milestones?.anniversaries && data.milestones.anniversaries.length > 0 ? (
                  <div className="p-3 rounded-lg border bg-info/5 border-info/20">
                    <p className="text-[12px] font-bold text-info mb-1">🎂 Work Anniversaries</p>
                    <p className="text-[11px] text-muted">{data.milestones.anniversaries.length} employee(s) have work anniversaries this month.</p>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </>
      )}

    </div>
  );
}
