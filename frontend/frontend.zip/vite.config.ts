import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { port: 5173 },
  base: './',
  build: {
    target: 'es2022'
  },
  esbuild: {
    target: 'es2022'
  },
});
