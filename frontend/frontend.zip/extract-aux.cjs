const fs = require('fs');
const content = fs.readFileSync('src/components/Layout.tsx', 'utf8');
const routes = [...content.matchAll(/to:\s*'(\/[^']+)'(.*?)label:\s*'([^']+)'/g)];

const uniqueRoutes = new Map();
for (const match of routes) {
  const path = match[1].substring(1); // remove leading slash
  const label = match[3];
  if (!uniqueRoutes.has(path)) {
    uniqueRoutes.set(path, label);
  }
}

let auxArr = 'export const AUXILIARY_ROUTES = [\n';
for (const [path, label] of uniqueRoutes.entries()) {
  if (path.includes('/') && path !== 'employees/me' && path !== 'employees/add' && path !== 'employees/transfer' && path !== 'employees/promotion' && path !== 'employees/resignation' && path !== 'employees/exit' && path !== 'employees/compliance') {
    auxArr += `  { path: '${path}', resourceType: '${path.replace(/\//g, '-')}', title: '${label}' },\n`;
  }
}
auxArr += '];\n';

fs.writeFileSync('src/AuxiliaryRoutes.ts', auxArr, 'utf8');
