const fs = require('fs');
const path = require('path');

const pages = [
  { path: 'src/pages/tax/TaxMasterPage.tsx', title: 'Employee TDS Declaration Master', icon: 'Calculator' },
  { path: 'src/pages/tax/TaxDeclarationsPage.tsx', title: 'Employee TDS Declaration List', icon: 'Calculator' },
  { path: 'src/pages/employee/attendance/DailyAttendancePage.tsx', title: 'Daily Attendance', icon: 'Clock' },
  { path: 'src/pages/employee/attendance/ManualPunchPage.tsx', title: 'Manual Punch', icon: 'Clock' },
  { path: 'src/pages/employee/attendance/CustomAttendancePage.tsx', title: 'Custom Attendance', icon: 'Clock' },
  { path: 'src/pages/employee/attendance/OvertimePage.tsx', title: 'Overtime', icon: 'Clock' },
  { path: 'src/pages/employee/attendance/GeofencePage.tsx', title: 'Geofence Attendance', icon: 'Clock' },
  { path: 'src/pages/employee/attendance/DailyReportPage.tsx', title: 'Daily Attendance Report', icon: 'Clock' },
  { path: 'src/pages/employee/attendance/SummaryPage.tsx', title: 'Attendance Summary', icon: 'Clock' },
  { path: 'src/pages/hr/employees/EmployeePromotionPage.tsx', title: 'Employee Promotion', icon: 'Award' },
];

const template = (p) => {
  const componentName = path.basename(p.path, '.tsx');
  return `import { ${p.icon}, Command } from 'lucide-react';

export default function ${componentName}() {
  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Premium Header */}
      <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="absolute top-0 right-0 p-32 bg-blue-500/10 rounded-bl-full -z-0 blur-2xl"></div>
        <div className="relative z-10 flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-500 shadow-inner">
             <${p.icon} size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[var(--text-primary)] tracking-tight">${p.title}</h1>
            <p className="text-sm text-[var(--text-muted)] mt-1 font-medium">Manage ${p.title.toLowerCase()} configurations and data.</p>
          </div>
        </div>
      </div>

      <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 shadow-sm min-h-[400px]">
        <div className="flex flex-col items-center justify-center h-64 text-[var(--text-muted)]">
           <div className="w-16 h-16 rounded-2xl bg-[var(--surface-alt)] border border-[var(--border)] flex items-center justify-center mb-4">
             <Command size={24} className="animate-spin-slow text-blue-500" />
           </div>
           <p className="text-sm font-bold text-[var(--text-primary)]">${p.title}</p>
           <p className="text-xs mt-1">This module is currently pending integration.</p>
        </div>
      </div>
    </div>
  );
}
`;
};

pages.forEach(p => {
  const fullPath = path.join(__dirname, p.path);
  const dir = path.dirname(fullPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(fullPath, template(p));
});

console.log('Generated 10 missing pages.');
