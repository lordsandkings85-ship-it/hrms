const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// add imports
code = code.replace("import { ErrorBoundary } from './components/ui/ErrorBoundary';", "import { ErrorBoundary } from './components/ui/ErrorBoundary';\nimport { AUXILIARY_ROUTES } from './AuxiliaryRoutes';\nimport { DynamicResourceView } from './components/ui/DynamicResourceView';");

// add before the mapped explicit routes
const targetStr = '          // Core pages';
const replaceStr = `          ...AUXILIARY_ROUTES.map(route => ({
            path: route.path,
            element: <DynamicResourceView resourceType={route.resourceType} title={route.title} />
          })),
          // Core pages`;

code = code.replace(targetStr, replaceStr);

code = code.replace(
  '].map(({ path, El }) => (',
  '].map(({ path, El, element }: any) => ('
);

code = code.replace(
  '<El />',
  '{El ? <El /> : element}'
);

fs.writeFileSync('src/App.tsx', code, 'utf8');
