const fs = require('fs');
const path = require('path');

const pages = [
  { name: 'LeaveApprovalPage', type: 'leave', title: 'Leave Approval', icon: 'Calendar' },
  { name: 'CancelLeaveApprovalPage', type: 'cancel-leave', title: 'Cancel Leave Application', icon: 'XSquare' },
  { name: 'ColCoffApprovalPage', type: 'compoff', title: 'COL/COFF Application', icon: 'RotateCcw' },
  { name: 'TravelClaimApprovalPage', type: 'travel', title: 'Travel Claim Approval', icon: 'Plane' },
  { name: 'AdvanceClaimApprovalPage', type: 'advance', title: 'Advance Claim Approval', icon: 'Wallet' },
  { name: 'LoanAdvanceApprovalPage', type: 'loan', title: 'Loan/Advance Approval', icon: 'Landmark' },
  { name: 'ShiftChangeApprovalPage', type: 'shift', title: 'Shift Change Approval', icon: 'Clock' },
  { name: 'OptionalHolidayApprovalPage', type: 'optional-holiday', title: 'Optional Holiday Approval', icon: 'CalendarDays' },
  { name: 'OvertimeApprovalPage', type: 'overtime', title: 'Overtime (O.T) Approval', icon: 'BarChart3' }
];

const template = (p) => `import { useMutation, useQueryClient } from '@tanstack/react-query';
import { leaveApi } from '../../../api/client';
import { ApprovalQueue } from '../../../components/hr/ApprovalQueue';
import { ${p.icon} } from 'lucide-react';
import { useToast } from '../../../components/ui/ToastProvider';

export default function ${p.name}() {
  const queryClient = useQueryClient();
  const { success } = useToast();

  const approveMutation = useMutation({
    mutationFn: (id: string) => leaveApi.approve(id),
    onSuccess: () => { success('Approved!', 'Request was approved successfully.'); queryClient.invalidateQueries({ queryKey: ['${p.type}-approvals'] }); }
  });

  const rejectMutation = useMutation({
    mutationFn: (id: string) => leaveApi.reject(id),
    onSuccess: () => { success('Rejected!', 'Request was rejected.'); queryClient.invalidateQueries({ queryKey: ['${p.type}-approvals'] }); }
  });

  return (
    <ApprovalQueue
      title="${p.title}"
      icon={${p.icon}}
      queryKey={['${p.type}-approvals']}
      queryFn={async () => {
        const res = await leaveApi.listPending();
        return res || [];
      }}
      onApprove={(id) => approveMutation.mutate(id)}
      onReject={(id) => rejectMutation.mutate(id)}
    />
  );
}
`;

const dir = path.join(__dirname, 'src', 'pages', 'hr', 'approvals');
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

pages.forEach(p => {
  fs.writeFileSync(path.join(dir, p.name + '.tsx'), template(p));
});

console.log('Generated 9 approval pages.');
